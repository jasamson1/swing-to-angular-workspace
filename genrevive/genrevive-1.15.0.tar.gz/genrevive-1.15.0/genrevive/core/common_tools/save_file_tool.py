from textwrap import dedent

from crewai.tools import tool
from genrevive.core.validation.directory_access_validator import (
    DirectoryAccessValidator,
)
from genrevive.helpers.common.file_utils import FileUtils


@tool("Save file")
def save_file_tool(file_path: str, content: str) -> str:
    """
    Saves the provided content to the specified file path.

    Args:
        file_path (str): The path where the content will be saved.
        content (str): The content to be saved.

    Returns:
        str: Confirmation message indicating the file path where the code was saved.
    """
    DirectoryAccessValidator.is_allowed_to_access(file_path)
    try:
        FileUtils.write_file(file_path, content)
        return f"Saving content to file: {file_path}."
    except Exception as e:
        return f"An error occurred while saving the file: {e}"


def get_instructions_string():
    return dedent("""Save the code and explanation blocks and in their respective files. 
        Only save the contents of the code and explanation blocks, not the first line with the filename.
        Use the correct extension according to the type of code block. The explanation blocks should be saves as .md files. 
        IMPORTANT INSTRUCTIONS:
        ------------------------------
        - Action Input, although a JSON dictionary, must *never* be surrounded by backticks! It must be passed verbatim as a JSON dictionary.
        - "```json ... ```" is not allowed!!!. This is critical, as the tool will not be able to function correctly if this is done.""")
