from textwrap import dedent

from crewai.tools import tool
from genrevive.helpers.common.file_utils import (
    FileUtils,
)


@tool("Read file")
def read_file_tool(file_path: str) -> str:
    """
    Reads and returns the content of the specified file.

    Args:
        file_path (str): The path to the file to be read.

    Returns:
        str: The content of the file, or an error message if the file cannot be read.
    """
    try:
        content = FileUtils.read_file(file_path)
        return f"Content of file '{file_path}':\n\n{content}"
    except Exception as e:
        return f"An error occurred while reading the file '{file_path}': {e}"


@tool("List files in directory")
def list_files_tool(directory_path: str) -> str:
    """
    Lists all files and directories in the specified directory.

    Args:
        directory_path (str): The path to the directory to list.

    Returns:
        str: A formatted list of files and directories, or an error message if the directory cannot be accessed.
    """
    try:
        import os

        items = os.listdir(directory_path)
        if not items:
            return f"Directory '{directory_path}' is empty."

        files = []
        dirs = []
        for item in items:
            item_path = os.path.join(directory_path, item)
            if os.path.isdir(item_path):
                dirs.append(f"📁 {item}/")
            else:
                files.append(f"📄 {item}")  # Fixed: use files.append()

        result = f"Contents of directory '{directory_path}':\n\n"
        for item in sorted(dirs + files):
            result += f"  {item}\n"

        return result
    except Exception as e:
        return f"An error occurred while listing directory '{directory_path}': {e}"


def get_instructions_string():
    return dedent(
        """Use these tools to read files and explore directory structures during migration analysis.
        
        IMPORTANT INSTRUCTIONS:
        ------------------------------
        - Use read_file_tool to examine source code files, configuration files, and documentation
        - Use list_files_tool to explore project structure and identify relevant files
        - File paths should be absolute or relative to the current working directory
        - Action Input, although a JSON dictionary, must *never* be surrounded by backticks! It must be passed verbatim as a JSON dictionary.
        - "```json ... ```" is not allowed!!!. This is critical, as the tool will not be able to function correctly if this is done."""
    )
