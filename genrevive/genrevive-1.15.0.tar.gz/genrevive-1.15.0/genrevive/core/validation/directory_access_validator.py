import os
from pathlib import Path
from typing import Tuple


class DirectoryAccessValidator:
    '''
    This class is responsible for validating whether
    a given file path is allowed to be accessed based
    on the allowed paths defined in the .env file.
    It provides a method to check if access to a
    specific file path is permitted, ensuring that
    the application only interacts with authorized
    directories.
    '''
    @staticmethod
    def is_allowed_to_access(file_path: str | Path) -> None:
        
        full_file_path = Path(str(file_path).strip()).resolve()
        whitelisted_paths = DirectoryAccessValidator._get_whitelisted_paths_from_dot_env()          

        for allowed_path in whitelisted_paths:
            try:
                full_file_path.relative_to(allowed_path)
                return
            except ValueError:
                continue
        
        raise ValueError(f"Not allowed to access path: {file_path}. Please configure a whitelisted path in the .env file.")

    
    @staticmethod
    def _get_whitelisted_paths_from_dot_env() -> Tuple[Path, ...]:
        whitelisted_paths_str = os.environ.get("WHITELISTED_PATHS")
        if not whitelisted_paths_str:
            raise ValueError("No whitelisted paths configured in .env file.")
        
        whitelisted_paths = tuple(
            Path(path.strip()).resolve()
            for path in whitelisted_paths_str.split(",") 
            if path.strip()
        )
        return whitelisted_paths


