from textwrap import dedent
from typing import Optional, Type
from pydantic import BaseModel
from crewai.tools import BaseTool
from genrevive.core.chunked_task_creator import ChunkedTaskCreator
from genrevive.helpers.common.merge_tools import get_merged_tools_for_task_type
from crewai import Task, Agent
from typing import List, Union
from crewai.utilities.constants import NOT_SPECIFIED, _NotSpecified
from genrevive.helpers.common.markdown_renderer import MarkdownRenderer
from dotenv import load_dotenv
import os


class TaskFactory:
    """Factory class to create various types of tasks for different roles.

    Class Attributes:
        _default_mcp_tools (list):
            Class variable to hold the default list of MCP tools.
            This is shared across all instances of TaskFactory and is used as a fallback.
            It should be initialized early (e.g., after connecting to the MCP server).

            Note:
                Existing migrators may call tasks as TaskFactory().task_*,
                which will override this default tools for that specific call. This class-level default ensures
                backward compatibility and provides a consistent fallback for cases where tools are not
                passed explicitly.
    """

    _default_mcp_tools = []

    def __init__(self, tools: Optional[list] = None):
        """
        Initialize the TaskFactory with a list of MCP tools.

        Args:
            tools (Optional[list]):
                A list of tools (typically MCP tools) that will be available to all tasks created by this factory.
                Pass the tools obtained from the MCP server connection.
                If not provided, the factory will initialize with an empty toolset.

        Note:
            Migrator developers should pass the list of tools that tasks may require for their operations,
            such as those returned by the MCPServerAdapter. This ensures tasks have access to the necessary
            capabilities for code generation, review, or DevOps operations.
        """
        load_dotenv()
        if tools is not None:
            TaskFactory._default_mcp_tools = tools
        self.chunked_task_creator = ChunkedTaskCreator()

    def __task_code_generation(
        self,
        agent: Agent,
        prompt: str,
        cookbook: str,
        input: str,
        target_technology_names: list[str],
        target_file_path: str,
        callback: any,
        other_instructions: str = None,
        tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        expected_output: Optional[str] = None,
        context: Optional[
            Union[List["Task"], None, _NotSpecified]
        ] = NOT_SPECIFIED,
    ) -> Task:
        """
        Create a task for code generation by an agent.

        Args:
            agent (Agent): The agent responsible for the task.
            prompt (str): The prompt for the agent.
            input (str): The input code or information to be translated.
            cookbook (str): The cookbook containing reference information.
            target_technology_names (list[str]): The technology names to which the code is being translated.
            target_file_path (str): The path where the translated code should be saved.
            callback (any): Callback to be executed after the task is completed.
            other_instructions (str): Other instructions for the agent.
            tools (list[BaseTool]): The tools/resources the agent is limited to use for this task.
            output_pydantic (Optional[Type[BaseModel]]): A Pydantic model for task output.
            expected_output (Optional[str]): A detailed description of what the task’s completion looks like.
            context (Optional[Union[List["Task"]): Optional context for this task; A list of previous tasks' outputs
        Returns:
            Task: A Task instance configured for code generation.
        """

        other_instructions_str = (
            f"# Other instructions:\n{other_instructions}"
            if other_instructions is not None
            else ""
        )

        return Task(
            description=remove_leading_whitespaces(
                f"""
                # Prompt:
                {prompt}                
                # Cookbook:
                {cookbook}
                # Input:
                {input}
                {other_instructions_str}
                """
            ),
            agent=agent,
            context=context,
            expected_output=(
                remove_leading_whitespaces(expected_output)
                if expected_output is not None
                else remove_leading_whitespaces(
                    f"""
                Runnable {",".join(target_technology_names)} Code
                Put "# filename: {target_file_path}/<filename>" inside each code block as first line.
                The output must look like:                
                {self.__get_code_block_sting(target_technology_names, target_file_path)}
                ```markdown
                    # filename: {target_file_path}/<filename>.md
                    <changelog>
                ```
                """
                )
            ),
            callback=callback,
            tools=tools or [],
            output_pydantic=output_pydantic,
        )

    def task_migration_analysis(
        self,
        agent: Agent,
        prompt: str,
        input: str,
        target_file_path: str,
        callback: any,
        expected_output: Optional[str] = None,
        tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        context: Optional[
            Union[List["Task"], None, _NotSpecified]
        ] = NOT_SPECIFIED,
    ) -> Task:
        """
        Create a task for migration analysis.

        Args:
            agent (Agent): The agent responsible for the task.
            prompt (str): The prompt for the agent.
            input (str): The input code or information to be analyzed.
            target_file_path (str): The path where the analysis results should be saved.
            callback (any): Callback to be executed after the task is completed.other_instructions (str): Other instructions for the agent.
            tools (list[BaseTool]): The tools/resources the agent is limited to use for this task.
            output_pydantic (Optional[Type[BaseModel]]): A Pydantic model for task output.
            expected_output (Optional[str]): A detailed description of what the task’s completion looks like.
            context (Optional[Union[List["Task"]): Optional context for this task; A list of previous tasks' outputs
        Returns:
            Task: A Task instance configured for migration analysis.
        """

        merged_tools = get_merged_tools_for_task_type(
            TaskFactory._default_mcp_tools, tools, "MIGRATION_ANALYSIS"
        )
        return Task(
            description=remove_leading_whitespaces(
                f"""
                # Prompt:
                {prompt}
                # Input:
                {input}                
                """
            ),
            agent=agent,
            context=context,
            expected_output=expected_output,
            target_file_path=target_file_path,
            callback=callback,
            tools=merged_tools,
            output_pydantic=output_pydantic,
        )

    def task_quality_confirmation(
        self,
        agent: Agent,
        prompt: str,
        input: str,
        target_file_path: str,
        callback: any,
        expected_output: Optional[str] = None,
        tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
    ) -> Task:
        """
        Create a task for quality confirmation.

        Args:
            agent (Agent): The agent responsible for the task.
            prompt (str): The prompt for the agent.
            input (str): The input code or information to be analyzed.
            target_file_path (str): The path where the analysis results should be saved.
            callback (any): Callback to be executed after the task is completed.other_instructions (str): Other instructions for the agent.
            tools (list[BaseTool]): The tools/resources the agent is limited to use for this task.
            output_pydantic (Optional[Type[BaseModel]]): A Pydantic model for task output.
            expected_output (Optional[str]): A detailed description of what the task’s completion looks like.

        Returns:
            Task: A Task instance configured for migration analysis.
        """

        merged_tools = get_merged_tools_for_task_type(
            TaskFactory._default_mcp_tools, tools, "MIGRATION_ANALYSIS"
        )
        return Task(
            description=remove_leading_whitespaces(
                f"""
                # Prompt:
                {prompt}
                # Input:
                {input}                
                """
            ),
            agent=agent,
            expected_output=expected_output,
            target_file_path=target_file_path,
            callback=None,
            tools=merged_tools,
            output_pydantic=output_pydantic,
            human_input=True,
        )

    def task_migration_development(
        self,
        agent: Agent,
        prompt: str,
        input: str,
        target_file_path: str,
        callback: any,
        expected_output: Optional[str] = None,
        tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        context: Optional[
            Union[List["Task"], None, _NotSpecified]
        ] = NOT_SPECIFIED,
    ) -> Task:
        """
        Create a task for migration development.

        Args:
            agent (Agent): The agent responsible for the task.
            prompt (str): The prompt for the agent.
            input (str): The input code or information to be analyzed.
            target_file_path (str): The path where the analysis results should be saved.
            callback (any): Callback to be executed after the task is completed.other_instructions (str): Other instructions for the agent.
            tools (list[BaseTool]): The tools/resources the agent is limited to use for this task.
            output_pydantic (Optional[Type[BaseModel]]): A Pydantic model for task output.
            expected_output (Optional[str]): A detailed description of what the task’s completion looks like.
            context (Optional[Union[List["Task"]): Optional context for this task; A list of previous tasks' outputs
        Returns:
            Task: A Task instance configured for migration development.
        """

        merged_tools = get_merged_tools_for_task_type(
            TaskFactory._default_mcp_tools, tools, "MIGRATION_DEVELOPMENT"
        )
        return Task(
            description=remove_leading_whitespaces(
                f"""
                # Prompt:
                {prompt}
                # Input:
                {input}                
                """
            ),
            agent=agent,
            context=context,
            expected_output=expected_output,
            target_file_path=target_file_path,
            callback=callback,
            tools=merged_tools,
            output_pydantic=output_pydantic,
        )

    @staticmethod
    def __get_code_block_sting(
        target_technology_names: list[str], target_file_path: str
    ) -> str:
        result = ""
        for technology in target_technology_names:
            result += dedent(
                f"""
                ```{technology}
                    # filename: {target_file_path}/<filename>
                    <code>
                ```"""
            )
        return result

    def task_code_translation(
        self,
        agent: Agent,
        prompt: str,
        cookbook: str,
        input: Union[str, dict],
        target_technology_names: list[str],
        target_file_path: str,
        callback: any,
        other_instructions: str = None,
        tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        expected_output: Optional[str] = None,
        context: Optional[
            Union[List["Task"], None, _NotSpecified]
        ] = NOT_SPECIFIED,
        chunking_enabled: bool = False,
    ) -> Task:
        """
        Create a task for code generation by an agent.

        Args:
            agent (Agent): The agent responsible for the task.
            prompt (str): The prompt for the agent.
            input (Union[str, dict]): The input code or information to be translated.
            cookbook (str): The cookbook containing reference information.
            target_technology_names (list[str]): The technology names to which the code is being translated.
            target_file_path (str): The path where the translated code should be saved.
            callback (any): Callback to be executed after the task is completed.
            other_instructions (str): Other instructions for the agent.
            tools (list[BaseTool]): The tools/resources the agent is limited to use for this task.
            output_pydantic (Optional[Type[BaseModel]]): A Pydantic model for task output.
            expected_output (Optional[str]): A detailed description of what the task’s completion looks like.
            chunking_enabled (bool): Flag to enable chunking mode for large inputs.

        Returns:
            Task: A Task instance configured for code translation.
        """

        merged_tools = get_merged_tools_for_task_type(
            TaskFactory._default_mcp_tools, tools, "CODE_TRANSLATION"
        )

        if chunking_enabled:
            return self.chunked_task_creator.create_chunked_translation_tasks(
                agent=agent,
                prompt=prompt,
                cookbook=cookbook,
                input=input,
                target_technology_names=target_technology_names,
                target_file_path=target_file_path,
                other_instructions=other_instructions,
                merged_tools=merged_tools,
                output_pydantic=output_pydantic,
                expected_output=expected_output,
            )
        else:
            input_markdown = (
                input
                if isinstance(input, str)
                else MarkdownRenderer.render_dict_to_markdown(input)
            )
            return self.__task_code_generation(
                agent=agent,
                prompt=prompt,
                cookbook=cookbook,
                input=input_markdown,
                target_technology_names=target_technology_names,
                target_file_path=target_file_path,
                callback=callback,
                other_instructions=other_instructions,
                tools=merged_tools,
                output_pydantic=output_pydantic,
                expected_output=expected_output,
                context=context,
            )

    def task_code_review(
        self,
        agent: Agent,
        prompt: str,
        cookbook: str,
        input: Union[str, dict],
        target_technology_names: list[str],
        target_file_path: str,
        callback: any,
        other_instructions: str = None,
        tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        expected_output: Optional[str] = None,
        context: Optional[
            Union[List["Task"], None, _NotSpecified]
        ] = NOT_SPECIFIED,
        chunking_enabled: bool = False,
    ) -> Task:
        """
        Create a task for code generation by an agent.

        Args:
            agent (Agent): The agent responsible for the task.
            prompt (str): The prompt for the agent.
            input (Union[str, dict]): The input code or information to be translated.
            cookbook (str): The cookbook containing reference information.
            target_technology_names (list[str]): The technology names to which the code is being translated.
            target_file_path (str): The path where the translated code should be saved.
            callback (any): Callback to be executed after the task is completed.
            other_instructions (str): Other instructions for the agent.
            tools (list[BaseTool]): The tools/resources the agent is limited to use for this task.
            output_pydantic (Optional[Type[BaseModel]]): A Pydantic model for task output.
            expected_output (Optional[str]): A detailed description of what the task’s completion looks like.
            chunking_enabled (bool): Flag to enable chunking mode for large inputs.


        Returns:
            Task: A Task instance configured for code review.
        """

        merged_tools = get_merged_tools_for_task_type(
            TaskFactory._default_mcp_tools, tools, "CODE_REVIEW"
        )

        if chunking_enabled:
            return self.chunked_task_creator._create_chunked_review_tasks(
                agent=agent,
                prompt=prompt,
                cookbook=cookbook,
                input=input,
                target_technology_names=target_technology_names,
                target_file_path=target_file_path,
                other_instructions=other_instructions,
                merged_tools=merged_tools,
                output_pydantic=output_pydantic,
                expected_output=expected_output,
            )
        else:
            input_markdown = (
                input
                if isinstance(input, str)
                else MarkdownRenderer.render_dict_to_markdown(input)
            )
            return self.__task_code_generation(
                agent=agent,
                prompt=prompt,
                cookbook=cookbook,
                input=input_markdown,
                target_technology_names=target_technology_names,
                target_file_path=target_file_path,
                callback=callback,
                other_instructions=other_instructions,
                tools=merged_tools,
                output_pydantic=output_pydantic,
                expected_output=expected_output,
                context=context,
            )

    def task_code_build(
        self,
        devops_engineer: Agent,
        devops_prompt: str,
        cookbook: str = None,
        tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        expected_output: Optional[str] = None,
        context: Optional[
            Union[List["Task"], None, _NotSpecified]
        ] = NOT_SPECIFIED,
        chunking_enabled: bool = False,
        callback: any = None,
    ) -> Task:
        """
        Create a task for code build by a DevOps engineer agent.

        Args:
            devops_engineer (Agent): The DevOps engineer agent responsible for the task.
            devops_prompt (str): The prompt for the DevOps engineer.
            tools (list[BaseTool]): The tools/resources the agent is limited to use for this task.
            output_pydantic (Optional[Type[BaseModel]]): A Pydantic model for task output.
            expected_output (Optional[str]): A detailed description of what the task’s completion looks like.

        Returns:
            Task: A Task instance configured for code building.
        """
        if chunking_enabled:
            from genrevive.core.building_fixing.project_builder_activity import (
                ProjectBuilderActivity,
            )

            return ProjectBuilderActivity(
                withCallback=True
            ).create_devops_task()
        else:
            merged_tools = get_merged_tools_for_task_type(
                TaskFactory._default_mcp_tools, tools, "CODE_BUILD"
            )

            cookbook = f"# Cookbook:\n{cookbook}" if cookbook else ""
            return Task(
                description=remove_leading_whitespaces(
                    f"""
                    # Prompt:
                    {devops_prompt}
                    {cookbook}
                    # IMPORTANT INSTRUCTIONS:
                    ------------------------------
                    - Action Input, although a JSON dictionary, must *never* be surrounded by backticks or any other character!
                    - It must be passed verbatim as a JSON dictionary—no backticks, no code fences, no square brackets [], no angle brackets <>, no quotes, and no extra text.
                    - "```json ... ```" is not allowed!!! This is critical, as the tool will not function correctly if this is done.
                    - Do NOT provide the 'Observation:' field yourself; it will be provided for you after the tool runs.
                    """
                ),
                agent=devops_engineer,
                context=context,
                expected_output=(
                    remove_leading_whitespaces(expected_output)
                    if expected_output is not None
                    else remove_leading_whitespaces(
                        """
                    If the build_success is 'False', provide a clear textual description of the error.
                    If the build_success is 'True', return 'Done'.
                """
                    )
                ),
                tools=merged_tools or [],
                output_pydantic=output_pydantic,
                callback=callback,
            )

    def task_code_build_and_extract_errors(
        self,
        devops_engineer: Agent,
        target_project_path: str,
        cookbook: str = None,
        devops_tools: list[BaseTool] = None,
    ) -> Task:
        """
        Create a task for code build by a DevOps engineer agent.
        The goal of this task is to build the project and extract errors if the build fails.

        Args:
            devops_engineer (Agent): The DevOps engineer agent responsible for the task.
            target_project_path (str): The path to the target project to be built.
            cookbook (str, optional): Additional instructions or guidelines for the task.
            devops_tools (list[BaseTool], optional): The tools/resources the agent is limited to use for this task.

        Returns:
            Task: A Task instance configured for code building.
        """
        cookbook = f"# Cookbook:\n{cookbook}" if cookbook else ""
        return Task(
            description=remove_leading_whitespaces(
                f"""
                # Prompt:
                {cookbook}
                Use the `maven_build_tool` to build the {target_project_path} project and analyze the build result.
                
                CRITICAL: The maven_build_tool returns a dictionary with:
                - 'success' field (boolean): True if build succeeded, False if build failed
                - 'description' field (string): Complete build log output
                
                You MUST check the 'success' field in the tool's return value to determine if the build passed or failed.
                
                # CRITICAL REQUIREMENTS:
                1. ALWAYS perform a CLEAN BUILD (mvn clean install or mvn clean compile)
                2. DO NOT use cached/stale artifacts from previous builds
                3. Execute maven_build_tool with fresh compilation
                
                # Required Workflow:
                1. Execute maven_build_tool (pass empty strings for file_path and java_code parameters)
                2. Check the 'success' field in the returned dictionary:
                   - If result['success'] == True: Report build_success = 'True'
                   - If result['success'] == False: Report build_success = 'False' and parse errors from the 'description' field
                3. When build fails (success == False), parse the 'description' field to extract:
                     * File names where errors occurred
                     * Variable/class names involved
                     * Line numbers of issues
                     * Exception types and error messages
                4. Make your output as concise as possible.
                5. Output must have information build_success = 'True' or 'False' based on the 'success' field
                6. DO NOT assume previous build results - always check the CURRENT tool output
                
                # IMPORTANT INSTRUCTIONS:
                ------------------------------
                - Action Input, although a JSON dictionary, must *never* be surrounded by backticks!
                It must be passed verbatim as a JSON dictionary.
                - "```json ... ```" is not allowed!!! This is critical, as the tool will not function correctly if this is done.
                - Always use the LATEST build output, not cached results
                - The tool returns a dictionary - check result['success'] to determine build status
                """
            ),
            agent=devops_engineer,
            expected_output=remove_leading_whitespaces(
                f"""
                # Expected Output Format:
                Your output MUST include build_success status based on the 'success' field from maven_build_tool:
                - build_success = 'True' if the tool returned {{'success': True, ...}}
                - build_success = 'False' if the tool returned {{'success': False, ...}}
                
                Example output for FAILURE (when tool returns {{'success': False, ...}}):
                build_success = 'False'
                Errors:
                * File: {target_project_path}/src/main/java/com/dakv/sumit/FinancialTransactionService.java
                * Line 17:
                - Error: modifier public not allowed here
                
                Example output for SUCCESS (when tool returns {{'success': True, ...}}):
                build_success = 'True'
                Build completed successfully. All files compiled without errors.
                
                # Success Criteria:
                Task is done when analysis is complete based on CURRENT build output, doesn't matter if build_success is 'True' or 'False'.
                DO NOT use stale/cached results - always check the actual tool return value.
                NEVER report build_success = 'True' when the tool's 'success' field is False.
            """
            ),
            callback=None,
            output_pydantic=None,
            tools=devops_tools or [],
            cookbook=cookbook,
        )

    def task_fix_only_one_error_from_list(
        self,
        software_engineer: Agent,
        target_project_path: str,
        cookbook: str = None,
        text_editor_tools: list[BaseTool] = None,
    ) -> Task:
        """
        Create a task for fixing only one error from the list of build errors.
        The goal of this task is to build the project and extract errors if the build fails.

        Args:
            software_engineer (Agent): The software engineer agent responsible for the task.
            target_project_path (str): The path to the target project to be built.
            cookbook (str, optional): Additional instructions or guidelines for the task.
            devops_tools (list[BaseTool], optional): The tools/resources the agent is limited to use for this task.

        Returns:
            Task: A Task instance configured for code building.
        """
        cookbook = f"# Cookbook:\n{cookbook}" if cookbook else ""
        return Task(
            description=remove_leading_whitespaces(
                f"""
                # Prompt:
                {cookbook}
                Fix the code issues in the {target_project_path} project based on the build errors provided.
                Error details will be provided in the context.

                # MANDATORY WORKFLOW (DO NOT SKIP ANY STEP):
                
                STEP 1: Identify the error
                - Example: "cannot find symbol: variable param22 at line 404"
                - Determine: Is this a method body issue or something else?
                
                STEP 2: Read the file BEFORE making changes
                - Use: read_file(file_path="path/to/file.java")
                - Locate the problematic code
                - Understand the context
                
                STEP 3: Apply the fix using the correct tool
                - For method errors: Use replace_method with COMPLETE method code
                - For duplicate class, field, method or import declarations: Use delete_lines with precise line numbers
                - For other errors: Use edit_file with precise patch
                - The tool will save and flush the file automatically
                
                STEP 4: VERIFY the fix was saved (CRITICAL - DO NOT SKIP)
                - Use: read_file(file_path="path/to/file.java") IMMEDIATELY after the fix
                - Check that your changes are actually in the file
                - If changes are NOT present: This is a file buffer/lock issue - RETRY the fix
                - You have multiple iterations to ensure the file is properly saved
                
                STEP 5: If verification fails, RETRY the fix
                - Call the same tool again with the same parameters
                - This forces a file buffer flush and ensures persistence
                - Verify again with read_file
                
                STEP 6: Report the results
                - Tool used
                - File modified
                - What was changed
                - Confirmation that change is in the file (from read_file verification)
                - If retries were needed, mention that

                # Tool Selection Guidelines:
                1. For fixing METHODS (method901, calculateTotal, etc.):
                   - ALWAYS use `replace_method` tool (PREFERRED - safer, prevents malformed code)
                   - First use `read_file` to see the current method
                   - Then use `replace_method` with complete method code including signature and closing brace
                   - THEN use `read_file` again to verify the change was saved
                   - If NOT saved, call replace_method AGAIN (file buffer flush issue)
                   - Example: replace_method(file_path="Service.java", method_name="method901", new_method_code="complete method here")

                2. For OTHER changes (imports, fields, annotations, small line fixes):
                   - Use `read_file` to examine the file
                   - Use `edit_file` with precise patches
                   - THEN use `read_file` again to verify the change was saved
                   - If NOT saved, call edit_file AGAIN (file buffer flush issue)

                3. Always verify your changes are applied:
                   - After applying fix, use `read_file` to confirm the change is in the file
                   - Ensure file was actually modified on disk
                   - If not present, this is likely a file lock/buffer issue - RETRY the tool call
                   - You have up to 3 attempts to ensure the file is properly saved

                # IMPORTANT INSTRUCTIONS:
                ------------------------------
                - Action Input, although a JSON dictionary, must *never* be surrounded by backticks!
                It must be passed verbatim as a JSON dictionary.
                - "```json ... ```" is not allowed!!! This is critical, as the tool will not function correctly if this is done.
                - For replace_method, provide the COMPLETE method code from method signature to closing brace
                - Ensure proper indentation in the new_method_code
                - After making changes, verify they are actually written to disk using read_file
                - If verification shows changes were NOT saved, call the tool AGAIN (file buffer/lock issue)
                - The tools handle file locks internally, but retrying ensures buffers are flushed
                """
            ),
            agent=software_engineer,
            expected_output=remove_leading_whitespaces(
                f"""
                # Expected Output Format:
                Your output MUST include list of changes made to fix the build issues.
                For each fix, specify:
                - Tool used (replace_method, delete_lines or edit_file)
                - File modified (full path)
                - Method name (if replace_method was used)
                - Description of the fix
                - Number of attempts needed (if file buffer required retry)
                - VERIFICATION RESULT: Quote specific lines from read_file that prove the change is in the file
                
                Example output:
                - Tool: replace_method
                - File: {target_project_path}/src/main/java/com/dakv/sumit/BigTestService1.java
                - Method: method901
                - Fix: Changed param22 to param2 on line 404
                - Attempts: 1 (or 2 if retry was needed due to file buffer issue)
                - Verification: ✓ Read file after fix confirms line 404 now contains "param2" instead of "param22"
                
                # Success Criteria:
                Task is done when the fix is applied AND VERIFIED using read_file to confirm changes are saved to disk.
                If read_file does not show your changes after first attempt, RETRY the tool call.
                If after 3 attempts the changes still don't persist, report the file lock/buffer issue.
            """
            ),
            tools=text_editor_tools,
            callback=None,
            output_pydantic=None,
            chunking_enabled=True,
        )


def remove_leading_whitespaces(s):
    return "\n".join(line.lstrip() for line in s.splitlines())


def get_chunking_instruction_review(full_target_file_path):
    return f"""\nIMPORTANT: This is chunking mode enabled.
        It means, that you are reviewing the chunk of file only. 
        As chunk will be merged later it is important to translate ONLY input.
        
        IMPORTANT: When you need to verify the complete implementation of any method mentioned in your chunk:
        1. Use Tree Outline Tool with file_path parameter: {full_target_file_path} to get the outline of the file, which is base for Tree Query Tool.
        2. Use Tree Query Tool with file_path parameter: {full_target_file_path} and method_name parameter to get the content of the method. See the outline of the file and decide which method to query.
        3. This will retrieve the full method implementation for context and validation
        
        You MUST return your output as a valid JSON object.
        """


def get_chunking_instruction_translation():
    return """\nIMPORTANT: This is chunking mode enabled.
        It means, that you are translating the chunk of file only. 
        As chunk will be merged later it is important to translate ONLY input.
        You MUST return your output as a valid JSON object.
        """
