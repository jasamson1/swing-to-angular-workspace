import os
import json
import logging
from mcp import StdioServerParameters


def set_configured_mcp_server_params():
    """
    Loads and sets configured MCP server parameters from a JSON file if enabled via environment variable.

    Environment Variables:
        MCP_JSON_FILE_PATH (str): Path to the JSON file containing MCP server configuration.

    Sets:
        _custom_server_params_cache (global): List of server config dictionaries with 'name' and 'config' keys.
    """

    json_path = os.getenv("MCP_JSON_FILE_PATH")
    if not json_path:
        logging.info("Environment variable 'MCP_JSON_FILE_PATH' is not set. Skipping")
        return []

    if not os.path.isfile(json_path):
        logging.error(
            f"The file specified in 'MCP_JSON_FILE_PATH' does not exist: {json_path}"
        )
        return []

    try:
        with open(json_path, "r", encoding="utf-8") as f:
            json_data = json.load(f)
    except Exception as e:
        raise ValueError(f"Failed to read or parse MCP JSON file: {e}")

    return load_configured_mcp_server_params(json_data)


def get_configured_mcp_server_params():
    """
    Loads MCP server configurations.

    Returns:
        list[dict]: A combined list of MCP server configurations,
                    each represented as a dictionary with 'name' and 'config' keys.
    Raises:
        ValueError: If the required workspace environment variable is not set.
    """

    # Load configured servers if provided
    configured_servers = set_configured_mcp_server_params()
    if configured_servers:
        logging.info("All configured servers in the mcp_servers.json were loaded successfully.")


    return configured_servers


def load_configured_mcp_server_params(config: dict):
    """
    Converts a JSON configuration dictionary into a list of MCP server parameter objects.

    Each server entry in the config is converted into a dictionary with:
    - 'server_name': the server name
    - 'server_config': a StdioServerParameters object or URL-based servers (SSE or HTTP)

    Supports both stdio-based servers and URL-based servers (SSE or HTTP).

    Args:
        config (dict): The parsed JSON configuration containing MCP server definitions.

    Returns:
        list[dict]: A list of server configurations with 'server_name' and 'server_config' keys.
    """

    servers = config.get("mcp", {}).get("servers", {})
    server_objects = []

    for server_name, details in servers.items():
        if "command" in details and "args" in details:
            command = details.get("command")
            args = details.get("args", [])
            custom_env = details.get("env", {})
            env = {**os.environ, **custom_env}

            server_objects.append(
                {
                    "server_name": server_name,
                    "server_config": StdioServerParameters(
                        command=command, args=args, env=env
                    ),
                }
            )
        elif "url" in details and "transport" in details:
            server_objects.append(
                {
                    "server_name": server_name,
                    "server_config": {
                        "url": details["url"],
                        "transport": details["transport"],
                    },
                }
            )
        else:
            raise ValueError(f"Invalid server configuration for '{server_name}'")

    return server_objects
