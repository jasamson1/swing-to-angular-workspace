import os
from dotenv import load_dotenv
import logging
from genrevive.core.genrevive_crew import GenreviveCrew
from genrevive.core.base_activity import BaseActivity
from genrevive.helpers.common.logger import log_activity_execution
from genrevive.core.agent_factory import AgentFactory
from genrevive.core.task_factory import TaskFactory
from genrevive.core.mcp_connection_manager import MCPConnectionManager
from genrevive.helpers.common.tracing import set_langfuse_tracing
from genrevive.core.embedding_configuration import get_embedding_configuration
from genrevive.helpers.common.crewai_knowledge import KnowledgeFactory


class GenAIActivity(BaseActivity):
    def __init__(self):
        # Load environment variables when the class is instantiated
        load_dotenv()

        self.agents = []
        self.tasks = []
        self.crew_args = (
            {}
        )  # Dictionary to store crew configuration parameters
        self.tools = (
            MCPConnectionManager.get_connection()
        )  # Singleton Connection to MCP Server
        # Initialize AgentFactory and TaskFactory with the tools from MCP
        self.agent_factory = AgentFactory(self.tools)
        self.task_factory = TaskFactory(self.tools)
        self.setup_general_configuration()
        self.setup_cookbooks_and_prompts()
        self.setup_agents()
        self.setup_tasks()
        self.configure_crew()  # New method to configure crew parameters

    def setup_general_configuration(self):
        pass

    def setup_cookbooks_and_prompts(self):
        pass

    def setup_agents(self):
        pass

    def setup_tasks(self):
        pass

    def configure_crew(self):
        """
        Configure the CrewAI instance parameters.
        Subclasses can override this method to customize crew configuration.
        """
        # Memory reset flags (default: no reset)
        self.crew_args["reset_short_memory"] = False
        self.crew_args["reset_long_memory"] = False
        self.crew_args["reset_entity_memory"] = False
        self.crew_args["reset_knowledge"] = False
        # context length
        self.crew_args["context_length"] = os.getenv("CONTEXT_LENGTH", None)

    @log_activity_execution
    def execute(self):
        try:
            set_langfuse_tracing()  # Initialize Langfuse tracing if enabled

            if not self.agents or not self.tasks:
                logging.info(
                    "No agents or tasks defined. Skipping CrewAI execution."
                )
                return

            # Read environment variables
            training_mode = (
                os.getenv("TRAINING_MODE", "false").lower() == "true"
            )
            iterations = int(os.getenv("TRAINING_ITERATIONS", "2"))
            filename = "trained_agents_data.pkl"
            memory_enabled = (
                os.getenv("ENABLE_CREWAI_MEMORY", "false").lower() == "true"
            )
            if memory_enabled:
                try:
                    # Configure embeddings
                    self.memory_embedder = get_embedding_configuration(
                        "memory_embedder"
                    )
                    provider_name = self.memory_embedder.get(
                        "provider", "unknown"
                    )
                    logging.info(
                        f"CrewAI memory is enabled with {provider_name} embeddings"
                    )
                except Exception as e:
                    logging.warning(f"Failed to configure embeddings: {e}")
                    logging.info("Continuing without memory functionality")
                    memory_enabled = False
            else:
                logging.info("CrewAI memory is disabled")

            crew_knowledge_sources = KnowledgeFactory().get_crew_knowledge()

            # Extract memory reset configuration
            reset_short_memory = self.crew_args.pop(
                "reset_short_memory", False
            )
            reset_long_memory = self.crew_args.pop("reset_long_memory", False)
            reset_entity_memory = self.crew_args.pop(
                "reset_entity_memory", False
            )
            reset_knowledge = self.crew_args.pop("reset_knowledge", False)
            crew_embedder = (
                getattr(self, "memory_embedder", None)
                if memory_enabled or crew_knowledge_sources
                else None
            )

            # Initialize the Crew object
            crew = GenreviveCrew(
                agents=self.agents,
                tasks=flatten_tasks(self.tasks),
                knowledge_sources=crew_knowledge_sources,
                verbose=True,
                memory=memory_enabled,
                embedder=crew_embedder,
                **self.crew_args,
            )

            # Handle training or execution mode
            result = None
            if training_mode:
                if not hasattr(crew, "train"):
                    raise NotImplementedError(
                        "'Crew' object does not have a 'train' method."
                    )
                logging.info(
                    f"Starting training with {iterations} iterations."
                )
                result = crew.train(n_iterations=iterations, filename=filename)
            else:
                logging.info("Starting task execution.")
                result = crew.kickoff()

            # Handle selective memory reset based on configuration
            if memory_enabled:
                memory_types_to_reset = []
                if reset_short_memory:
                    memory_types_to_reset.append("short")
                if reset_long_memory:
                    memory_types_to_reset.append("long")
                if reset_entity_memory:
                    memory_types_to_reset.append("entity")
                if reset_knowledge:
                    memory_types_to_reset.append("knowledge")

                if memory_types_to_reset:
                    logging.info(
                        f"Resetting memory types: {', '.join(memory_types_to_reset)}"
                    )
                    for memory_type in memory_types_to_reset:
                        try:
                            crew.reset_memories(command_type=memory_type)
                            logging.info(
                                f"Memory type '{memory_type}' reset successfully"
                            )
                        except Exception as e:
                            logging.warning(
                                f"Failed to reset memory type '{memory_type}': {e}"
                            )
                else:
                    logging.info("No memory types selected for reset")

            return result
        except Exception as e:
            logging.error(
                f"An error occurred during the execution of the activity: {e}",
                exc_info=True,
            )
            raise


def flatten_tasks(tasks):
    flattened = []
    for task in tasks:
        if isinstance(task, list):
            flattened.extend(flatten_tasks(task))
        else:
            flattened.append(task)
    return flattened
