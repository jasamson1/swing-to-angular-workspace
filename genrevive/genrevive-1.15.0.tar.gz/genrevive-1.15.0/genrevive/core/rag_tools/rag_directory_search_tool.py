import logging
from typing import Any, Optional
import os
import glob
from crewai_tools import RagTool
from crewai_tools.rag.data_types import DataType
from pydantic import BaseModel
from genrevive.core.embedding_configuration import get_embedding_configuration
from genrevive.core.llm_configuration import get_llm_provider_config


def _int_env(var: str, default: int = 100) -> int:
    val = os.environ.get(var)
    if val is None or val.strip() == "":
        return default
    try:
        return int(val)
    except ValueError:
        logging.warning(f"Invalid int for {var}='{val}', using default={default}")
        return default


class DirectorySearchInput(BaseModel):
    query: str

def rag_directory_search_tool(
    directory: str,
    file_extensions: list[str] = None,
    llm_configuration: Optional[dict[str, Any]] = None,
) -> RagTool:
    if not os.path.exists(directory):
        raise FileNotFoundError(f"Directory not found: {directory}")

    llm = get_llm_provider_config(llm_configuration)
    embedder = get_embedding_configuration("rag_embedder")


    
    config = {
        "provider": os.environ.get("VECTOR_STORE_PROVIDER", "chromadb"),  # MUST be chromadb or qdrant
        "config": {
            "llm": llm,
            "embedding_model": embedder,
            "chunker": {
                "chunk_size": _int_env("CHUNK_SIZE", 800),
                "chunk_overlap": _int_env("CHUNK_OVERLAP", 80),
                "min_chunk_size": _int_env("MIN_CHUNK_SIZE", 100),
            },
            "vectordb": {
                "provider": os.environ.get("VECTOR_STORE_PROVIDER", "chromadb"),
                "config": {
                    "dir": os.environ.get("VECTOR_STORE_PERSIST_DIRECTORY", "db"),
                    "batch_size": int(os.environ.get("VECTOR_STORE_BATCH_SIZE", 100)),
                    "allow_reset": os.environ.get("VECTOR_STORE_ALLOW_RESET", "false").lower() == "true",
                },
            },
        },
    }





    tool = RagTool(
        name="directory_search",
        description="Searches a directory using RAG (PDF, text, Java, XML, etc.).",
        args_schema=DirectorySearchInput,
        return_direct=True,
        config=config,    # now correct shape for crewai_tools
    )


    # Load files
    if file_extensions:
        for ext in file_extensions:
            for file_path in glob.glob(
                os.path.join(directory, f"**/*{ext}"), recursive=True
            ):
                tool.add(file_path)
    else:
        tool.add(directory, data_type=DataType.DIRECTORY)
        for pdf_file in glob.glob(os.path.join(directory, "**/*.pdf"), recursive=True):
            tool.add(pdf_file, data_type=DataType.PDF_FILE)

    return tool
