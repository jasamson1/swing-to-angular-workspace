import os
from typing import Any, Optional
from dotenv import load_dotenv
from crewai import LLM


def get_llm(**kwargs):
    load_dotenv()

    agent_model = os.environ["AGENT_MODEL"]

    return LLM(model=agent_model, **kwargs)


def get_llm_provider_config(kwargs_dict: Optional[dict[str, Any]] = None):
    load_dotenv()
    llm_provider = os.environ.get("LLM_PROVIDER")

    if not llm_provider:
        raise ValueError("LLM_PROVIDER environment variable is not set.")

    return _get_provider_config(
        llm_provider, os.environ.get("AGENT_MODEL"), kwargs_dict
    )


def _get_provider_config(
    provider: str, model: str, kwargs_dict: Optional[dict[str, Any]] = None
):
    if not kwargs_dict:
        return dict(
            provider=provider,
            config=dict(
                model=model,
            ),
        )

    return dict(
        provider=provider,
        config=dict(model=model, **kwargs_dict),
    )
