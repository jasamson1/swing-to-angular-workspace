from textwrap import dedent
from typing import Any, Optional, Type
from pydantic import BaseModel
from crewai.tools import BaseTool
from crewai import Task, Agent
from typing import List, Union
from crewai.utilities.constants import NOT_SPECIFIED, _NotSpecified
from genrevive.core.intelligent_chunking import IntelligentChunking
from genrevive.helpers.intelligent_chunking.chunking_callbacks import (
    ChunkingCallbacks,
)
from genrevive.helpers.intelligent_chunking.repository.repository_origin import (
    RepositoryOrigin,
)
from genrevive.helpers.intelligent_chunking.tools.tree_sitter_query_tool import (
    TreeQueryTool,
)
from genrevive.helpers.intelligent_chunking.tools.tree_sitter_outline_tool import (
    TreeOutlineTool,
)
from pathlib import Path

from genrevive.helpers.intelligent_chunking.tools.consolidation_tool import (
    ConsolidationTool,
)
from genrevive.helpers.intelligent_chunking.repository.repository_se import (
    RepositorySE,
)
from genrevive.helpers.intelligent_chunking.repository.repository_sr import (
    RepositorySR,
)


class ChunkedTaskCreator:
    def create_chunked_translation_tasks(
        self,
        agent: Agent,
        prompt: str,
        cookbook: str,
        input: dict,
        target_technology_names: list[str],
        target_file_path: str,
        other_instructions: str = "",
        merged_tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        expected_output: Optional[str] = None,
    ) -> list[Task]:
        """Create chunked translation tasks for software engineering (SE) role."""

        if not isinstance(input, dict):
            raise ValueError(
                "Input must be a dict with 'filename' and 'content' keys when chunking is enabled. Avoid using MarkdownRenderer here."
            )

        target_filename = input["filename"]
        code = input["content"]

        # Generate chunks for translation
        intelligent_chunking = IntelligentChunking()
        chunks: list[dict[str, Any]] = intelligent_chunking.chunk_input(
            input_text=code,
            filename=target_filename,
            target_file_path=target_file_path,
            role="se",
        )

        return self._create_chunked_tasks_common(
            agent=agent,
            prompt=prompt,
            cookbook=cookbook,
            chunks=chunks,
            target_filename=target_filename,
            target_file_path=target_file_path,
            role="se",
            repository_class=RepositorySE,
            task_config={
                "target_technology_names": target_technology_names,
                "other_instructions": other_instructions,
                "merged_tools": merged_tools,
                "output_pydantic": output_pydantic,
                "expected_output": expected_output,
                "chunking_instruction": get_chunking_instruction_translation(),
            },
        )

    def _create_chunked_review_tasks(
        self,
        agent: Agent,
        prompt: str,
        cookbook: str,
        input: dict,
        target_technology_names: list[str],
        target_file_path: str,
        other_instructions: str = "",
        merged_tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        expected_output: Optional[str] = None,
    ) -> list[Task]:
        """Create chunked review tasks for software reviewer (SR) role."""

        if not isinstance(input, dict):
            raise ValueError(
                "Input must be a dict with 'filename' and 'content' keys when chunking is enabled. Avoid using MarkdownRenderer here."
            )

        # Add tree tools for review
        merged_tools = merged_tools or []
        merged_tools.append(TreeQueryTool())
        merged_tools.append(TreeOutlineTool())

        target_filename = input["filename"]
        full_target_file_path = str(Path(target_file_path) / target_filename)

        # Get chunks from repository for review
        origin_repo = RepositoryOrigin()
        chunks = origin_repo.get_chunks_by_target_filepath_full(
            full_target_file_path
        )

        return self._create_chunked_tasks_common(
            agent=agent,
            prompt=prompt,
            cookbook=cookbook,
            chunks=chunks,
            target_filename=target_filename,
            target_file_path=target_file_path,
            role="sr",
            repository_class=RepositorySR,
            task_config={
                "target_technology_names": target_technology_names,
                "other_instructions": other_instructions,
                "merged_tools": merged_tools,
                "output_pydantic": output_pydantic,
                "expected_output": expected_output,
                "chunking_instruction": get_chunking_instruction_review(
                    full_target_file_path
                ),
            },
        )

    def _create_chunked_tasks_common(
        self,
        agent: Agent,
        prompt: str,
        cookbook: str,
        chunks: list[dict[str, Any]],
        target_filename: str,
        target_file_path: str,
        role: str,
        repository_class: Type,
        task_config: dict,
    ) -> list[Task]:
        """
        Common logic for creating chunked tasks for both SE and SR roles.

        Args:
            task_config: Dict containing 'target_technology_names', 'other_instructions',
                        'merged_tools', 'output_pydantic', 'expected_output', 'chunking_instruction'
        """

        chunking_prompt = prompt + task_config["chunking_instruction"]
        tasks = []
        chunking_callbacks = ChunkingCallbacks().save_code_blocks

        for idx, chunk in enumerate(chunks):
            chunk_expected_output = (
                task_config.get("expected_output")
                if task_config.get("expected_output") is not None
                else self.__generate_chunk_expected_output(
                    task_config["target_technology_names"],
                    idx,
                    chunk,
                    target_filename,
                    target_file_path,
                )
            )

            tasks.append(
                self.__task_code_generation(
                    agent=agent,
                    prompt=chunking_prompt,
                    cookbook=cookbook,
                    input=chunk["content"],
                    target_technology_names=task_config[
                        "target_technology_names"
                    ],
                    target_file_path=target_file_path,
                    callback=chunking_callbacks,
                    context=[],
                    other_instructions=task_config.get("other_instructions"),
                    tools=task_config.get("merged_tools"),
                    output_pydantic=task_config.get("output_pydantic"),
                    expected_output=chunk_expected_output,
                )
            )

        # Add consolidation task
        full_target_file_path = str(Path(target_file_path) / target_filename)
        consolidate_task = Task(
            description=(
                f"Call the tool consolidation_tool with target_filepath_full='{full_target_file_path}' and agent='{role}'"
            ),
            agent=agent,
            tools=[ConsolidationTool(repository=repository_class())],
            expected_output="Output of the tool 'consolidation_tool'",
            context=[]
        )

        tasks.append(consolidate_task)
        return tasks

    def __task_code_generation(
        self,
        agent: Agent,
        prompt: str,
        cookbook: str,
        input: str,
        target_technology_names: list[str],
        target_file_path: str,
        callback: any,
        other_instructions: str = None,
        tools: list[BaseTool] = None,
        output_pydantic: Optional[Type[BaseModel]] = None,
        expected_output: Optional[str] = None,
        context: Optional[
            Union[List["Task"], None, _NotSpecified]
        ] = NOT_SPECIFIED,
    ) -> Task:
        """
        Create a task for code generation by an agent.

        Args:
            agent (Agent): The agent responsible for the task.
            prompt (str): The prompt for the agent.
            input (str): The input code or information to be translated.
            cookbook (str): The cookbook containing reference information.
            target_technology_names (list[str]): The technology names to which the code is being translated.
            target_file_path (str): The path where the translated code should be saved.
            callback (any): Callback to be executed after the task is completed.
            other_instructions (str): Other instructions for the agent.
            tools (list[BaseTool]): The tools/resources the agent is limited to use for this task.
            output_pydantic (Optional[Type[BaseModel]]): A Pydantic model for task output.
            expected_output (Optional[str]): A detailed description of what the task’s completion looks like.
        Returns:
            Task: A Task instance configured for code generation.
        """

        other_instructions_str = (
            f"# Other instructions:\n{other_instructions}"
            if other_instructions is not None
            else ""
        )

        return Task(
            description=remove_leading_whitespaces(f"""
                # Prompt:
                {prompt}                
                # Cookbook:
                {cookbook}
                # Input:
                {input}
                {other_instructions_str}
                """),
            agent=agent,
            context=context,
            expected_output=(
                remove_leading_whitespaces(expected_output)
                if expected_output is not None
                else remove_leading_whitespaces(f"""
                Runnable {",".join(target_technology_names)} Code
                Put "# filename: {target_file_path}/<filename>" inside each code block as first line.
                The output must look like:                
                {self.__get_code_block_sting(target_technology_names, target_file_path)}
                ```markdown
                    # filename: {target_file_path}/<filename>.md
                    <changelog>
                ```
                """)
            ),
            callback=callback,
            tools=tools or [],
            output_pydantic=output_pydantic,
        )

    @staticmethod
    def __generate_chunk_expected_output(
        target_technology_names, idx, chunk, target_filename, target_file_path
    ) -> str:
        return dedent(f"""
            Return a valid JSON object with these fields:
            {{
                "code": "<your translated {",".join(target_technology_names)} code here>",
                "chunk_idx": {idx},
                "origin_chunk_id": "{chunk["chunk_id"]}",
                "filename": "{target_filename}",
                "target_filepath_full": "{target_file_path}/{target_filename}"
            }}
            
            CRITICAL: Return ONLY valid JSON. The 'code' field must contain the translated code as a properly escaped string.

            Additionally, after the JSON, provide a markdown changelog in the following format:

            ```markdown
                # filename: {target_file_path}/{target_filename}.md
                <changelog>
            ```
            """)


def get_chunking_instruction_review(full_target_file_path):
    return f"""\nIMPORTANT: This is chunking mode enabled.
        It means, that you are reviewing one chunk of file only. 
        As the chunks will be merged later on, it is important to translate ONLY the given input.
        
        IMPORTANT: When you need to verify the complete implementation of any method mentioned in your chunk:
        1. Use Tree Outline Tool with file_path parameter: {full_target_file_path} to get the outline of the file, which is base for Tree Query Tool.
        2. Use Tree Query Tool with file_path parameter: {full_target_file_path} and method_name parameter to get the content of the method. See the outline of the file and decide which method to query.
        3. This will retrieve the full method implementation for context and validation
        
        You MUST return your output as a valid JSON object.
        """


def get_chunking_instruction_translation():
    return """\nIMPORTANT: This is chunking mode enabled.
        It means, that you are translating one chunk of file only. 
        As the chunks will be merged later on, it is important to translate ONLY the given input.
        DO NOT add any additional code, comments, or explanations that are not part of the translation of the given chunk.
        Focus on translating the provided code chunk as accurately and efficiently as possible, without making assumptions about the content of other chunks or the overall file structure.
        DO NOT balance or match brackets if they are not balanced in the input chunk. Translate the chunk as-is, even if it means that some code blocks may be incomplete. 
        The consolidation step will handle merging and balancing of the complete file.
        You MUST return your output as a valid JSON object.
        """


def remove_leading_whitespaces(s):
    return "\n".join(line.lstrip() for line in s.splitlines())
