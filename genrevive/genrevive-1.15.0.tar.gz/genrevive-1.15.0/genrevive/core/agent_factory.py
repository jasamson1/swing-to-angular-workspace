import os
from textwrap import dedent
from crewai import Agent
from typing import Any, Optional, List
from genrevive.core.llm_configuration import get_llm
from genrevive.helpers.common.crewai_knowledge import KnowledgeFactory
from genrevive.helpers.common.system_prompts_loader import (
    load_system_prompts_templates,
)
from genrevive.helpers.common.merge_tools import (
    get_merged_tools_for_agent_type,
)
from genrevive.helpers.common.file_utils import FileUtils


class AgentFactory:
    """Factory class to create various types of tasks for different roles.

    Class Attributes:
        _default_mcp_tools (list):
            Class variable to hold the default list of MCP tools.
            This is shared across all instances of AgentFactory and is used as a fallback.
            It should be initialized early (e.g., after connecting to the MCP server).

            Note:
                Existing migrators may call tasks as AgentFactory().agent*,
                which will override this default tools for that specific call. This class-level default ensures
                backward compatibility and provides a consistent fallback for cases where tools are not
                passed explicitly.
    """

    _default_mcp_tools = []

    def __init__(self, tools: Optional[list] = None, embedder=None):
        """
        Initialize the AgentFactory with a list of MCP tools.

        Args:
            tools (Optional[list]):
                A list of tools (typically MCP tools) that will be available to all agents created by this factory.
                Pass the tools obtained from the MCP server connection.
                If not provided, the factory will initialize with an empty toolset.

        Note:
            Migrator developers should pass the list of tools that agents may require for their tasks,
            such as those returned by the MCPServerAdapter. This ensures agents have access to the necessary
            capabilities for code migration, review, or DevOps operations.
        """
        if tools is not None:
            AgentFactory._default_mcp_tools = tools

        self.embedder = (
            embedder or KnowledgeFactory.get_global_embedder_config()
        )

    def software_engineer(
        self,
        origin_technology: str,
        target_technology: str,
        origin_input: str,
        target_output: str,
        tools: list,
        knowledge_sources: Optional[List] = None,
        llm=None,  # default value is None, but can be overwritten with a custom LLM object
        **llm_kwargs,  # added arguments, e.g. temperature, can be adjusted per agent
    ) -> Agent:
        """
        Create an agent with a software engineer role.

        Args:
            origin_technology (str): The origin technology.
            target_technology (str): The target technology.
            origin_input (str): Input related to the origin technology.
            target_output (str): Desired output related to the target technology.
            tools (list): A list of tools the agent can use.

        Returns:
            Agent: An instance of the Agent class configured as a Software Engineer.
        """
        system_template, prompt_template = load_system_prompts_templates("SE")

        if not llm:
            llm = get_llm(
                **llm_kwargs
            )  # default LLM if not overwritten by migrator

        if knowledge_sources is None:
            knowledge_sources = (
                KnowledgeFactory.get_multiple_knowledge_from_env(
                    "SE_KNOWLEDGE_PATH",
                    "ENABLE_SE_KNOWLEDGE",
                    embedder=self.embedder,
                )
            )

        merged_tools = get_merged_tools_for_agent_type(
            AgentFactory._default_mcp_tools, tools, "SE"
        )

        return Agent(
            role="Software Engineer",
            backstory=dedent(
                f"""
                You are a seasoned software engineer specializing in {origin_technology} and {target_technology},
                recognized for your deep expertise and years of experience.
                Leveraging your knowledge, you authored a comprehensive cookbook detailing the migration process
                from {origin_technology} to {target_technology}. You excel at refactoring and improving code.
                """
            ),
            goal=dedent(
                f"""
                Generate {target_output} either from provided {origin_input} or
                by refactoring your previous code using feedback or error messages from other agents.
                """
            ),
            allow_delegation=False,
            knowledge_sources=knowledge_sources or [],
            embedder=self.embedder,
            verbose=True,
            system_template=system_template,
            prompt_template=prompt_template,
            llm=llm,
            tools=merged_tools,
        )

    def software_reviewer(
        self,
        target_technology: str,
        tools: list,
        knowledge_sources: Optional[List] = None,
        llm=None,  # default value is None, but can be overwritten with a custom LLM object
        **llm_kwargs,  # added arguments, e.g. temperature, can be adjusted per agent
    ) -> Agent:
        """
        Create an agent with a software reviewer role.

        Args:
            target_technology (str): The technology for which code review is required.
            tools (list): A list of tools the agent can use.

        Returns:
            Agent: An instance of the Agent class configured as a Software Reviewer.
        """
        system_template, prompt_template = load_system_prompts_templates("SR")

        if not llm:
            llm = get_llm(
                **llm_kwargs
            )  # default LLM if not overwritten by migrator

        if knowledge_sources is None:
            knowledge_sources = (
                KnowledgeFactory.get_multiple_knowledge_from_env(
                    "SR_KNOWLEDGE_PATH",
                    "ENABLE_SR_KNOWLEDGE",
                    embedder=self.embedder,
                )
            )

        merged_tools = get_merged_tools_for_agent_type(
            AgentFactory._default_mcp_tools, tools, "SR"
        )

        return Agent(
            role="Software Reviewer",
            backstory=dedent(
                f"""
                You are an expert in {target_technology} application development.
                You possess deep knowledge of {target_technology} best practices and coding standards.
                Your role is to ensure that the {target_technology} code adheres to these standards and is free of errors.
                """
            ),
            goal=dedent(
                f"""
                Improve and correct {target_technology} code to adhere to best practices and standards, providing a short 
                overview of improvements made.
                """
            ),
            allow_delegation=False,
            knowledge_sources=knowledge_sources or [],
            embedder=self.embedder,
            verbose=True,
            system_template=system_template,
            prompt_template=prompt_template,
            llm=llm,
            tools=merged_tools,
        )

    def devops_engineer(
        self,
        target_technology: str,
        compiler_technology: str,
        tools: list,
        knowledge_sources: Optional[List] = None,
        llm=None,  # default value is None, but can be overwritten with a custom LLM object
        **llm_kwargs,  # added arguments, e.g. temperature, can be adjusted per agent
    ) -> Agent:
        """
        Create an agent with a DevOps engineer role.

        Args:
            target_technology (str): The technology for which DevOps processes are to be applied.
            compiler_technology (str): The technology used for compiling the code.
            tools (list): A list of tools the agent can use.

        Returns:
            Agent: An instance of the Agent class configured as a DevOps Engineer.
        """
        system_template, prompt_template = load_system_prompts_templates("DE")

        if not llm:
            llm = get_llm(
                **llm_kwargs
            )  # default LLM if not overwritten by migrator

        if knowledge_sources is None:
            knowledge_sources = (
                KnowledgeFactory.get_multiple_knowledge_from_env(
                    "DEVOPS_KNOWLEDGE_PATH",
                    "ENABLE_DEVOPS_KNOWLEDGE",
                    embedder=self.embedder,
                )
            )

        merged_tools = get_merged_tools_for_agent_type(
            AgentFactory._default_mcp_tools, tools, "DE"
        )

        return Agent(
            role="DevOps Engineer",
            backstory=dedent(
                f"""
                You are an expert in the continuous integration and continuous deployment
                of {target_technology} projects with {compiler_technology}. You review and check {target_technology} code.
                """
            ),
            goal=dedent(
                f"""
                Prepare {target_technology} code that is error-free and clean so that the {target_technology} project
                can be built successfully using the {tools}.
                """
            ),
            tools=merged_tools,
            allow_delegation=True,
            knowledge_sources=knowledge_sources or [],
            embedder=self.embedder,
            verbose=True,
            system_template=system_template,
            prompt_template=prompt_template,
            llm=llm,
        )

    def _read_documents_for_migration_expert(self):
        base_dir = os.path.join(
            os.path.dirname(__file__), "migration", "migration_expert"
        )
        current_abilities = FileUtils.read_file(
            os.path.join(base_dir, "current_genrevive_abilities.md")
        )
        example_activities = FileUtils.read_file(
            os.path.join(base_dir, "example_activities.md")
        )
        example_tasks = FileUtils.read_file(
            os.path.join(base_dir, "example_migration_expert_tasks.md")
        )

        return {
            "current_abilities": current_abilities,
            "example_activities": example_activities,
            "example_tasks": example_tasks,
        }

    def migration_expert(
        self,
        origin_technology: str,
        target_technology: str,
        tools: list,
        knowledge_sources: Optional[List] = None,
        llm=None,  # default value is None, can be overwritten with a
        # custom LLM object
        **llm_kwargs,  # added arguments, e.g. temperature, can be adjusted
        # per agent
    ) -> Agent:
        """
        Create an agent with a migration expert role.

        Returns:
            Agent: An instance of the Agent class configured as a Migration Expert.
        """
        system_template, prompt_template = load_system_prompts_templates("ME")

        if not llm:
            llm = get_llm(
                **llm_kwargs
            )  # default LLM if not overwritten by migrator

        merged_tools = get_merged_tools_for_agent_type(
            AgentFactory._default_mcp_tools, tools, "ME"
        )

        documents = self._read_documents_for_migration_expert()

        return Agent(
            role="Migration Expert",
            backstory=dedent(
                f"""
                You are a senior developer of technology {origin_technology} having knowledge of 
                technologies, libraries and frameworks described in input_architecture AND
                You are a senior developer of technology {target_technology} having knowledge of
                technologies, libraries and frameworks described in output_architecture.
                Additionally you understand how architectural models for input and output 
                applications work.
                
                In your previous work, you created the following examples to guide developers through the migration process:
                {documents["example_activities"]}

                You are also aware of what Genrevive abilities are:
                {documents["current_abilities"]}

                When creating the list of tasks, you can use these example task as a template:
                {documents["example_tasks"]}

                In output document, remember to not use Unicode characters, only use plain ASCII characters.

                What is really important, task should be very technical and dedicated for an output technology developer.
                """
            ),
            goal=dedent(
                """
                The goal is to create migration activities which you can learn what they are 
                from the genrevive and migrator template.
                Prepare a migration plan based on GenRevive framework, containing list of
                proposals of BaseActivity or GenAiActivity ABSTRACT (not fully implemented) 
                classes with suggestions in the comments what external CLIs or libraries 
                should be used for implementation and what prompts can be used inside 
                implementations of GenAIBased clases.

                While doing this, follow this structure:

                activity name
                activity type (is it base activity or gen ai activity) 
                goal
                implementation details (what need to be done to achieve the goal)
                helpers/utilities (describe what can be used within the activity, such as genRevive helpers, tools, MCPs)                 
                """
            ),
            allow_delegation=False,
            knowledge_sources=knowledge_sources or [],
            embedder=self.embedder,
            verbose=True,
            system_template=system_template,
            prompt_template=prompt_template,
            llm=llm,
            tools=merged_tools,
        )

    def migrator_developer(
        self,
        origin_technology: str,
        target_technology: str,
        tools: list,
        knowledge_sources: Optional[List] = None,
        llm=None,  # default value is None, can be overwritten with a
        # custom LLM object
        **llm_kwargs,  # added arguments, e.g. temperature, can be adjusted
        # per agent
    ) -> Agent:
        """
        Create an agent with a migrator developer role.

        Returns:
            Agent: An instance of the Agent class configured as a Migrator Developer.
        """
        system_template, prompt_template = load_system_prompts_templates("MD")

        if not llm:
            llm = get_llm(
                **llm_kwargs
            )  # default LLM if not overwritten by migrator

        merged_tools = get_merged_tools_for_agent_type(
            AgentFactory._default_mcp_tools, tools, "MD"
        )

        return Agent(
            role="Migration Developer",
            backstory=dedent(
                f"""
                You are a senior developer of technology {origin_technology} having knowledge of technologies, libraries and frameworks described in input_architecture AND
                You are a senior developer of technology {target_technology} having knowledge of technologies, libraries and frameworks described in output_architecture.
                Additionally you understand how architectural models for input and output applications work.
                """
            ),
            goal=dedent(
                """
                Create rough, incomplete migration activity implementations as starting points 
                for migrator developers.
                These are NOT complete, production-ready implementations, but rather 
                scaffolding and guidance for human developers.
                Prepare a migration plan based on GenRevive framework, containing proposals of BaseActivity or GenAiActivity classes with:
                - Basic structure and method signatures
                - TODO comments indicating what needs to be implemented
                - Implementation hints and suggestions for external CLIs, libraries, and tools
                - Comments explaining the logic flow and key implementation points
                - Prompts suggestions for GenAI-based activities

                The output should serve as a development template that human migrator developers can use to:
                - Understand the required activity structure
                - See what methods and functionality need to be implemented
                - Get guidance on which tools and libraries to use
                - Have clear TODOs for actual implementation work 
                """
            ),
            allow_delegation=False,
            knowledge_sources=knowledge_sources or [],
            embedder=self.embedder,
            verbose=True,
            system_template=system_template,
            prompt_template=prompt_template,
            llm=llm,
            tools=merged_tools,
        )

    def bug_fixer_se(
        self,
        tools: list,
        embedder: Any = None,
        system_template: str = None,
        prompt_template: str = None,
        **llm_kwargs,
    ) -> Agent:
        return Agent(
            role="Software Engineer",
            backstory=dedent(
                """
                You are a seasoned software engineer specializing in Java Spring Boot applications.
                Recognized for your deep expertise and years of experience.
                You excel at fixing issues and improving code.
                You understand the importance of using the right tool for the right job.
                CRITICAL: You MUST verify that every change you make is actually written to disk by reading the file after modifications.
                """
            ),
            goal=dedent(
                """
                Your goal is to correct ONE build error so that the Java Spring Boot project can be built successfully.
                You are responsible for fixing only one code issue based on build errors taken from the top of the list.
                Don't try to fix multiple issues at once.
                """
            ),
            allow_delegation=False,
            knowledge_sources=[],
            embedder=embedder,
            verbose=True,
            system_template=system_template,
            prompt_template=prompt_template,
            llm=get_llm(**llm_kwargs),
            tools=tools,
        )
