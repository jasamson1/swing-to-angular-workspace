"""
Standalone Text Editor Tool - adapted from mcp-text-editor without MCP dependency.
Provides file editing operations with hash-based conflict detection.
"""

import hashlib
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


class EditPatch(BaseModel):
    """Model for a single edit patch operation."""

    start: int = Field(1, description="Starting line for edit (1-based)")
    end: Optional[int] = Field(
        None, description="Ending line for edit (inclusive, None = EOF)"
    )
    contents: str = Field(..., description="New content to insert")
    range_hash: Optional[str] = Field(
        None, description="Hash of content being replaced"
    )


class TextEditorService:
    """
    Standalone text file editor with hash-based conflict detection.

    Features:
    - Read file contents (full or range)
    - Edit file with patches (insert, replace, delete)
    - Hash-based conflict detection
    - Safe path validation
    """

    def __init__(self, allowed_directories: Optional[List[str]] = None):
        """
        Initialize TextEditorTool.

        Args:
            allowed_directories: List of allowed base directories for file operations.
                                If None, uses current working directory.
        """
        self.allowed_directories = allowed_directories or [os.getcwd()]
        self._validate_allowed_directories()

    def _validate_allowed_directories(self):
        """Validate that allowed directories exist and are absolute paths."""
        validated = []
        for d in self.allowed_directories:
            path = Path(d).resolve()
            if not path.exists():
                logger.warning(f"Allowed directory does not exist: {d}")
            validated.append(str(path))
        self.allowed_directories = validated

    def _validate_file_path(self, file_path: str) -> str:
        """
        Validate if file path is within allowed directories.

        Args:
            file_path: Path to validate

        Returns:
            Absolute validated path

        Raises:
            ValueError: If path is outside allowed directories
        """
        abs_path = Path(file_path).resolve()

        # Check if path is within any allowed directory
        for allowed_dir in self.allowed_directories:
            try:
                abs_path.relative_to(allowed_dir)
                return str(abs_path)
            except ValueError:
                continue

        raise ValueError(
            f"Path '{file_path}' is not within allowed directories: {self.allowed_directories}"
        )

    @staticmethod
    def calculate_hash(content: str) -> str:
        """
        Calculate SHA-256 hash of content.

        Args:
            content: Content to hash

        Returns:
            Hex digest of SHA-256 hash
        """
        return hashlib.sha256(content.encode()).hexdigest()

    def read_file(
        self,
        file_path: str,
        start: int = 1,
        end: Optional[int] = None,
        max_lines: int = 30,
        encoding: str = "utf-8",
    ) -> Dict[str, Any]:
        """
        Read file contents with optional line range.

        Args:
            file_path: Path to the file
            start: Starting line number (1-based, default: 1)
            end: Ending line number (inclusive, None = EOF)
            max_lines: Maximum lines to return (default: 30)
            encoding: File encoding (default: utf-8)

        Returns:
            Dictionary with:
                - result: "ok" or "error"
                - contents: File content string (if successful)
                - file_hash: SHA-256 hash of entire file (if successful)
                - total_lines: Total lines in file (if successful)
                - reason: Error message (if failed)
        """
        validated_path = self._validate_file_path(file_path)

        try:
            with open(validated_path, "r", encoding=encoding) as f:
                lines = f.readlines()
        except FileNotFoundError:
            raise FileNotFoundError(f"File not found: {file_path}")
        except UnicodeDecodeError as e:
            raise UnicodeDecodeError(
                encoding,
                e.object,
                e.start,
                e.end,
                f"Failed to decode file '{file_path}' with {encoding} encoding",
            )

        total_lines = len(lines)
        file_content = "".join(lines)
        file_hash = self.calculate_hash(file_content)

        # Normalize range
        start = max(1, start) - 1  # Convert to 0-based
        end = total_lines if end is None else min(end, total_lines)

        # Apply max_lines limit
        if end - start > max_lines:
            end = start + max_lines

        if start >= total_lines:
            return {
                "result": "ok",
                "contents": "",
                "file_hash": file_hash,
                "total_lines": total_lines,
            }

        selected_lines = lines[start:end]
        numbered_lines = [  
            {"line": start + i + 1, "content": line.rstrip()}  
            for i, line in enumerate(selected_lines)  
        ]  
        content = numbered_lines 

        return {
            "result": "ok",
            "contents": content,
            "file_hash": file_hash,
            "total_lines": total_lines,
        }

    def edit_file(
        self,
        file_path: str,
        expected_file_hash: Optional[str],
        patches: List[Dict[str, Any]],
        encoding: str = "utf-8",
        create_if_missing: bool = False,
    ) -> Dict[str, Any]:
        """
        Edit file contents with hash-based conflict detection.

        Args:
            file_path: Path to the file
            expected_file_hash: Expected hash of entire file (for conflict detection). None = skip validation.
            patches: List of patches, each with:
                - start: Starting line (1-based)
                - end: Ending line (inclusive, None = EOF)
                - contents: New content
                - range_hash: Expected hash of content being replaced
            encoding: File encoding
            create_if_missing: Create file if it doesn't exist

        Returns:
            Dictionary with:
                - result: "ok" or "error"
                - new_hash: New file hash (if successful)
                - reason: Error message (if failed)
        """
        validated_path = self._validate_file_path(file_path)

        # Debug logging
        logger.info(
            f"TextEditorService.edit_file called with expected_file_hash={expected_file_hash}"
        )

        try:
            with open(validated_path, "r", encoding=encoding) as f:
                lines = f.readlines()
            file_content = "".join(lines)
            current_hash = self.calculate_hash(file_content)

            logger.info(
                f"TextEditorService: current_hash={current_hash}, expected_file_hash={expected_file_hash}, will skip validation: {expected_file_hash is None}"
            )

            # Skip hash validation if expected_file_hash is None
            if (
                expected_file_hash is not None
                and current_hash != expected_file_hash
            ):
                return {
                    "result": "error",
                    "reason": f"File hash mismatch. Expected: {expected_file_hash}, got: {current_hash}",
                    "current_hash": current_hash,
                }

        except FileNotFoundError:
            if not create_if_missing:
                return {
                    "result": "error",
                    "reason": f"File not found: {file_path}",
                }
            lines = []
            file_content = ""
            current_hash = self.calculate_hash(file_content)

            # Skip hash validation if expected_file_hash is None
            if (
                expected_file_hash is not None
                and expected_file_hash != current_hash
            ):
                return {
                    "result": "error",
                    "reason": "File does not exist, but expected_file_hash does not match empty file hash",
                }

        # Sort patches by start line (descending) to apply from bottom to top
        parsed_patches = [EditPatch(**p) for p in patches]
        parsed_patches.sort(
            key=lambda p: (p.start, p.end if p.end else float("inf")),
            reverse=True,
        )

        # Apply patches
        total_lines = len(lines)
        for patch in parsed_patches:
            start = max(1, patch.start) - 1  # 0-based
            end = (
                total_lines
                if patch.end is None
                else min(patch.end, total_lines)
            )

            # Verify range hash if provided
            if patch.range_hash is not None:
                selected_lines = lines[start:end]
                range_content = "".join(selected_lines)
                range_hash = self.calculate_hash(range_content)

                if range_hash != patch.range_hash:
                    return {
                        "result": "error",
                        "reason": f"Range hash mismatch at lines {patch.start}-{patch.end}. Expected: {patch.range_hash}, got: {range_hash}",
                    }

            # Apply patch
            new_lines = patch.contents.splitlines(keepends=True)
            if new_lines and not new_lines[-1].endswith("\n"):
                new_lines[-1] += "\n"

            lines[start:end] = new_lines
            total_lines = len(lines)

        # Write modified content
        new_content = "".join(lines)
        new_hash = self.calculate_hash(new_content)

        os.makedirs(os.path.dirname(validated_path), exist_ok=True)
        with open(validated_path, "w", encoding=encoding) as f:
            f.write(new_content)

        return {"result": "ok", "new_hash": new_hash}

    def delete_lines(
        self,
        file_path: str,
        expected_file_hash: Optional[str],
        start: int = 1,
        end: Optional[int] = None,
        encoding: str = "utf-8",
    ) -> Dict[str, Any]:
        """
        Delete lines from file.

        Args:
            file_path: Path to the file
            expected_file_hash: Expected hash of entire file. None = skip validation.
            start: Starting line (1-based)
            end: Ending line (inclusive, None = EOF)
            encoding: File encoding

        Returns:
            Dictionary with result, new_hash, or error reason
        """
        # Delete is just an edit with empty contents
        patches = [
            {"start": start, "end": end, "contents": "", "range_hash": None}
        ]

        return self.edit_file(file_path, expected_file_hash, patches, encoding)
