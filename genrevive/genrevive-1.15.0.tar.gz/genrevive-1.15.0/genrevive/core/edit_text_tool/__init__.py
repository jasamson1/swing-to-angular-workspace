"""
Text Editor Tool - Standalone file editing with hash-based conflict detection.

Adapted from mcp-text-editor for use without MCP dependency.
Provides safe file operations with CrewAI tool integration.
"""

from genrevive.core.edit_text_tool.text_editor_service import (
    TextEditorService,
    EditPatch,
)
from genrevive.core.edit_text_tool.text_editor_chunking_tools import (
    ReadFileTool,
    EditFileTool,
    DeleteLinesTool,
    ReplaceMethodTool,
    create_text_editor_tools,
)

__all__ = [
    "TextEditorService",
    "EditPatch",
    "ReadFileTool",
    "EditFileTool",
    "DeleteLinesTool",
    "ReplaceMethodTool",
    "create_text_editor_tools",
]
