"""
CrewAI Tool wrapper for TextEditorService - provides file editing capabilities to agents.

TOOLS:
- read_file: Reads file content (useful for reviewing files)
- edit_file: Edits file with patches (automatic hash handling)
- delete_lines: Deletes lines from file (requires hash from read_file)
- replace_method: Replaces entire methods atomically (safer than patch-based edits)

AGENT USAGE:

1. EDIT FILE:
   - Call edit_file with patches (range_hash MUST be null)
   - Example: edit_file("example.py", patches=[{"start": 50, "end": 50, "contents": "try:\\n", "range_hash": null}])

2. DELETE LINES:
   - First: read_file("example.py") -> get file_hash
   - Then: delete_lines("example.py", expected_file_hash="abc123...", start=10, end=20)

3. REPLACE METHOD:
   - Call replace_method with file_path, method_name, and new_method_code
   - Example: replace_method("Service.java", "calculateTotal", "public Double calculateTotal(List<Item> items) { ... }")
"""

from crewai.tools import BaseTool
from typing import Type, Any, Dict, List, Optional
from pydantic import BaseModel, Field
from .text_editor_service import TextEditorService
import os
import threading
import logging
from pathlib import Path
from collections import defaultdict

# Per-file locks to prevent concurrent edits to the same file
_file_locks = defaultdict(threading.Lock)
_file_locks_lock = threading.Lock()


def get_file_lock(file_path: str) -> threading.Lock:
    """Get or create a lock for a specific file path."""
    normalized_path = os.path.normpath(os.path.abspath(file_path))
    with _file_locks_lock:
        return _file_locks[normalized_path]


class ReadFileInput(BaseModel):
    """Input for read_file operation."""

    file_path: str = Field(..., description="Path to the file to read")
    start: int = Field(
        1, description="Starting line number (1-based, default: 1)"
    )
    end: Optional[int] = Field(
        None, description="Ending line number (inclusive, None = end of file)"
    )
    max_lines: int = Field(
        150,
        description="Maximum lines to return (default: 30, prevents context overflow)",
    )
    verify_hash: Optional[bool] = Field(
        None,
        description="DO NOT SET - uses tool's configured default. Only override if explicitly instructed.",
    )


class EditFileInput(BaseModel):
    """Input for edit_file operation."""

    file_path: str = Field(..., description="Path to the file to edit")
    patches: List[Dict[str, Any]] = Field(
        ...,
        description='List of patches to apply. Each patch must have exactly these fields: \'start\' (int), \'end\' (int or None), \'contents\' (str), \'range_hash\' (ALWAYS null - do not calculate). Example: {"start": 10, "end": 15, "contents": "new code", "range_hash": null}',
    )
    create_if_missing: bool = Field(
        False, description="Create file if it doesn't exist"
    )
    verify_hash: Optional[bool] = Field(
        None,
        description="DO NOT SET - uses tool's configured default. Only override if explicitly instructed.",
    )
    dry_run: bool = Field(
        False,
        description="Preview changes without applying them (returns preview of result)",
    )


class DeleteLinesInput(BaseModel):
    """Input for delete_lines operation."""

    file_path: str = Field(..., description="Path to the file")
    expected_file_hash: Optional[str] = Field(
        None,
        description="Expected SHA-256 hash of the entire file (optional when verify_hash=False)",
    )
    start: int = Field(1, description="Starting line to delete (1-based)")
    end: Optional[int] = Field(
        None,
        description="Ending line to delete (inclusive, None = end of file)",
    )
    verify_hash: Optional[bool] = Field(
        None,
        description="DO NOT SET - uses tool's configured default. Only override if explicitly instructed.",
    )


class ReplaceMethodInput(BaseModel):
    """Input for replace_method operation."""

    file_path: str = Field(..., description="Path to the file")
    method_name: str = Field(..., description="Name of the method to replace")
    new_method_code: str = Field(
        ...,
        description="Complete new method code including signature and body (from 'public/private' to closing '}')",
    )
    verify_hash: Optional[bool] = Field(
        None,
        description="DO NOT SET - uses tool's configured default. Only override if explicitly instructed.",
    )
    dry_run: bool = Field(
        False, description="Preview the replacement without applying"
    )


class ReadFileTool(BaseTool):
    """Tool for reading file contents with optional line range."""

    name: str = "read_file"
    description: str = """Read file contents. Returns: contents, file_hash, total_lines.

Args: file_path, start (default 1), end (None=EOF), max_lines (default 100), verify_hash (default True)"""
    args_schema: Type[BaseModel] = ReadFileInput

    def __init__(
        self,
        allowed_directories: Optional[List[str]] = None,
        verify_hash: bool = True,
        **kwargs,
    ):
        super().__init__(**kwargs)
        object.__setattr__(
            self, "_editor", TextEditorService(allowed_directories)
        )
        object.__setattr__(self, "_verify_hash", verify_hash)
        object.__setattr__(
            self, "_logger", logging.getLogger(f"{__name__}.ReadFileTool")
        )

    def _run(
        self,
        file_path: str,
        start: int = 1,
        end: Optional[int] = None,
        max_lines: int = 100,
        verify_hash: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Execute read_file operation."""
        file_lock = get_file_lock(file_path)
        try:
            # Use instance default - if instance is False, ignore agent's attempt to enable it
            if verify_hash is None or self._verify_hash is False:
                verify_hash = self._verify_hash

            with file_lock:
                self._logger.info(
                    f"Reading file: {file_path} (lines {start}-{end or 'EOF'})"
                )
                # Ensure all parameters are passed as keyword arguments to avoid confusion
                result = self._editor.read_file(
                    file_path=file_path,
                    start=start,
                    end=end,
                    max_lines=max_lines,
                )
                # If verify_hash is False, remove or set file_hash to None
                if (
                    not verify_hash
                    and isinstance(result, dict)
                    and "file_hash" in result
                ):
                    result["file_hash"] = None
                self._logger.info(
                    f"Successfully read {result.get('total_lines', 0)} lines from {file_path}"
                )
                return result
        except Exception as e:
            self._logger.error(
                f"Error reading file {file_path}: {str(e)}", exc_info=True
            )
            return {"result": "error", "reason": str(e)}


class EditFileTool(BaseTool):
    """Tool for editing file contents with improved reliability."""

    name: str = "edit_file"
    description: str = """Edit file with patches. Returns: new_hash.

Args: 
- file_path: path to file
- patches: list of dicts, each with EXACTLY these keys: "start", "end", "contents", "range_hash"
  CRITICAL: "range_hash" MUST ALWAYS be null (never calculate hash values)
  Example: [{"start": 10, "end": 15, "contents": "new code", "range_hash": null}]
- create_if_missing: bool (default False)
- verify_hash: bool (default True)
- dry_run: bool (default False) - Preview changes before applying

IMPORTANT: Patches are applied in order. Ensure line numbers account for previous edits.
TIP: Use dry_run=True first to preview the result before applying."""
    args_schema: Type[BaseModel] = EditFileInput

    def __init__(
        self,
        allowed_directories: Optional[List[str]] = None,
        verify_hash: bool = True,
        **kwargs,
    ):
        super().__init__(**kwargs)
        object.__setattr__(
            self, "_editor", TextEditorService(allowed_directories)
        )
        object.__setattr__(self, "_verify_hash", verify_hash)
        object.__setattr__(
            self, "_logger", logging.getLogger(f"{__name__}.EditFileTool")
        )

    def _check_balanced_delimiters(
        self, content: str, file_path: str
    ) -> Optional[str]:
        """Check for balanced braces, brackets, and parentheses. Returns error message or None."""
        # Skip check for non-code files
        if not any(
            file_path.endswith(ext)
            for ext in [
                ".java",
                ".py",
                ".js",
                ".ts",
                ".cpp",
                ".c",
                ".cs",
                ".go",
                ".rs",
            ]
        ):
            return None

        stack = []
        pairs = {"(": ")", "[": "]", "{": "}"}
        line_num = 1
        col_num = 0

        for char in content:
            col_num += 1
            if char == "\n":
                line_num += 1
                col_num = 0
                continue

            if char in pairs.keys():
                stack.append((char, line_num, col_num))
            elif char in pairs.values():
                if not stack:
                    return f"Unmatched closing '{char}' at line {line_num}, column {col_num}"
                opening, open_line, open_col = stack.pop()
                if pairs[opening] != char:
                    return f"Mismatched delimiters: '{opening}' at line {open_line}, col {open_col} closed with '{char}' at line {line_num}, col {col_num}"

        if stack:
            unclosed = [(char, line, col) for char, line, col in stack]
            first = unclosed[0]
            return f"Unclosed delimiter '{first[0]}' opened at line {first[1]}, column {first[2]} (total unclosed: {len(unclosed)})"

        return None

    def _check_code_structure(
        self, original: str, modified: str, file_path: str
    ) -> Optional[str]:
        """Check if critical code elements were accidentally removed or NEW malformed code was introduced. Returns error message or None."""
        # Skip check for non-code files
        if not any(
            file_path.endswith(ext)
            for ext in [
                ".java",
                ".py",
                ".js",
                ".ts",
                ".cpp",
                ".c",
                ".cs",
                ".go",
                ".rs",
            ]
        ):
            return None

        import re

        # For Java files, check for return statements in methods
        if file_path.endswith(".java"):
            # Check for malformed patterns - but only NEW ones introduced by this edit
            # 1. Multiple statements on same line (excluding simple cases)
            malformed_lines_orig = []
            malformed_lines_mod = []

            for i, line in enumerate(original.split("\n"), 1):
                if re.search(r"println.*return\s", line) or re.search(
                    r"\}\s*return\s", line
                ):
                    malformed_lines_orig.append(i)

            for i, line in enumerate(modified.split("\n"), 1):
                # Check for multiple return statements on one line
                if line.count("return ") > 1:
                    if i not in malformed_lines_orig:  # Only report if NEW
                        malformed_lines_mod.append(
                            f"Line {i}: Multiple return statements on same line"
                        )
                # Check for statement followed by return on same line (suspicious pattern)
                if re.search(r"println.*return\s", line) or re.search(
                    r"\}\s*return\s", line
                ):
                    if i not in malformed_lines_orig:  # Only report if NEW
                        malformed_lines_mod.append(
                            f"Line {i}: Statement and return on same line: {line.strip()[:80]}"
                        )

            if malformed_lines_mod:
                return f"Malformed code detected: {'; '.join(malformed_lines_mod[:3])}"

            # 2. Check for orphaned statements (statements outside methods)
            lines = modified.split("\n")
            in_method = False
            brace_count = 0
            for i, line in enumerate(lines, 1):
                stripped = line.strip()

                # Track method boundaries
                if re.search(
                    r"(public|private|protected)\s+.*\(.*\)\s*\{", stripped
                ):
                    in_method = True

                # Track braces
                brace_count += stripped.count("{") - stripped.count("}")

                # Check for statements that should be inside methods
                if not in_method and brace_count <= 1:  # At class level
                    if (
                        stripped.startswith("System.out.println")
                        or stripped.startswith("return ")
                        or (
                            stripped.startswith("//") is False
                            and 'return "' in stripped
                        )
                    ):
                        return f"Line {i}: Statement found outside method body: {stripped[:80]}"

                # Reset method flag when exiting
                if in_method and brace_count <= 1:
                    in_method = False

            # 3. Check for missing method signatures
            # Find return statements and ensure they're in methods
            return_lines = [
                i
                for i, line in enumerate(lines, 1)
                if "return " in line and not line.strip().startswith("//")
            ]
            for ret_line in return_lines:
                # Look backward for method signature (within reasonable distance)
                found_method = False
                for j in range(max(0, ret_line - 20), ret_line):
                    if re.search(
                        r"(public|private|protected)\s+\w+\s+\w+\s*\(",
                        lines[j],
                    ):
                        found_method = True
                        break

                if (
                    not found_method and ret_line > 10
                ):  # Allow some flexibility at file start
                    context = (
                        lines[ret_line - 1].strip() if ret_line > 0 else ""
                    )
                    return f"Line {ret_line}: Return statement without method signature nearby: {context[:80]}"

            # Find all method signatures in original
            method_pattern = r"(public|private|protected|static|\s)+[\w\<\>\[\]]+\s+(\w+)\s*\([^\)]*\)\s*\{"
            methods_orig = re.findall(method_pattern, original)
            methods_mod = re.findall(method_pattern, modified)

            # Count return statements per method
            def count_returns_after_methods(content, methods):
                returns_per_method = {}
                lines = content.split("\n")
                method_starts = []

                for match in re.finditer(method_pattern, content):
                    method_name = match.group(2)
                    start_pos = match.start()
                    line_num = content[:start_pos].count("\n")
                    method_starts.append(
                        (method_name, line_num, match.group(0))
                    )

                for i, (method_name, start_line, signature) in enumerate(
                    method_starts
                ):
                    # Determine if method should have return (not void, not constructor)
                    if (
                        "void" in signature or method_name[0].isupper()
                    ):  # Constructor
                        continue

                    # Find end of method (next method or end of file)
                    end_line = (
                        method_starts[i + 1][1]
                        if i + 1 < len(method_starts)
                        else len(lines)
                    )
                    method_body = "\n".join(lines[start_line:end_line])

                    # Count return statements
                    return_count = len(re.findall(r"\breturn\s+", method_body))
                    returns_per_method[method_name] = return_count

                return returns_per_method

            try:
                orig_returns = count_returns_after_methods(
                    original, methods_orig
                )
                mod_returns = count_returns_after_methods(
                    modified, methods_mod
                )

                # Check if any non-void method lost its return statement
                for method_name, orig_count in orig_returns.items():
                    if method_name in mod_returns:
                        if orig_count > 0 and mod_returns[method_name] == 0:
                            return f"Method '{method_name}' lost its return statement (had {orig_count}, now has 0)"
                        elif mod_returns[method_name] < orig_count:
                            return f"Method '{method_name}' has fewer return statements than original ({mod_returns[method_name]} vs {orig_count})"
            except Exception as e:
                self._logger.warning(
                    f"Could not validate return statements: {e}"
                )

        # For Python files, check for return/yield statements
        elif file_path.endswith(".py"):
            # Find all function definitions
            func_pattern = r"def\s+(\w+)\s*\([^\)]*\):"

            orig_funcs = set(re.findall(func_pattern, original))
            mod_funcs = set(re.findall(func_pattern, modified))

            # Check if functions that had returns lost them
            for func_name in orig_funcs & mod_funcs:  # Intersection
                # Extract function body (simplified)
                orig_func_match = re.search(
                    rf"def\s+{func_name}\s*\([^\)]*\):.*?(?=\ndef\s|\nclass\s|\Z)",
                    original,
                    re.DOTALL,
                )
                mod_func_match = re.search(
                    rf"def\s+{func_name}\s*\([^\)]*\):.*?(?=\ndef\s|\nclass\s|\Z)",
                    modified,
                    re.DOTALL,
                )

                if orig_func_match and mod_func_match:
                    orig_body = orig_func_match.group(0)
                    mod_body = mod_func_match.group(0)

                    orig_has_return = bool(re.search(r"\breturn\b", orig_body))
                    mod_has_return = bool(re.search(r"\breturn\b", mod_body))

                    if orig_has_return and not mod_has_return:
                        return (
                            f"Function '{func_name}' lost its return statement"
                        )

        return None

    def _validate_patches(
        self,
        patches: List[Dict[str, Any]],
        file_lines: Optional[List[str]] = None,
    ) -> Optional[str]:
        """Validate patch structure and detect overlaps. Returns error message or None if valid."""
        if not patches:
            return "Patches list cannot be empty"

        for i, patch in enumerate(patches):
            # Check required fields
            required_fields = {"start", "end", "contents", "range_hash"}
            missing = required_fields - set(patch.keys())
            if missing:
                return f"Patch {i} missing required fields: {missing}"

            # Validate types
            if not isinstance(patch["start"], int):
                return f"Patch {i}: 'start' must be an integer, got {type(patch['start'])}"
            if patch["end"] is not None and not isinstance(patch["end"], int):
                return f"Patch {i}: 'end' must be an integer or None, got {type(patch['end'])}"
            if not isinstance(patch["contents"], str):
                return f"Patch {i}: 'contents' must be a string, got {type(patch['contents'])}"

            # Validate line numbers
            if patch["start"] < 1:
                return f"Patch {i}: 'start' must be >= 1, got {patch['start']}"
            if patch["end"] is not None and patch["end"] < patch["start"]:
                return f"Patch {i}: 'end' ({patch['end']}) cannot be less than 'start' ({patch['start']})"

            # Validate against file bounds if file_lines provided
            if file_lines:
                total_lines = len(file_lines)
                if patch["start"] > total_lines + 1:
                    return f"Patch {i}: 'start' ({patch['start']}) exceeds file length ({total_lines})"
                if patch["end"] is not None and patch["end"] > total_lines:
                    return f"Patch {i}: 'end' ({patch['end']}) exceeds file length ({total_lines})"

            # Check if patch is removing return statements without replacing them
            if file_lines and patch["end"] is not None:
                start_idx = patch["start"] - 1
                end_idx = patch["end"] - 1
                removed_lines = "".join(file_lines[start_idx : end_idx + 1])

                if (
                    "return " in removed_lines
                    and "return " not in patch["contents"]
                ):
                    self._logger.warning(
                        f"Patch {i} removes 'return' statement without replacing it. Original: {removed_lines[:100]}"
                    )
                    # Don't fail, just warn - might be intentional

        # Check for overlapping patches (which cause duplicate content)
        for i in range(len(patches) - 1):
            patch1 = patches[i]
            patch2 = patches[i + 1]

            end1 = (
                patch1["end"] if patch1["end"] is not None else patch1["start"]
            )
            start2 = patch2["start"]

            # Patches should be in ascending order and non-overlapping
            if start2 <= end1:
                return f"Patches {i} and {i + 1} overlap or are out of order: patch {i} ends at line {end1}, patch {i + 1} starts at line {start2}. Patches must be sorted and non-overlapping."

        return None

    def _preview_edit(
        self, file_path: str, patches: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Preview what the file would look like after applying patches."""
        try:
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                return {
                    "result": "error",
                    "reason": f"File does not exist: {file_path}",
                }

            # Read current file
            with open(file_path, "r", encoding="utf-8") as f:
                original_content = f.read()
                lines = original_content.splitlines(keepends=True)

            # Apply patches in reverse order to maintain line numbers
            result_lines = lines.copy()
            for patch in reversed(patches):
                start = patch["start"] - 1  # Convert to 0-based
                end = (patch["end"] - 1) if patch["end"] is not None else start
                new_content = patch["contents"]

                # Split new content into lines, preserving line endings
                if new_content:
                    new_lines = new_content.splitlines(keepends=True)
                    # Ensure last line has newline if original had one
                    if (
                        new_lines
                        and not new_content.endswith("\n")
                        and end < len(lines) - 1
                    ):
                        new_lines[-1] = new_lines[-1] + "\n"
                else:
                    new_lines = []

                # Replace the range
                result_lines[start : end + 1] = new_lines

            preview = "".join(result_lines)

            # Check for balanced delimiters in preview
            balance_error = self._check_balanced_delimiters(preview, file_path)
            if balance_error:
                return {
                    "result": "error",
                    "reason": f"Preview shows unbalanced delimiters: {balance_error}",
                    "preview": preview,
                    "suggestion": "The patches would create malformed code. Please review and adjust your changes.",
                }

            # Check if critical code elements were removed
            # Only validate if we're making structural changes, not simple additions
            is_simple_addition = all(
                patch.get("start") == patch.get("end")
                and (
                    patch.get("contents", "").strip().startswith("import ")
                    or len(patch.get("contents", "").strip()) < 100
                )
                for patch in patches
            )

            if not is_simple_addition:
                structure_error = self._check_code_structure(
                    original_content, preview, file_path
                )
                if structure_error:
                    return {
                        "result": "error",
                        "reason": f"Preview shows missing critical code: {structure_error}",
                        "preview": preview,
                        "suggestion": "The patches removed important code elements. Please ensure all return statements and critical code are preserved.",
                    }

            return {
                "result": "success",
                "preview": preview,
                "original_lines": len(lines),
                "result_lines": len(result_lines),
                "message": "This is a dry-run preview. Set dry_run=False to apply changes.",
            }
        except Exception as e:
            return {"result": "error", "reason": f"Preview failed: {str(e)}"}

    def _run(
        self,
        file_path: str,
        patches: List[Dict[str, Any]],
        create_if_missing: bool = False,
        verify_hash: Optional[bool] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Execute edit_file operation with improved error handling and validation."""

        # Log all input parameters
        self._logger.info("EditFileTool._run called with parameters:")
        self._logger.info(f"  file_path: {file_path}")
        self._logger.info(f"  patches: {patches}")
        self._logger.info(f"  create_if_missing: {create_if_missing}")
        self._logger.info(f"  verify_hash: {verify_hash}")
        self._logger.info(f"  dry_run: {dry_run}")

        file_lock = get_file_lock(file_path)

        try:
            # Read file for validation
            file_lines = None
            original_content = None
            file_path_obj = Path(file_path)
            if file_path_obj.exists():
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        original_content = f.read()
                        file_lines = original_content.splitlines(keepends=True)
                except Exception as e:
                    self._logger.warning(
                        f"Could not read file for validation: {e}"
                    )

            # Validate patches with file context
            validation_error = self._validate_patches(patches, file_lines)
            if validation_error:
                self._logger.error(
                    f"Patch validation failed: {validation_error}"
                )
                return {
                    "result": "error",
                    "reason": f"Invalid patches: {validation_error}",
                }

            # Handle dry-run mode (includes syntax validation)
            if dry_run:
                self._logger.info(
                    f"Dry-run mode: Previewing changes to {file_path}"
                )
                return self._preview_edit(file_path, patches)

            # ALWAYS preview and validate before applying to catch syntax errors
            preview_result = self._preview_edit(file_path, patches)
            if preview_result.get("result") == "error":
                self._logger.warning(
                    f"Preview validation failed: {preview_result.get('reason')}"
                )
                # return {
                #     "result": "error",
                #     "reason": preview_result.get("reason"),
                #     "preview": preview_result.get("preview", "N/A")[:500],
                #     "suggestion": preview_result.get(
                #         "suggestion",
                #         "Fix the patches to create valid code structure.",
                #     ),
                # }

            # Use instance default - if instance is False, ignore agent's attempt to enable it
            if verify_hash is None or self._verify_hash is False:
                verify_hash = self._verify_hash

            self._logger.info(
                f"EditFileTool: Editing {file_path} with {len(patches)} patch(es), verify_hash={verify_hash}"
            )

            # Force all range_hash values to None (agent might mistakenly calculate them)
            for patch in patches:
                patch["range_hash"] = None

            with file_lock:
                import hashlib

                # Create backup if file exists
                backup_content = None
                if file_path_obj.exists():
                    try:
                        with open(file_path, "rb") as f:
                            backup_content = f.read()
                    except Exception as e:
                        self._logger.warning(f"Could not create backup: {e}")

                if verify_hash:
                    # Read current file to get its hash
                    if file_path_obj.exists():
                        current_hash = hashlib.sha256(
                            backup_content
                        ).hexdigest()
                    else:
                        current_hash = None
                    self._logger.info(
                        f"EditFileTool: Hash verification enabled, current_hash={current_hash[:8] if current_hash else 'None'}..."
                    )
                else:
                    # Skip hash verification
                    current_hash = None
                    self._logger.info(
                        "EditFileTool: Hash verification disabled"
                    )

                # Log patch details
                for i, patch in enumerate(patches):
                    content_preview = patch["contents"][:50].replace(
                        "\n", "\\n"
                    )
                    self._logger.info(
                        f"Patch {i}: lines {patch['start']}-{patch['end']}, content: '{content_preview}...'"
                    )

                # Apply edits
                try:
                    result = self._editor.edit_file(
                        file_path,
                        current_hash,
                        patches,
                        create_if_missing=create_if_missing,
                    )

                    # Post-edit validation: check the actual file
                    try:
                        with open(file_path, "r", encoding="utf-8") as f:
                            final_content = f.read()

                        balance_error = self._check_balanced_delimiters(
                            final_content, file_path
                        )
                        if balance_error:
                            self._logger.warning(
                                f"Post-edit validation failed: {balance_error}"
                            )
                            # Restore backup
                            # if backup_content:
                            #     with open(file_path, "wb") as f:
                            #         f.write(backup_content)
                            #     self._logger.info(
                            #         "Restored backup due to syntax error"
                            #     )
                            # return {
                            #     "result": "error",
                            #     "reason": f"Edit created malformed code: {balance_error}",
                            #     "suggestion": "File was restored from backup. Please review patches and ensure they create valid code structure.",
                            # }

                        # Check for missing critical code
                        if original_content:
                            structure_error = self._check_code_structure(
                                original_content, final_content, file_path
                            )
                            if structure_error:
                                self._logger.warning(
                                    f"Post-edit structure validation failed: {structure_error}"
                                )
                                # Restore backup
                                # if backup_content:
                                #     with open(file_path, "wb") as f:
                                #         f.write(backup_content)
                                #     self._logger.info(
                                #         "Restored backup due to missing critical code"
                                #     )
                                # return {
                                #     "result": "error",
                                #     "reason": f"Edit removed critical code: {structure_error}",
                                #     "suggestion": "File was restored from backup. Please ensure all return statements and critical code are preserved in your patches.",
                                # }
                    except Exception as validation_error:
                        self._logger.warning(
                            f"Post-edit validation failed: {validation_error}"
                        )

                    self._logger.info(
                        f"Successfully edited {file_path}, new_hash={result.get('new_hash', 'N/A')[:8]}..."
                    )
                    return result
                except Exception as edit_error:
                    # Attempt to restore backup on failure
                    if backup_content and file_path_obj.exists():
                        try:
                            with open(file_path, "wb") as f:
                                f.write(backup_content)
                            self._logger.info(
                                "Restored backup after edit failure"
                            )
                        except Exception as restore_error:
                            self._logger.error(
                                f"Failed to restore backup: {restore_error}"
                            )
                    raise edit_error

        except Exception as e:
            self._logger.error(
                f"Error editing file {file_path}: {str(e)}", exc_info=True
            )
            return {
                "result": "error",
                "reason": str(e),
                "suggestion": "Try: 1) Use dry_run=True to preview changes, 2) Read the file first to verify current state, 3) Apply patches one at a time, 4) Ensure patches are sorted by line number and don't overlap",
            }


class DeleteLinesTool(BaseTool):
    """Tool for deleting lines from a file."""

    name: str = "delete_lines"
    description: str = """Delete lines from file (requires read_file first for hash). Returns: new_hash.

Args: file_path, expected_file_hash, start (default 1), end (None=EOF), verify_hash (default True)"""
    args_schema: Type[BaseModel] = DeleteLinesInput

    def __init__(
        self,
        allowed_directories: Optional[List[str]] = None,
        verify_hash: bool = True,
        **kwargs,
    ):
        super().__init__(**kwargs)
        object.__setattr__(
            self, "_editor", TextEditorService(allowed_directories)
        )
        object.__setattr__(self, "_verify_hash", verify_hash)
        object.__setattr__(
            self, "_logger", logging.getLogger(f"{__name__}.DeleteLinesTool")
        )

    def _run(
        self,
        file_path: str,
        expected_file_hash: Optional[str] = None,
        start: int = 1,
        end: Optional[int] = None,
        verify_hash: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Execute delete_lines operation."""
        file_lock = get_file_lock(file_path)
        try:
            # Use instance default - if instance is False, ignore agent's attempt to enable it
            if verify_hash is None or self._verify_hash is False:
                verify_hash = self._verify_hash

            with file_lock:
                self._logger.info(
                    f"Deleting lines {start}-{end or 'EOF'} from {file_path}"
                )
                # If verify_hash is False, pass None to skip hash validation
                hash_to_use = expected_file_hash if verify_hash else None
                result = self._editor.delete_lines(
                    file_path, hash_to_use, start, end
                )
                self._logger.info(
                    f"Successfully deleted lines from {file_path}"
                )
                return result
        except Exception as e:
            self._logger.error(
                f"Error deleting lines from {file_path}: {str(e)}",
                exc_info=True,
            )
            return {"result": "error", "reason": str(e)}


class ReplaceMethodTool(BaseTool):
    """Tool for replacing entire methods atomically - safer than patch-based edits."""

    name: str = "replace_method"
    description: str = """Replace an entire method in a Java/Python file. Returns: new_hash.

This tool finds a method by name and replaces it completely, ensuring:
- Method signature is preserved or updated correctly
- All braces/brackets are balanced
- Return statements are present
- No orphaned code

Args:
- file_path: path to file
- method_name: name of method to replace (e.g., "method901")
- new_method_code: complete new method including signature, body, and closing brace
- dry_run: preview changes before applying (default False)

Example for Java:
replace_method(
    file_path="Service.java",
    method_name="calculateTotal",
    new_method_code=\"\"\"    public Double calculateTotal(List<Item> items) {
        Double total = 0.0;
        for (Item item : items) {
            total += item.getPrice();
        }
        return total;
    }\"\"\"
)"""
    args_schema: Type[BaseModel] = ReplaceMethodInput

    def __init__(
        self,
        allowed_directories: Optional[List[str]] = None,
        verify_hash: bool = True,
        **kwargs,
    ):
        super().__init__(**kwargs)
        object.__setattr__(
            self, "_editor", TextEditorService(allowed_directories)
        )
        object.__setattr__(self, "_verify_hash", verify_hash)
        object.__setattr__(
            self, "_logger", logging.getLogger(f"{__name__}.ReplaceMethodTool")
        )

    def _find_method_bounds(
        self, content: str, method_name: str, file_path: str
    ) -> Optional[tuple[int, int]]:
        """Find the start and end line numbers of a method. Returns (start, end) or None."""
        import re

        lines = content.split("\n")

        if file_path.endswith(".java"):
            # Java method pattern
            pattern = rf"(public|private|protected|static|\s)+[\w\<\>\[\]]+\s+{re.escape(method_name)}\s*\([^\)]*\)\s*\{{"

            for i, line in enumerate(lines):
                if re.search(pattern, line):
                    start_line = i + 1  # 1-based

                    # Find matching closing brace
                    brace_count = line.count("{") - line.count("}")
                    end_line = None

                    for j in range(i + 1, len(lines)):
                        brace_count += lines[j].count("{") - lines[j].count(
                            "}"
                        )
                        if brace_count == 0:
                            end_line = j + 1  # 1-based
                            break

                    if end_line:
                        return (start_line, end_line)
                    else:
                        self._logger.error(
                            f"Found method {method_name} but couldn't find closing brace"
                        )
                        return None

        elif file_path.endswith(".py"):
            # Python function pattern
            pattern = rf"def\s+{re.escape(method_name)}\s*\([^\)]*\):"

            for i, line in enumerate(lines):
                if re.search(pattern, line):
                    start_line = i + 1  # 1-based

                    # Find end of function (next def/class or dedent)
                    base_indent = len(line) - len(line.lstrip())
                    end_line = None

                    for j in range(i + 1, len(lines)):
                        current_line = lines[j]
                        if current_line.strip():  # Non-empty line
                            current_indent = len(current_line) - len(
                                current_line.lstrip()
                            )
                            # Check if we've dedented or found new def/class
                            if current_indent <= base_indent or re.match(
                                r"\s*(def|class)\s+", current_line
                            ):
                                end_line = j  # Line before this one
                                break

                    if end_line is None:
                        end_line = len(lines)  # End of file

                    return (start_line, end_line)

        return None

    def _validate_method_code(
        self, method_code: str, method_name: str, file_path: str
    ) -> Optional[str]:
        """Validate the new method code. Returns error message or None."""
        import re

        if not method_code.strip():
            return "Method code cannot be empty"

        if file_path.endswith(".java"):
            # Check for method signature
            if not re.search(
                rf"(public|private|protected)\s+.*{re.escape(method_name)}\s*\(",
                method_code,
            ):
                return f"Method code must include method signature with name '{method_name}'"

            # Check balanced braces
            if method_code.count("{") != method_code.count("}"):
                return f"Unbalanced braces: {method_code.count('{')} opening, {method_code.count('}')} closing"

            # Check for return statement if not void
            if "void" not in method_code.split("(")[0]:  # Check return type
                if "return " not in method_code:
                    return "Non-void method must have a return statement"

            # Check that it ends with closing brace
            if not method_code.rstrip().endswith("}"):
                return "Method code must end with closing brace '}'"

        elif file_path.endswith(".py"):
            # Check for function definition
            if not re.search(
                rf"def\s+{re.escape(method_name)}\s*\(", method_code
            ):
                return f"Method code must include function definition 'def {method_name}(...)'"

            # Check indentation consistency
            lines = method_code.split("\n")
            if len(lines) > 1:
                first_line_indent = len(lines[0]) - len(lines[0].lstrip())
                for i, line in enumerate(lines[1:], 2):
                    if line.strip():  # Non-empty
                        line_indent = len(line) - len(line.lstrip())
                        if line_indent < first_line_indent:
                            return f"Line {i} has invalid dedent"

        return None

    def _run(
        self,
        file_path: str,
        method_name: str,
        new_method_code: str,
        verify_hash: Optional[bool] = None,
        dry_run: bool = False,
    ) -> Dict[str, Any]:
        """Execute replace_method operation."""
        file_lock = get_file_lock(file_path)

        try:
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                return {
                    "result": "error",
                    "reason": f"File does not exist: {file_path}",
                }

            # Read file
            with open(file_path, "r", encoding="utf-8") as f:
                original_content = f.read()

            # Validate new method code
            validation_error = self._validate_method_code(
                new_method_code, method_name, file_path
            )
            if validation_error:
                self._logger.error(
                    f"Method validation failed: {validation_error}"
                )
                return {
                    "result": "error",
                    "reason": f"Invalid method code: {validation_error}",
                }

            # Find method bounds
            bounds = self._find_method_bounds(
                original_content, method_name, file_path
            )
            if not bounds:
                return {
                    "result": "error",
                    "reason": f"Method '{method_name}' not found in {file_path}",
                    "suggestion": "Verify the method name is correct and the file contains this method",
                }

            start_line, end_line = bounds
            self._logger.info(
                f"Found method '{method_name}' at lines {start_line}-{end_line}"
            )

            # Create the patch
            patch = {
                "start": start_line,
                "end": end_line,
                "contents": new_method_code,
                "range_hash": None,
            }

            # Preview the change
            lines = original_content.splitlines(keepends=True)
            result_lines = lines.copy()
            result_lines[start_line - 1 : end_line] = [
                (
                    new_method_code
                    if new_method_code.endswith("\n")
                    else new_method_code + "\n"
                )
            ]
            preview_content = "".join(result_lines)

            if dry_run:
                self._logger.info(
                    f"Dry-run: Would replace method '{method_name}'"
                )
                return {
                    "result": "success",
                    "preview": preview_content,
                    "start_line": start_line,
                    "end_line": end_line,
                    "lines_replaced": end_line - start_line + 1,
                    "message": f"Dry-run: Method '{method_name}' would be replaced. Set dry_run=False to apply.",
                }

            # Use instance default for verify_hash
            if verify_hash is None or self._verify_hash is False:
                verify_hash = self._verify_hash

            with file_lock:
                import hashlib

                # Create backup
                backup_content = None
                try:
                    with open(file_path, "rb") as f:
                        backup_content = f.read()
                except Exception as e:
                    self._logger.warning(f"Could not create backup: {e}")

                # Get hash if needed
                current_hash = None
                if verify_hash and backup_content:
                    current_hash = hashlib.sha256(backup_content).hexdigest()

                self._logger.info(
                    f"Replacing method '{method_name}' in {file_path}"
                )

                try:
                    # Apply the edit using existing editor
                    result = self._editor.edit_file(
                        file_path,
                        current_hash,
                        [patch],
                        create_if_missing=False,
                    )

                    # Validate result
                    with open(file_path, "r", encoding="utf-8") as f:
                        final_content = f.read()

                    # Check that method exists in result
                    if method_name not in final_content:
                        raise Exception(
                            f"Method '{method_name}' missing after replacement"
                        )

                    self._logger.info(
                        f"Successfully replaced method '{method_name}'"
                    )
                    result["method_name"] = method_name
                    result["start_line"] = start_line
                    result["end_line"] = end_line
                    return result

                except Exception as edit_error:
                    # Restore backup
                    if backup_content:
                        try:
                            with open(file_path, "wb") as f:
                                f.write(backup_content)
                            self._logger.info(
                                "Restored backup after replacement failure"
                            )
                        except Exception as restore_error:
                            self._logger.error(
                                f"Failed to restore backup: {restore_error}"
                            )
                    raise edit_error

        except Exception as e:
            self._logger.error(
                f"Error replacing method '{method_name}' in {file_path}: {str(e)}",
                exc_info=True,
            )
            return {
                "result": "error",
                "reason": str(e),
                "suggestion": "Use dry_run=True to preview the replacement first. Ensure the method name is exact and the new code is complete.",
            }


def create_text_editor_tools(
    allowed_directories: Optional[List[str]] = None, verify_hash: bool = True
) -> List[BaseTool]:
    """
    Create all text editor tools with shared configuration.

    Args:
        allowed_directories: List of allowed base directories.
                           If None, uses FILESYSTEM_ALLOWED_DIRS env var or current directory.
        verify_hash: Enable hash verification for all tools (default: True)

    Returns:
        List of BaseTool instances: [ReadFileTool, EditFileTool, DeleteLinesTool, ReplaceMethodTool]
    """
    if allowed_directories is None:
        # Use env var or fallback to current directory
        dirs_str = os.getenv("FILESYSTEM_ALLOWED_DIRS")
        if dirs_str:
            # Try parsing as JSON first (supports ["dir1","dir2"] format)
            import json

            try:
                allowed_directories = json.loads(dirs_str)
            except (json.JSONDecodeError, ValueError):
                # Fallback to comma-separated format
                allowed_directories = [
                    d.strip() for d in dirs_str.split(",") if d.strip()
                ]
        else:
            allowed_directories = [os.getcwd()]

    return [
        ReadFileTool(allowed_directories, verify_hash=verify_hash),
        EditFileTool(allowed_directories, verify_hash=verify_hash),
        DeleteLinesTool(allowed_directories, verify_hash=verify_hash),
        ReplaceMethodTool(allowed_directories, verify_hash=verify_hash),
    ]
