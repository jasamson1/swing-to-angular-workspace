from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv
from genrevive.helpers.intelligent_chunking.chunkers.java_chunker import JavaChunker
from genrevive.helpers.intelligent_chunking.repository.repository_origin import RepositoryOrigin

class IntelligentChunking():
    def __init__(self):
        load_dotenv()
        self.chunker = JavaChunker()
        self.repo = RepositoryOrigin()

    def chunk_input(self, input_text: str, filename: str = None, target_file_path: str = None, role: str = None):

        target_filename = filename if filename else "unknown_source"
        # metadata to be saved as JSON in ChromaDB
        data = {
            "filename": target_filename,
            "target_path": target_file_path,
            "full_target_path": str(Path(target_file_path) / target_filename),
        }

       
        chunks = self.chunker.chunk(input_text, role)
        chunks_data = self._retrieve_chunk_data(chunks, data)
        self._persist_chunks(chunks_data, data)
        return chunks_data

    def _retrieve_chunk_data(self, chunks: list[str], data: dict) -> list[dict]:
        chunks_data = []
        for i, chunk in enumerate(chunks):
            chunk_id = f"origin_{str(Path(data['target_path']).resolve())}_{data['filename']}_chunk_{i}"
            if(i == len(chunks) - 1):
                chunk_id += "_last_chunk"
            chunk_id += f"_{datetime.now().isoformat()}"
            chunks_data.append({
                "chunk_id": chunk_id,
                "content": chunk
            })
        return chunks_data
    
    def _persist_chunks(self, chunks_data: list[dict], data: dict) -> None:
        ids = [chunk_data["chunk_id"] for chunk_data in chunks_data]
        chunks = [chunk_data["content"] for chunk_data in chunks_data]
        metadatas = []
        for chunk_data in chunks_data:
            metadata = {
                "target_filepath_full": data["full_target_path"],
            }
            metadatas.append(metadata)
        
        self.repo.add(
            ids=ids,
            chunks=chunks,
            metadatas=metadatas
        )
        