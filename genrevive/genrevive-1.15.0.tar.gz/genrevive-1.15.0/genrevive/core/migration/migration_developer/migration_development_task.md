# Migration Activity Generation Instructions

You will generate migration activities based on the provided plan. Each activity will be saved in output_activities/generated directory.

## File Structure and Path Handling

For each activity, create one of the following directory structures inside output_activities/generated.
If it is an BaseActivity, use this directory structure:
```
[activity_name]/
└── [activity_name].py      # Main activity module
```
If it is an GenAIActivity, use this directory structure:
```
[activity_name]/
├── [activity_name].py      # Main activity module
├── .env                    # Environment configuration
├── prompts/
│   └── task.md            # Task documentation
└── cookbooks/
    └── cookbook.md        # Implementation guide
```
## Code Block Generation Guidelines

1. Use relative paths in filename tags
2. Always include full module content
3. Use the standard pattern:

```python 
filename: output_activities/generated/<activity_name>/<activity_name>.py
<Activity implementation>
```
The following files are only needed for GenAIActivities.

```properties 
filename: output_activities/generated/<activity_name>/.env
<Configuration>
```

```markdown 
filename: output_activities/generated/<activity_name>/prompts/task.md
<Task documentation>
```

```markdown 
filename: output_activities/generated/<activity_name>/cookbooks/cookbook.md
<Implementation guide>
```

## Important Path Handling Rules

1. All paths in `filename:` tags must be relative
2. Never include absolute paths in generated code
3. The system will automatically:
   - Place files in the correct base directory
   - Create necessary subdirectories
   - Handle path resolution


### Task Prompt
```markdown 
filename: activities/<activity_name>/prompts/task.md
# <Activity Name> Task
<Prompt content describing the specific task and requirements>
```

### Cookbook
```markdown 
filename: activities/<activity_name>/cookbooks/cookbook.md
# <Activity Name> Cookbook
<Cookbook content with patterns, examples, and best practices>
```

## CRITICAL: GenAIActivity Implementation Requirements

Every generated activity must extend either BaseActivity or GenAIActivity.
Those are the imports to use, depending on the type of activity:
- `from genrevive.core.gen_ai_activity import GenAIActivity`
- `from genrevive.core.base_activity import BaseActivity`
Every class extending GenAIActivity MUST implement these 5 required methods:

1. `__init__(self)` - Initialize instance variables and call `super().__init__()`
2. `setup_general_configuration(self)` - Load paths and general environment variables
3. `setup_cookbooks_and_prompts(self)` - Load prompt and cookbook files from filesystem
4. `setup_agents(self)` - Initialize CrewAI agents (software engineer, reviewer, etc.)
5. `setup_tasks(self)` - Define and append tasks to self.tasks list
It MUST NOT implement the `execute(self)` method. DO NOT include `execute(self)` in the GenAIActivities. 

## Requirements for Each Activity

1. Each activity should be self-contained in its own directory
2. Include clear documentation in the main Python file
3. Provide task-specific prompts in the prompts directory
4. Include relevant patterns and examples in the cookbook
5. Prepare empty .env file for activity-specific configuration

Please generate the migration activities based on the provided plan following this structure.