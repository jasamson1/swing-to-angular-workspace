Task1:

Description: Prepare abstract activity class for cleaning of the input project. Based on input_architecture.md and current_genrevive_abilities.md verify if :

there are helper classes in GenRevive for the given technology to take actions before migration (like adf_project_cleaner.py).  If yes add usage of this cleaners to the semi_code_migration_plan.md in a form like AdfProjectCleaner().execute(). End the current task. 
If the helper is not there and based on input technology knowledge some cleanup actions are suggested before migration
Create a semi code definition a InputAppCleaner class and add it to semi_code_migration_plan.md
add information of what needs to be done as the cleaning actions for migration to the comments section of the InputAppCleaner class.

Expected Output: updated semi_code_migration_plan.md



Task2:

Description: Prepare abstract activity class for an input and output dependency installer. Based on input_architecture.md and output_architecture_design.md and current_genrevive_abilities.md verify if :

there are helper classes in GenRevive for the given input or output technology to install dependencies that are needed for the migration (like angular_package_installer.py).  If yes add usage of this helpers to the semi_code_migration_plan.md in a form like AdfProjectCleaner().execute(). End the current task. 
if helper classes do not exist but technical knowledge of input or output architecture implies that some additional actions are needed
 Create a semi code definition a PrerequisiteInstaller class and add it to semi_code_migration_plan.md
add information of what needs to be done as the prerequisite actions for migration to the comments section of the PrerequisiteInstaller class. Suggest what existing GenRevive helpers, cookbooks, callbacks can be used.
Expected Output: updated semi_code_migration_plan.md



Task3:

Description: Prepare abstract activity class for creation of output project. Based on output_architecture_design.md and current_genrevive_abilities.md verify if

a project creator class for the given output technology is already done in GenRevive helpers.
If yes add usage of this creator to the semi_code_migration_plan.md in a form like AngularProjectCreator().execute() or SpringBootProjectCreator().execute(), end the current task.
If not continue to the next step.
Create a semi code definition an <OuptutProjectTye>ProjectCreator class and add it to semi_code_migration_plan.md
based on your output project technology knowledge check if a dedicated CLI for the project creation may be used,
if yes add the CLI usage proposals to the comments of the <OuptutProjectTye>ProjectCreator in semi_code_migration_plan.md. 
If a structure for the output project is defined in output_architecture_design.md  add that piece of information to the comments of the <OuptutProjectTye>ProjectCreator in semi_code_migration_plan.md. 
Expected Output: updated semi_code_migration_plan.md



Task4:

Description: Prepare abstract activity class for migration of data structures. Based on input_architecture.md and output_architecture_design.md and current_genrevive_abilities.md verify if a DB is used in the input application or a DB  is to be used in the output application

If yes

Create a semi code definition  a <DBOutputDefionionType>Creator class and add it to semi_code_migration_plan.md like LiquibaseCreator or SqlSchemaCreator
 In the comments section of the <DBOutputDefionionType>Creator add suggestions where definitions of input DB structures are defined, what DB Structures are desired in the output, and how to implement translation of them in the activity
Expected Output: updated semi_code_migration_plan.md



Task5:

Description: Prepare abstract activity class for creation of a model of DB entities. Based on input_architecture.md and output_architecture_design.md and current_genrevive_abilities.md if a DB is used in the input application or is to be used in the output application

If yes

Create a semi code definition an EntityGenerator class and add it to semi_code_migration_plan.md 
 In the comments section of the EntityGenerator add suggestions
where definitions of input DB entities (e.g. VB Classes in db_entity folder) are defined and what DB entities are desired in the output (e.g. Maven classes in entities folder)
suggest a way to generate entities in the output or how to translate them from the entities defined in the input application (in that case add a warning if input and output DB engines are different - the translated entities may not be compliant)
Expected Output: updated semi_code_migration_plan.md



Task6:

Description: Prepare abstract activity class for creation of a model of DB CRUD repositories. Based on input_architecture.md and output_architecture_design.md and current_genrevive_abilities.md if a DB is used in the input application or is to be used in the output application and the output technology suggest CRUD repository creation

If yes

Create a semi code definition a CrudRepositoryGenerator class and add it to semi_code_migration_plan.md 
 In the comments section of the CrudRepositoryGenerator add suggestions
where definitions of input DB logic are defined (e.g. Oracle stored procedures in a schema.sql file) and what kind of repositories are desired in the output (e.g. JPA repositories located in repositories folder) 
suggest a way to generate repositories and their methods in the output or how to translate them from the DB structure definitions like tables and views in the input application


Expected Output: updated semi_code_migration_plan.md



Task7:

Description: Prepare abstract activity class for the generation of logic of DB repositories . Based on input_architecture.md and output_architecture_design.md and current_genrevive_abilities.md if a DB is used in the input application or is to be used in the output application

If yes

Create a semi code definition of a RepositoryLogicGenerator class and add it to semi_code_migration_plan.md 
 In the comments section of the RepositoryLogicGenerator add suggestions
where definitions of input DB logic are defined (e.g. Oracle stored procedures in a schema.sql file) and what kind of repositories are desired in the output (e.g. JPA repositories located in repositories folder) 
suggest a way to generate repositories and their methods in the output or add logic to existing repositories
suggest a way how to translate them from the DB logic definitions like stored procedures and functions in the input application


Expected Output: updated semi_code_migration_plan.md



Task8:

Description: Prepare abstract activity for a logic migration actions . Based on input_architecture.md and output_architecture_design.md and current_genrevive_abilities.md

Create a semi code definition of a CodeGenerator class and add it to semi_code_migration_plan.md 
 In the comments section of the CodeGenerator add suggestions
where definitions of input logic are defined (e.g. logic in *. VB files in the component_logic folder) and what kind of logic classes are desired in the output (e.g. Java service classes in the services) 
suggest a way to split bigger logic inputs into smaller ones  and how to generate classes and methods in the output
suggest a way how to translate logic from input components into the  logic of the output application


Expected Output: updated semi_code_migration_plan.md

