# GenRevive Framework Capabilities Analysis

## Framework Overview

**GenRevive** is a comprehensive Python-based code migration framework designed to automate the process of migrating applications from one technology stack to another. It provides a structured approach using abstract activities, reusable helpers, and CrewAI integration for AI-driven code generation.

## Abstract Classes

### BaseActivity
**Location**: `genrevive.core.base_activity`

**Purpose**: Fundamental building block for simple, synchronous migration activities

**Features**:
- Abstract `execute()` method that must be implemented
- Lightweight design for straightforward operations
- No AI integration - pure Python logic
- Direct execution model

**When to Use**:
- File operations (copying, moving, creating projects)
- Configuration updates
- Simple transformations
- npm/Maven commands
- Project scaffolding

### GenAIActivity  
**Location**: `genrevive.core.gen_ai_activity`

**Purpose**: Advanced AI-powered migration activities using CrewAI

**Features**:
- **CrewAI Integration**: Multi-agent orchestration for complex code generation
- **Memory Management**: Persistent memory across migration sessions
- **Embedding Configuration**: Vector database support for semantic search
- **MCP Tool Integration**: External tools via Model Context Protocol
- **Agent & Task Factories**: Configurable AI agents and tasks
- **Callback Support**: Extensible callback system for output processing
- **LLM Provider Support**: Multiple LLM backends (Azure OpenAI, etc.)
- **Knowledge Management**: Cookbook and prompt integration

**Key Components**:
- `setup_general_configuration()`: Base LLM and embedding setup
- `setup_cookbooks_and_prompts()`: Load development guidelines
- `setup_agents()`: Configure AI agents with roles and capabilities
- `setup_tasks()`: Define agent tasks and workflows
- `execute()`: Run the CrewAI crew and process results

**When to Use**:
- Code generation and translation
- Architecture analysis and transformation
- Complex business logic migration
- Multi-step reasoning tasks
- Pattern recognition and adaptation

## Helpers

### Angular Helpers (`genrevive.helpers.angular`)

**Supported Angular Versions**: 16-20 (NgModule and Standalone components)

#### `angular_project_creator.py`
- **Function**: `create_angular_project()`
- **Purpose**: Initialize new Angular projects with version/architecture options
- **Parameters**: 
  - `angular_version`: CLI version (16-20)
  - `standalone`: Enable standalone components (boolean)
  - `routing`: Include Angular Router (boolean)
- **Features**: Supports both traditional NgModule and modern standalone architectures

#### `angular_component_creator.py`
- **Function**: `create_angular_component()`
- **Purpose**: Generate Angular components with CLI version compatibility
- **Configuration**: Standalone component support, version-specific generation

#### `angular_build_tool.py`
- **Purpose**: Angular build operations with configurable CLI versions
- **Features**: Caching, version management, build optimization

#### `angular_builder.py`
- **Purpose**: Advanced Angular build workflows and configuration management

#### `angular_routing_creator.py`
- **Purpose**: Generate and configure Angular routing modules
- **Features**: Route generation, lazy loading setup, guard creation

#### `angular_openapi.py`
- **Function**: `generate_client()`
- **Purpose**: Generate Angular services from OpenAPI specifications
- **Features**: TypeScript interfaces, HTTP client integration, configuration options

### Java Helpers (`genrevive.helpers.java`)

#### `java_code_parser.py`
- **Purpose**: Parse and analyze Java source code
- **Features**: AST parsing, class structure extraction, dependency analysis

#### `maven_builder.py` & `maven_build_tool.py`
- **Purpose**: Maven build operations and project management
- **Features**: Dependency resolution, build lifecycle management, multi-module projects

#### `spring_boot_extractor.py`
- **Purpose**: Extract Spring Boot application structure and configuration
- **Features**: Annotation analysis, configuration property extraction, bean discovery

### Common Helpers (`genrevive.helpers.common`)

#### `file_utils.py`
- **Purpose**: File system operations and utilities
- **Functions**: 
  - `find_files_in_directory()`: Recursive file discovery with patterns
  - File reading/writing with encoding support
  - Directory management operations

#### `shell_utils.py`
- **Functions**:
  - `run_command()`: Execute shell commands with output capture
  - `get_local_command_path()`: Locate CLI tools in system PATH
- **Features**: Cross-platform command execution, error handling

#### `logger.py`
- **Decorator**: `@log_activity_execution`
- **Purpose**: Activity execution logging and monitoring
- **Features**: Execution time tracking, error logging, debug output

#### `markdown_renderer.py`
- **Purpose**: Render and process Markdown content
- **Features**: Template processing, content generation for documentation

#### `content_minifier.py`
- **Purpose**: Optimize and compress generated content
- **Features**: Code minification, whitespace optimization

#### `crewai_knowledge.py`
- **Purpose**: CrewAI knowledge base integration
- **Features**: Knowledge embedding, semantic search, context retrieval

#### `merge_tools.py`
- **Purpose**: Merge and combine generated code artifacts
- **Features**: Conflict resolution, code integration utilities

#### `system_prompts_loader.py`
- **Purpose**: Load and manage AI system prompts
- **Features**: Template loading, prompt customization, context injection

#### `tracing.py`
- **Purpose**: Execution tracing and debugging support
- **Features**: Performance monitoring, execution flow tracking

### NPM Helpers (`genrevive.helpers.npm`)

#### `package_installer.py`
- **Function**: `local_npm_install_packages()`
- **Purpose**: Install NPM packages in target projects
- **Features**: Version specification, dependency management, local installation

### SQL Helpers (`genrevive.helpers.sql`)
- **Purpose**: Database schema migration and SQL operations
- **Features**: Schema analysis, query generation, database compatibility

### ADF Helpers (`genrevive.helpers.adf`)
- **Purpose**: Azure Data Factory migration support
- **Features**: Pipeline conversion, data flow transformation

### OpenRewrite Helpers (`genrevive.helpers.openrewrite`)
- **Purpose**: Java code refactoring using OpenRewrite recipes
- **Features**: Automated code modernization, dependency updates

### Spring Boot Helpers (`genrevive.helpers.spring_boot`)
- **Purpose**: Spring Boot specific migration utilities
- **Features**: Configuration migration, annotation updates, version upgrades

---

## Cookbooks

Cookbooks provide development guidelines and coding standards for AI agents during code generation.

### Software Engineer Cookbook (`se-cookbook.md`)
- **Purpose**: Define coding standards and implementation guidelines
- **Content**: 
  - Component naming conventions
  - Implementation patterns
  - Code quality rules
  - Best practices for target technology
- **Usage**: Loaded by GenAIActivity during agent setup

### Software Reviewer Cookbook (`sr-cookbook.md`)
- **Purpose**: Code review and quality assurance guidelines
- **Content**:
  - Review criteria and standards
  - Error detection patterns
  - Quality validation rules
  - Improvement suggestions
- **Usage**: Used by reviewer agents for code validation

### DevOps Cookbook (`devops-prompt.md`)
- **Purpose**: Deployment and infrastructure guidelines (optional)
- **Content**: 
  - Deployment patterns
  - Infrastructure configuration
  - CI/CD integration
- **Usage**: Optional cookbook for deployment-related tasks

### Customization
- Cookbooks are markdown files that can be customized per migration scenario
- Support templating and dynamic content injection
- Integration with system prompts and agent configuration

---

## Tools

### CrewAI Built-in Tools
GenRevive leverages CrewAI's tool ecosystem:
- **File Management**: Read, write, and manipulate files
- **Web Scraping**: Extract information from web sources
- **Code Analysis**: Parse and understand source code
- **Documentation**: Generate and format documentation

### MCP (Model Context Protocol) Tools
External tools integrated via MCP servers:
- **Filesystem Tools**: Enhanced file operations with path restrictions
- **Custom Tools**: Project-specific utilities loaded from JSON configuration
- **Version Control**: Git operations and repository management
- **Build Tools**: Maven, Gradle, npm integration through MCP

### Shell Tools
Command-line integration:
- **CLI Execution**: Run Angular CLI, Maven, npm commands
- **Build Operations**: Execute build pipelines and scripts
- **Testing**: Run test suites and validation scripts

---

## MCPs (Model Context Protocol)

### MCP Connection Manager (`mcp_connection_manager.py`)
**Purpose**: Manage persistent connections to multiple MCP servers

**Features**:
- **Multi-server Support**: Connect to multiple MCP servers simultaneously
- **Tool Aggregation**: Combine tools from different servers with unique naming
- **Connection Persistence**: Maintain connections across activity execution
- **Error Handling**: Robust connection management and recovery

**Configuration**:
- Environment variable `ENABLE_MCP_SERVER`: Enable/disable MCP integration
- Server configurations loaded from JSON or environment variables

### Default MCP Servers (`mcp_servers_configuration.py`)

#### Filesystem Server
- **Purpose**: Secure filesystem operations with path restrictions
- **Version**: Configurable (default: 2025.7.1)
- **Configuration**: 
  - `FILESYSTEM_ALLOWED_DIRS`: Comma-separated allowed paths
  - `FILESYSTEM_SERVER_VERSION`: Server version override
- **Tools**: File read/write operations within allowed directories

#### Custom Servers
- **Configuration**: `MCP_JSON_FILE_PATH` environment variable
- **Format**: JSON configuration file with server definitions
- **Support**: Both stdio and URL-based servers (SSE/HTTP)

## Callbacks

### Built-in Callbacks (`callbacks.py`)

#### `save_code_blocks()`
**Purpose**: Extract and save code blocks from AI-generated output

**Features**:
- **Pattern Matching**: Regex-based extraction of code blocks with filenames
- **Directory Creation**: Automatic directory structure creation
- **File Writing**: Save extracted code to specified file paths
- **Encoding Support**: UTF-8 encoding for international characters
