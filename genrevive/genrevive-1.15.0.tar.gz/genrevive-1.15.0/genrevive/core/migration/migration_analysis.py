import os
from dotenv import load_dotenv

from genrevive.core.callbacks import save_full_markdown_report
from genrevive.core.gen_ai_activity import GenAIActivity
from genrevive.core.task_factory import TaskFactory
from genrevive.core.agent_factory import AgentFactory
from genrevive.core.common_tools.save_file_tool import save_file_tool
from genrevive.core.common_tools.read_file_tool import read_file_tool
from genrevive.helpers.common.file_utils import FileUtils
from genrevive.helpers.common.markdown_renderer import MarkdownRenderer


class Migration_analysis(GenAIActivity):
    def __init__(self):
        self.origin_project_path = ""
        self.target_project_path = ""

        # Task prompt for single comprehensive migration analysis
        self.migration_analysis_prompt = ""

        # Source documents
        self.capabilities = ""
        self.input_design = ""
        self.output_design = ""
        self.task_definitions = ""

        # Agent
        self.migration_expert = None

        load_dotenv(override=True)
        super().__init__()

    def setup_general_configuration(self):
        self.output_path = os.environ["OUTPUT_PATH"]

    def setup_agents(self):

        self.origin_technology = os.environ["ORIGIN_TECHNOLOGY"]
        self.target_technology = os.environ["TARGET_TECHNOLOGY"]

        self.migration_expert = AgentFactory().migration_expert(
            self.origin_technology, self.target_technology, [], []
        )
        self.agents = [self.migration_expert]

    def setup_tasks(self):
        self.__append_migration_analysis_task()

    def __append_migration_analysis_task(self):
        self.input_design = FileUtils.read_file(
            os.environ["ME_INPUT_DESIGN_FILE"]
        )
        self.output_design = FileUtils.read_file(
            os.environ["ME_OUTPUT_DESIGN_FILE"]
        )
        input_data = {
            "input_design": self.input_design,
            "output_design": self.output_design,
        }

        # Get the project root directory
        project_root = os.path.dirname(self.output_path)
        report_path = os.path.join(
            project_root, self.output_path, "migration_analysis_report.md"
        )

        task = TaskFactory().task_migration_analysis(
            agent=self.migration_expert,
            prompt="Task: Description: Prepare a list of tasks for a migration developer who uses GenInsight library. Each task should be related to creating one abstract class for a migration activity. This list should be based on information given by input design, which describes current architecture of the application, and output design, which describes desired architecture of that application. Important: dont use any non utf-8 characters",
            expected_output="Detailed migration analysis report with step-by-step migration plan",
            input=MarkdownRenderer.render_dict_to_markdown(input_data),
            target_file_path=report_path,
            callback=lambda output: save_full_markdown_report(
                output, filename=report_path
            ),
        )

        task2 = TaskFactory().task_quality_confirmation(
            agent=self.migration_expert,
            prompt=f"Do this after you give agent final answer: ask user to confirm the migration analysis report, it is located in {os.environ['MD_INPUT_DESIGN_FILE']} You can use read_file_tool and save_file_tool. "
            "Important! always ask using this exact wording once you produce result: 'If you want to make changes to the report, type your suggested changes and press 'Enter'. If you do not want to apply any changes, type 'confirm' and press 'Enter'."
            f"You can take a look at the final report here: {os.environ['MD_INPUT_DESIGN_FILE']}'",
            expected_output="",
            input=MarkdownRenderer.render_dict_to_markdown(input_data),
            target_file_path=report_path,
            callback=lambda output: save_full_markdown_report(
                output, filename=report_path
            ),
            tools=[read_file_tool, save_file_tool],
        )

        self.tasks.append(task)
        self.tasks.append(task2)
