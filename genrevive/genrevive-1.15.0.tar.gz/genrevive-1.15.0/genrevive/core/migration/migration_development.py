import os
from dotenv import load_dotenv

from genrevive.core.callbacks import save_code_blocks
from genrevive.core.gen_ai_activity import GenAIActivity
from genrevive.core.task_factory import TaskFactory
from genrevive.helpers.common.file_utils import FileUtils
from genrevive.core.common_tools.save_file_tool import save_file_tool
from genrevive.core.common_tools.read_file_tool import read_file_tool

from genrevive.core.agent_factory import AgentFactory


class Migration_development(GenAIActivity):
    def __init__(self):
        self.generated_activities_directory = ""

        # Task prompt for migration development
        self.migration_development_prompt = ""

        # Source documents
        self.capabilities = ""
        self.input_design = ""
        self.task_definitions = ""

        # Agent
        self.migration_expert = None

        load_dotenv(override=True)
        super().__init__()

    def setup_general_configuration(self):
        self.generated_activities_directory = os.environ[
            "GENERATED_ACTIVITIES_DIRECTORY"
        ]

    def setup_cookbooks_and_prompts(self):
        # Load source documents
        self.input_design = FileUtils.read_file(
            os.environ["MD_INPUT_DESIGN_FILE"]
        )

    def setup_agents(self):
        self.origin_technology = os.environ["ORIGIN_TECHNOLOGY"]
        self.target_technology = os.environ["TARGET_TECHNOLOGY"]
        self.migration_developer = AgentFactory().migrator_developer(
            self.origin_technology, self.target_technology, [], []
        )
        self.agents = [self.migration_developer]

    def setup_tasks(self):
        # Create single comprehensive migration development task
        self.__append_migration_analysis_task(self.input_design)

    def __append_migration_analysis_task(self, input_design):

        # Get the directory of this file and construct path to migration_development_task.md
        current_dir = os.path.dirname(os.path.abspath(__file__))
        task_file_path = os.path.join(
            current_dir, "migration_developer", "migration_development_task.md"
        )

        self.tasks.append(
            TaskFactory().task_migration_analysis(
                agent=self.migration_developer,
                prompt=FileUtils.read_file(task_file_path),
                expected_output="A collection of incompleted generated activities which are meant to be completed by human developers.",
                input=input_design,
                target_file_path=self.generated_activities_directory,
                callback=save_code_blocks,
            )
        )

        self.tasks.append(
            TaskFactory().task_quality_confirmation(
                agent=self.migration_developer,
                prompt=f"Do this after you give agent final answer: ask user to confirm the migration developer, it is located in {os.environ['GENERATED_ACTIVITIES_DIRECTORY']}. You can use read_file_tool and save_file_tool. "
                "Important! always ask using this exact wording once you produce result: 'If you want to confirm the migration analysis report, type confirm. If you want to make changes to the report, type your changes and press enter.'",
                expected_output="",
                input=input_design,
                target_file_path=self.generated_activities_directory,
                callback=save_code_blocks,
                tools=[read_file_tool, save_file_tool],
            )
        )
