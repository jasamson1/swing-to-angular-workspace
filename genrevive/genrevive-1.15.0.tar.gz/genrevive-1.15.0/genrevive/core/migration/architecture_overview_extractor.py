import os
import logging
from dotenv import load_dotenv

from genrevive.core.callbacks import save_full_markdown_report
from genrevive.core.base_activity import BaseActivity
from genrevive.core.task_factory import TaskFactory
from genrevive.helpers.common.file_utils import FileUtils
from genrevive.core.agent_factory import AgentFactory
from genrevive.helpers.common.markdown_parser import MarkdownParser

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


class Architecture_overview_extractor(BaseActivity):
    def __init__(self):
        self.output_path = os.environ["OUTPUT_PATH"]
        self.source_docs_path = os.environ.get("ME_INPUT_DESIGN_FILE")

    def execute(self):
        # Read the DeepWiki output file dynamically
        deepwiki_dir = os.path.join(self.output_path, "input", "deepwiki")
        if os.path.exists(deepwiki_dir):
            files = [f for f in os.listdir(deepwiki_dir) if f.endswith(".md")]
            deepwiki_content = (
                FileUtils.read_file(os.path.join(deepwiki_dir, files[0]))
                if files
                else ""
            )
        else:
            error_msg = f"DeepWiki directory not found: {deepwiki_dir}. Cannot proceed with architecture overview extraction."
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)

        markdown_parser = MarkdownParser(deepwiki_content)
        architecture_overview_content = markdown_parser.extract_sections(
            "Architecture Overview"
        )
        FileUtils.write_file(
            self.source_docs_path, "\n\n".join(architecture_overview_content)
        )
