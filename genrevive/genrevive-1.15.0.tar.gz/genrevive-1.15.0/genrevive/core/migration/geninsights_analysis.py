import os
from dotenv import load_dotenv

from genrevive.core.callbacks import save_full_markdown_report
from genrevive.core.gen_ai_activity import GenAIActivity
from genrevive.core.task_factory import TaskFactory
from genrevive.helpers.common.merge_tools import get_tool_by_name
from genrevive.core.agent_factory import AgentFactory


class GenInsights_analysis(GenAIActivity):
    def __init__(self):
        self.origin_project_path = ""
        self.output_path = ""

        # Agent
        self.migration_expert = None

        load_dotenv(override=True)
        super().__init__()

    def setup_general_configuration(self):
        self.output_path = os.environ["OUTPUT_PATH"]
        self.origin_technology = os.environ["ORIGIN_TECHNOLOGY"]
        self.target_technology = os.environ["TARGET_TECHNOLOGY"]

    def setup_agents(self):

        self.origin_technology = os.environ["ORIGIN_TECHNOLOGY"]
        self.target_technology = os.environ["TARGET_TECHNOLOGY"]

        self.migration_expert = AgentFactory().migration_expert(
            self.origin_technology, self.target_technology, [], []
        )
        self.agents = [self.migration_expert]

    def setup_tasks(self):
        self.__append_acquire_geninsights_analysis()

    def __build_geninsights_prompt(self):
        """Build GenInsights analysis prompt with configuration parameters."""
        source_folder = os.environ.get("INPUT_CODE_PATH")
        code_language = os.environ.get("SOURCE_CODE_LANGUAGE")
        modules = os.environ.get("GENINSIGHTS_MODULES")
        output_folder = (os.environ.get("GENINSIGHTS_ANALYSIS_OUTPUT_FOLDER"),)

        prompt = f"""# GenInsights Code Analysis Task

        ## Objective
        Analyze the source codebase using GenInsights MCP to generate comprehensive technical documentation from DeepWiki Module.

        Here is your source code for the analysis: {source_folder}, which is primarily written in {code_language}
        The analysis should be strictly done using just these modules: {modules}.
        Deep wiki report must be save here: {output_folder}
        """
        return prompt

    def __append_acquire_geninsights_analysis(self):
        gen_insights_tool = get_tool_by_name(
            self.tools, "geninsights_start_geninsights_with_configuration"
        )

        task = TaskFactory().task_migration_analysis(
            agent=self.migration_expert,
            prompt=self.__build_geninsights_prompt(),
            expected_output="Detailed analysis report from GenInsights",
            input="",
            target_file_path=f"{self.output_path}/deepwiki_report.md",
            tools=[gen_insights_tool],
            callback=save_full_markdown_report,
        )
        self.tasks.append(task)
        return task
