import os
import json
import logging
import re


def _substitute_env_variables(data):
    """
    Recursively substitute environment variables in the configuration data.

    Environment variables should be specified in the format ${VAR_NAME}.

    Args:
        data: The data structure (dict, list, str, etc.) to process

    Returns:
        The data structure with environment variables substituted

    Raises:
        ValueError: If a required environment variable is not found
    """
    if isinstance(data, dict):
        return {key: _substitute_env_variables(value) for key, value in data.items()}
    elif isinstance(data, list):
        return [_substitute_env_variables(item) for item in data]
    elif isinstance(data, str):
        # Find all ${VAR_NAME} patterns in the string
        env_var_pattern = r"\$\{([^}]+)\}"
        matches = re.findall(env_var_pattern, data)

        result = data
        for env_var in matches:
            env_value = os.getenv(env_var)
            if env_value is None:
                raise ValueError(
                    f"Required environment variable '{env_var}' is not set"
                )

            # Replace ${VAR_NAME} with the actual environment variable value
            result = result.replace(f"${{{env_var}}}", env_value)
            logging.debug(
                f"Substituted environment variable '{env_var}' in embedding configuration"
            )

        return result
    else:
        # Return other types (int, float, bool, None) as-is
        return data


def get_embedding_configuration(embedder_key):
    """
    Loads a specific embedding configuration from a JSON file specified by environment variable.

    Args:
        embedder_key (str): The key in the JSON file that specifies which embedder to extract.

    Environment Variables:
        EMBEDDING_CONFIG_JSONFILE_PATH (str): Path to the JSON file containing embedding configurations.

    Returns:
        dict: The configuration dictionary with 'provider' and 'config' keys.

    Raises:
        ValueError: If embedder_key is None, the environment variable is missing,
                    the file doesn't exist, the file can't be parsed, or the embedder config is missing/incomplete.
    """
    if embedder_key is None:
        raise ValueError(
            "No embedder key provided. Please specify which embedder to load."
        )

    json_path = os.getenv("EMBEDDING_CONFIG_JSONFILE_PATH")
    if not json_path:
        raise ValueError(
            "Environment variable 'EMBEDDING_CONFIG_JSONFILE_PATH' is not set."
        )

    if not os.path.isfile(json_path):
        raise ValueError(
            f"The file specified in 'EMBEDDING_CONFIG_JSONFILE_PATH' does not exist: {json_path}"
        )

    try:
        with open(json_path, "r", encoding="utf-8") as f:
            json_data = json.load(f)
    except Exception as e:
        raise ValueError(
            f"Failed to read or parse embedding configuration JSON file: {e}"
        )

    # Substitute environment variables in the entire configuration
    json_data = _substitute_env_variables(json_data)

    # Extract the requested embedder configuration
    return _load_embedder_config(json_data, embedder_key)


def _load_embedder_config(json_data, key):
    embedder = json_data.get(key)
    if embedder and "provider" in embedder and "config" in embedder:
        logging.info(f"{key} configuration loaded successfully")
        return embedder
    raise ValueError(
        f"Embedder configuration for key '{key}' is missing or incomplete."
    )
