from abc import ABC, abstractmethod


class BaseActivity(ABC):
    @abstractmethod
    def execute(self):
        pass
