import os
import logging
from crewai_tools import MCPServerAdapter
from genrevive.core.mcp_servers_configuration import (
    get_configured_mcp_server_params,
)


class MCPConnectionManager:
    """
    Manages persistent connections to multiple MCP servers and
    aggregates tools with unique names.
    """

    _instances = []
    _tools = []

    @classmethod
    def get_connection(cls):
        """
        Returns a combined list of uniquely named tools from all
        MCP servers.
        """
        if not cls._instances:
            cls._connect_all()
        return cls._tools

    @classmethod
    def _connect_all(cls):
        enable_mcp = (
            os.getenv("ENABLE_MCP_SERVER", "false").lower() == "true"
        )
        if not enable_mcp:
            logging.info("MCP connection disabled.")
            return

        try:
            server_params_list = get_configured_mcp_server_params()
            if not server_params_list:
                raise RuntimeError(
                    "No MCP server parameters found. "
                    "Please check your configuration."
                )

            for server in server_params_list:
                server_name = server["server_name"]
                server_config = server["server_config"]

                adapter = MCPServerAdapter([server_config])
                adapter.__enter__()  # Keep connection alive
                cls._instances.append(adapter)

                for tool in adapter.tools:
                    original_tool_name = tool.name
                    new_tool_name = f"{server_name}_{original_tool_name}"
                    tool.name = new_tool_name

                    if hasattr(tool, "description") and isinstance(
                        tool.description, str
                    ):
                        tool.description = tool.description.replace(
                            f"Tool Name: {original_tool_name}",
                            f"Tool Name: {new_tool_name}",
                        )

                    cls._tools.append(tool)

                logging.info(f"Connected to MCP server '{server_name}'")
                tool_names = [tool.name for tool in adapter.tools]
                logging.info(
                    f"Tools from '{server_name}': {tool_names}"
                )

        except Exception as e:
            logging.error(
                f"Failed to connect to MCP servers: {e}",
                exc_info=True,
            )
            cls._instances.clear()
            cls._tools.clear()
            raise
