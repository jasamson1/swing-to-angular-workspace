import os
from dotenv import load_dotenv

from genrevive.core.gen_ai_activity import GenAIActivity
from genrevive.core.task_factory import TaskFactory
from genrevive.core.agent_factory import AgentFactory
from genrevive.core.building_fixing.devops_tool_multicrew import (
    DevOpsToolMultiCrew,
)
from genrevive.core.edit_text_tool.text_editor_chunking_tools import (
    create_text_editor_tools,
)
from genrevive.core.common_tools.save_file_tool import save_file_tool
from genrevive.helpers.common.crewai_knowledge import KnowledgeFactory
from genrevive.helpers.common.system_prompts_loader import (
    load_system_prompts_templates,
)


class ProjectBuilderActivity(GenAIActivity):
    """
    Utility class for BuilderFixer that encapsulates the build-and-fix execution logic.

    This class is located in the building_fixing module rather than within the migrator
    template implementation although it is a reusable utility component that in theory can be invoked
    by any migration workflow.
    """

    def __init__(self, withCallback: bool = False):
        self.target_project_path = ""

        self.devops_prompt = ""
        self.devops_cookbook = ""  # Optional DevOps cookbook

        self.devops_engineer = None
        self.bug_fixer = None
        self.withCallback = withCallback

        load_dotenv(override=True)
        self.origin_technology = os.environ["ORIGIN_TECHNOLOGY"]
        self.target_technology = os.environ["TARGET_TECHNOLOGY"]
        self.origin_input = os.environ["ORIGIN_INPUT"]
        self.target_output = os.environ["TARGET_OUTPUT"]
        self.compiler_technology = os.environ["COMPILER_TECHNOLOGY"]
        self.save_file_tool = save_file_tool
        super().__init__()

    def setup_general_configuration(self):
        self.target_project_path = os.environ["TARGET_PROJECT_PATH"]

    def setup_agents(self):

        self.devops_engineer = AgentFactory().devops_engineer(
            self.target_technology, self.compiler_technology, []
        )
        # Allow agent to retry even if it thinks it's done
        self.devops_engineer.allow_delegation = False

        # Override the agent's role to force proper behavior
        self.devops_engineer.role = "DevOps Build Engineer"
        self.devops_engineer.goal = "Run builds to detect compilation errors and fix them by editing source files until the project builds successfully"

        embedder = KnowledgeFactory.get_global_embedder_config()
        llm_kwargs = {}
        system_template, prompt_template = load_system_prompts_templates("DIF")
        self.bug_fixer = AgentFactory().bug_fixer_se(
            tools=[],  # Tools will be set later
            embedder=embedder,
            system_template=system_template,
            prompt_template=prompt_template,
            **llm_kwargs
        )

        self.agents = [self.devops_engineer, self.bug_fixer]

    def setup_tasks(self):
        self.__append_devops_task()

    def __append_devops_task(self):
        self.tasks.append(self.create_devops_task())

    def create_devops_task(self):
        from genrevive.core.callbacks import run_building_and_fixing_loop

        callback_function = None

        if self.withCallback:
            callback_function = run_building_and_fixing_loop

        # Create text editor tools - these allow the agent to modify source files
        # verify_hash=False allows the DevOpsTool to also modify files without conflicts
        # Pass as a list to avoid iterating over string characters
        edit_text = create_text_editor_tools(
            [self.target_project_path], verify_hash=False
        )

        # DevOpsTool is used to run builds and detect compilation errors
        # It should NOT modify source files - only the text editor tools should
        devops = DevOpsToolMultiCrew(
            devops_engineer=self.devops_engineer,
            bug_fixer=self.bug_fixer,
            verify_hash=False,
            target_project_path=self.target_project_path,
        )

        tools = [devops] + edit_text

        if self.devops_cookbook:
            print(" DevOps cookbook loaded.")
        else:
            print(" DevOps cookbook not found. Proceeding without it.")

        # Added support for optional DevOps cookbook
        return TaskFactory().task_code_build(
            devops_engineer=self.devops_engineer,
            devops_prompt=self.devops_prompt,
            cookbook=self.devops_cookbook,
            tools=tools,
            callback=callback_function,
            context=[]
        )
