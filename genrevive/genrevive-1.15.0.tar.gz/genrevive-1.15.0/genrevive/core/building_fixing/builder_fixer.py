import logging
import sys
from chromadb import logger
from dotenv import load_dotenv
from genrevive.helpers.common.logger import Logger

from genrevive.core.building_fixing.project_builder_activity import (
    ProjectBuilderActivity,
)

logging.root.setLevel(level=logging.INFO)
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


class BuilderFixer:
    def build_and_fix(self, iterations: int = 0) -> str:
        """
        Iteratively builds and fixes the project until successful or max iterations reached.

        Usage in a migration context:

        NO_CHUNKING mode:
            1. create_mocks()  # migration teams create mocks
            2. For every file:
                - SE_ENG.TASK_TRANSFORM()
                - SE_ENG.REVIEW()
                - DEVOPS.BUILD() - with delegation (not build_and_fix)

        CHUNKING mode:
            1. create_mocks()  # migration teams create mocks
            2. For every file:
                - SE_ENG.TASK_TRANSFORM()
                - SE_ENG.REVIEW()
                - DEVOPS.BUILD() use a task from project_builder_activity with build_and_fix callback, no delegation.

        Args:
            iterations: Maximum number of build attempts (0 means no limit)

        Returns:
            str: Build result information
        """

        load_dotenv()
        sys.stdout = Logger()

        idx = 0
        build_success = False
        while not build_success and (iterations == 0 or idx < iterations):
            logger.info(f"=== Build Iteration {idx} ===")
            target_builder = ProjectBuilderActivity()
            result = target_builder.execute()
            Logger().write(f"Build Iteration {idx} Result: {result}\n")

            # Check if build succeeded by examining the crew result
            if result:
                result_str = str(result)
                build_success = self.is_build_successful(result_str)
            logger.info(f"Build {'succeeded' if build_success else 'failed'}")
            idx += 1

    @staticmethod
    def is_build_successful(result_str: str) -> bool:
        """
        Analyzes the output to determine if the build was successful.

        Args:
            output (TaskOutput): The output from the build process.

        Returns:
            bool: True if the build was successful, False otherwise.
        """
        build_success = False

        # "Done" indicates successful build
        if "Done" in result_str:
            build_success = True
        elif "build_success = 'False'" in result_str:
            build_success = False
        else:
            # Fallback to text-based detection
            build_success = (
                "BUILD SUCCESS" in result_str
                or "build successfully" in result_str.lower()
                or "Done" in result_str
            )

        return build_success
