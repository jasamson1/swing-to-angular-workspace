import os
from dotenv import load_dotenv
from crewai import Agent, Task
from crewai.tools import BaseTool
from pydantic import BaseModel, Field
from genrevive.core.task_factory import TaskFactory
from genrevive.helpers.java.maven_build_tool import MavenBuildTool
from genrevive.core.edit_text_tool.text_editor_chunking_tools import (
    create_text_editor_tools,
)


class DevOpsToolInput(BaseModel):
    """Input schema for DevOpsTool."""


class DevOpsToolMultiCrew(BaseTool):
    name: str = "DevOpsMultiCrew tool"
    description: str = "Call to execute task and get build results."
    args_schema: type[BaseModel] = DevOpsToolInput
    devops_engineer: Agent = Field(...)
    bug_fixer: Agent = Field(...)
    verify_hash: bool = Field(True)
    build_error: bool = Field(False)
    target_project_path: str = Field(...)

    def __init__(
        self,
        devops_engineer: Agent,
        bug_fixer: Agent,
        target_project_path: str,
        verify_hash: bool = True,
        **kwargs,
    ):
        load_dotenv()

        super().__init__(
            devops_engineer=devops_engineer,
            bug_fixer=bug_fixer,
            verify_hash=verify_hash,
            build_error=kwargs.get("build_error", False),
            target_project_path=target_project_path,
            **kwargs,
        )

    def _run(self) -> str:
        import logging

        logger = logging.getLogger(__name__)
        logger.info(f"DevOpsTool._run: self.verify_hash={self.verify_hash}")

        target_project_path = os.environ.get(
            "TARGET_PROJECT_PATH", "C:/PROJECTS/INPUT/sumit"
        )

        # Setup tools and configure agents
        text_editor_tools = create_text_editor_tools(
            verify_hash=self.verify_hash
        )
        for tool in text_editor_tools:
            if hasattr(tool, "_verify_hash"):
                logger.info(
                    f"Created {tool.name} with _verify_hash={tool._verify_hash}"
                )

        devops_tools = [
            MavenBuildTool(
                with_tests=False,
                verify_hash=self.verify_hash,
                caches_success_only=True,
            )
        ]
        engineer_tools = list(text_editor_tools)

        if self.bug_fixer:
            self.bug_fixer.max_iter = 3
        self.devops_engineer.max_iter = 1

        build_task: Task = TaskFactory().task_code_build_and_extract_errors(
            devops_engineer=self.devops_engineer,
            target_project_path=target_project_path,
            devops_tools=devops_tools,
            cookbook=None,
        )

        fix_task: Task = TaskFactory().task_fix_only_one_error_from_list(
            software_engineer=self.bug_fixer,
            target_project_path=target_project_path,
            cookbook=None,
            text_editor_tools=engineer_tools,
        )

        build_task.context = None
        build_output = build_task.execute_sync(
            agent=self.devops_engineer, tools=devops_tools
        )

        logger.info(f"Build output: {build_output.raw[:500]}...")

        # Parse build status
        build_status = self._parse_build_status_from_output(
            build_output.raw, logger
        )
        logger.info(f"Final build_status for iteration: {build_status}")

        if not build_status:
            data = self._execute_fix_task(
                build_output, fix_task, engineer_tools, logger
            )
        else:
            data = self._format_success_output(build_output, logger)

        self.build_error = not build_status
        return "Done" if build_status else self._format_failure_output(data)

    def _parse_build_status_from_output(self, output_raw: str, logger) -> bool:
        """Parse build status from output."""
        output_lower = output_raw.lower()

        # Check for explicit failures first (before success to avoid false positives)
        if (
            "build failure" in output_lower
            or "compilation error" in output_lower
        ):
            logger.info("Detected BUILD FAILURE in output")
            return False

        # Check for success indicators
        if (
            "build success" in output_lower
            or "built successfully" in output_lower
        ):
            logger.info("Detected BUILD SUCCESS in output")
            return True

        # Parse build_success line for explicit status
        for line in output_raw.splitlines():
            if "build_success" in line.lower() and "=" in line:
                try:
                    build_success_str = line.split("=")[1].strip().strip("'\"")
                    logger.info(
                        f"Parsed build_success from line: {line} -> {build_success_str}"
                    )
                    return build_success_str.lower() == "true"
                except (IndexError, AttributeError):
                    pass

        logger.warning(
            "Could not determine build status from output, assuming failure"
        )
        return False

    def _execute_fix_task(
        self, build_output, fix_task, engineer_tools, logger
    ):
        """Execute fix task for build failure."""
        data = f"\n{'='*80}\n\n[BUILD OUTPUT]\n{build_output.raw}\n{'='*80}\n"
        logger.info("Set fix task context for FIXER")
        logger.info(f"Context {data}")
        logger.info("Executing fix task for FIXER")

        fix_output = fix_task.execute_sync(
            agent=self.bug_fixer, tools=engineer_tools, context=data
        )
        data += f"\n[FIX OUTPUT]\n{fix_output.raw}\n{'='*80}\n"
        return data

    def _format_success_output(self, build_output, logger):
        """Format output for successful build."""
        logger.info("Build successful on iteration")
        return f"\n{'='*80}\n=== Final Successful Iteration  ===\n{'='*80}\n\n[BUILD OUTPUT]\n{build_output.raw}\n"

    def _format_failure_output(self, data):
        """Format output for failed build."""
        return f"""build_success = 'False'
                                Build failed - Could not resolve all errors.
                                
                                === BUILD DETAILS ===
                                {data}
                                === END BUILD DETAILS ==="""

    def get_tools(self):
        """Return all available tools for agents."""
        return [
            self.read_file_tool,
            self.edit_file_tool,
            self.delete_lines_tool,
            self.replace_method_tool,  # NEW - add to tools list
            # ...other existing tools...
        ]


def remove_leading_whitespaces(s):
    return "\n".join(line.lstrip() for line in s.splitlines())
