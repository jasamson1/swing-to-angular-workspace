from crewai import Crew
from typing import Optional, Union
from pydantic import Field, field_validator
import logging
from crewai.utilities.formatter import (
    aggregate_raw_outputs_from_task_outputs,
    aggregate_raw_outputs_from_tasks,
)
from crewai.task import Task
from crewai.tasks.task_output import TaskOutput
from typing import List
from crewai.utilities.constants import NOT_SPECIFIED


class GenreviveCrew(Crew):
    context_length: Optional[int] = Field(
        default=None,
        description="Normalized context length (>= 0). If omitted, it is set to the sentinel None. Invalid values normalize to 0.",
    )

    @field_validator("context_length", mode="before")
    def _normalize_context_length(cls, value: Union[str, None]) -> Optional[int]:
        if value is None:  # not present in .env
            return None

        s = str(value).strip()
        if s == "":  # empty string
            return 0
        try:
            parsed = int(s)
            return max(parsed, 0)  # ensure non-negative
        except ValueError:
            return 0  # invalid string → normalize to 0

    # @log_activity_execution
    def _get_context(self, task: Task, task_outputs: List[TaskOutput]) -> str:
        take_all_outputs = self.context_length is None  # not given
        # Case 1: Explicitly empty context
        if task.context is None or not task.context:  # given but None or []/empty list
            logging.info("context is None or empty")
            return ""
        # Case 2: Context not specified → derive from outputs based on context_length
        if task.context is NOT_SPECIFIED:  # no given
            if take_all_outputs:
                logging.info("context is not specified with context_length is None ")
                return aggregate_raw_outputs_from_task_outputs(
                    task_outputs
                )  # aggregate all previous outputs
            if self.context_length == 0:
                logging.info("context is not specified with context_length 0 ")
                return ""
            if self.context_length >= len(task_outputs):
                logging.info(
                    "context is not specified with context_length > previous outputs count"
                )
                return aggregate_raw_outputs_from_task_outputs(
                    task_outputs
                )  # aggregate all outputs

            logging.info(
                "context is not specified with context_length < previous outputs count"
            )
            recent_outputs = task_outputs[-self.context_length :]
            return aggregate_raw_outputs_from_task_outputs(
                recent_outputs
            )  # aggregate all n previous outputs
        # Case 3: Context explicitly provided → aggregate from tasks
        logging.info("context is specified and forms the context")
        return aggregate_raw_outputs_from_tasks(task.context)
