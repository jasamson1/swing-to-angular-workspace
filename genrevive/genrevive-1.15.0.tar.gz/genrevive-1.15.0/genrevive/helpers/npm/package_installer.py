import logging

from genrevive.helpers.common.shell_utils import run_command, get_local_command_path


def local_npm_install_packages(packages: list[str], flags: list[str] = None):
    """
    Uses locally installed version of NPM to install specified packages
    Parameters:
    packages -- specifies the packages to install
    flags -- specifies the additional flags to pass to the npm CLI (default "--save")
    """

    if not flags:
        flags = ["--save"]

    if not packages:
        return

    npm_path = get_local_command_path("npm")
    logging.info(f"Using npm at: {npm_path}")

    command = [npm_path, "install"] + flags + packages
    # Run the command
    run_command(command)
    logging.info(f"Successfully installed packages: {', '.join(packages)}")
