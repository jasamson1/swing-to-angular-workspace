import logging
import xml.etree.ElementTree as elemTree
import re

from genrevive.helpers.common.file_utils import FileUtils


class ADFExtractor:
    def __init__(self, adf_directory_path):
        self.adf_directory_path = adf_directory_path

    def fetch_elements_by_tag(self, element_tag):
        """
        Fetch root elements matching the provided tag from ADF XML files, along with their file paths.
        """
        matching_elements = []
        logging.debug(
            f"Reading ADF XML files from directory: {self.adf_directory_path}"
        )
        xml_files = FileUtils.find_files_in_directory(".xml", self.adf_directory_path)

        for xml_file in xml_files:
            root_element = self.__get_root_element_from_xml(xml_file)
            if root_element is not None and root_element.tag == element_tag:
                matching_elements.append((root_element, xml_file))
                logging.debug(
                    f"Found element with tag: {element_tag} in file: {xml_file}"
                )

        return matching_elements

    def get_all_adf_entities(self):
        """
        Extract all ADF EntityObjects and their corresponding table names from XML files.
        """
        adf_entities = {}
        element_tag = "Entity"

        # Fetch all elements with the specified tag
        entity_elements = self.fetch_elements_by_tag(element_tag)

        # Process the fetched elements to extract specific information
        for element, file_path in entity_elements:
            table_name = element.get("DBObjectName")
            entity_name = element.get("Name")
            if table_name and entity_name:
                adf_entities[entity_name] = {
                    "content": self.__extract_content(element),
                    "table_name": table_name,
                    "file_path": file_path,
                }
                logging.debug(
                    f"Found ADF EntityObject: {entity_name} in file: {file_path}"
                )

        return adf_entities

    def load_adf_entity_objects_order(self, table_order):
        """
        Extract ADF EntityObjects and order them according to table_order.
        """
        # Get all ADF EntityObjects
        adf_entities = self.get_all_adf_entities()

        # Initialize lists to hold the ordered entity names and table names
        ordered_adf_entities = []
        ordered_table_names = []

        # Iterate over the table order and load corresponding entities
        for table_name in table_order:
            for entity_name, entity_info in adf_entities.items():
                if entity_info["table_name"] == table_name:
                    ordered_adf_entities.append(entity_name)
                    ordered_table_names.append(table_name)
                    logging.debug(
                        f"Loaded ADF EntityObject: {entity_name} with table: {table_name}"
                    )
                    break
            else:
                logging.warning(
                    f"Table name '{table_name}' specified in the order is not found in ADF entities."
                )

        # Log the ordered entity names and table names
        logging.info(f"ADF EntityObjects ordered: {ordered_adf_entities}")
        logging.info(f"Corresponding table names ordered: {ordered_table_names}")

        return ordered_adf_entities, ordered_table_names

    def get_table_name_from_adf_entity(self, entity_name):
        """
        Get the table name corresponding to a given ADF EntityObject name.

        :param entity_name: The name of the ADF EntityObject.
        :return: The table name associated with the given entity name, or None if not found.
        """
        logging.debug(f"Retrieving table name for entity: {entity_name}")

        adf_entities = self.get_all_adf_entities()

        if entity_name in adf_entities:
            table_name = adf_entities[entity_name].get("table_name")
            if table_name:
                logging.debug(
                    f"Table name '{table_name}' found for entity '{entity_name}'."
                )
            else:
                logging.warning(
                    f"Entity '{entity_name}' found, but no table name is associated."
                )
        else:
            logging.warning(f"Entity '{entity_name}' not found in ADF entities.")

        return adf_entities.get(entity_name, {}).get("table_name")

    def get_all_adf_associations(self, entity_name):
        """
        Extract all associations related to the given entity name from XML files.
        """
        adf_associations = {}
        association_tag = "Association"

        # Fetch all elements with the specified tag
        association_elements = self.fetch_elements_by_tag(association_tag)

        # Process the fetched elements to extract specific information
        for element, file_path in association_elements:
            if entity_name in elemTree.tostring(element, encoding="unicode"):
                association_name = element.get("Name")
                if association_name:
                    adf_associations[association_name] = {
                        "content": self.__extract_content(element),
                        "file_path": file_path,
                    }
                    logging.debug(
                        f"Found ADF Association: {association_name} related to entity: {entity_name}"
                    )

        return adf_associations

    def get_entity_and_association_descriptors(self, entity_name):
        """
        Get the descriptor content of EntityObjects and related Associations based on the ADF entity name,
        with each surrounded by respective XML tags.
        Exemplary Output:
        <root>
            <Entities>[entity_content]</Entities>
            <Associations>[association_contents]</Associations>
        </root>

        :param entity_name: The name of the entity to search for.
        :return: A string containing the XML structure of the entity and related associations.
                If no descriptors are found, an empty string is returned.
        """
        logging.info(f"Starting to retrieve descriptors for entity: {entity_name}")

        # Retrieve the content for the specific entity
        adf_entities = self.get_all_adf_entities()
        entity_content = adf_entities.get(entity_name, {}).get("content")

        if entity_content:
            logging.info(
                f"Entity '{entity_name}' found. Wrapping content with <Entities> tag."
            )
            entities_xml = f"<Entities>{entity_content}</Entities>"
        else:
            logging.warning(f"Entity '{entity_name}' not found in ADF entities.")
            entities_xml = "<Entities></Entities>"

        # Retrieve the content for the associations related to the specific entity
        adf_associations = self.get_all_adf_associations(entity_name)
        association_contents = "".join(
            [assoc_info["content"] for assoc_info in adf_associations.values()]
        )

        if association_contents:
            logging.info(
                f"Found associations related to entity '{entity_name}'. Wrapping content with <Associations> tag."
            )
            associations_xml = f"<Associations>{association_contents}</Associations>"
        else:
            logging.warning(f"No associations found for entity '{entity_name}'.")
            associations_xml = "<Associations></Associations>"

        # Combine entity and association contents
        combined_content = (entity_content or "") + association_contents

        if combined_content:
            logging.info(
                f"Descriptors successfully retrieved for entity '{entity_name}'."
            )
            return f"<root>{entities_xml + associations_xml}</root>"
        else:
            logging.warning(f"No descriptors found for entity '{entity_name}'.")
            return ""

    def get_all_adf_view_objects(self):
        """
        Extract all ADF ViewObjects and their corresponding details (e.g., name, content) from XML files.
        """
        adf_view_objects = {}
        element_tag = "ViewObject"

        # Fetch all elements with the specified tag and their file paths
        view_object_elements = self.fetch_elements_by_tag(element_tag)

        # Process the fetched elements to extract specific information
        for element, file_path in view_object_elements:
            view_object_name = element.get("Name")
            component_class = element.attrib.get("ComponentClass")
            if view_object_name:
                if view_object_name in adf_view_objects:
                    logging.warning(
                        f"Duplicate ADF ViewObject name: {view_object_name} found in file: {file_path}. Skipping entry."
                    )
                    continue

                # Extract view criteria from the XML element
                view_criteria = self.__get_view_criterias(element)
                query = self.__get_main_query(element)

                adf_view_objects[view_object_name] = {
                    "content": self.__extract_content(element),
                    "file_path": file_path,
                    "component_class": component_class,
                    "view_criteria": view_criteria,
                    "query": query,
                }
                logging.debug(
                    f"Found ADF ViewObject: {view_object_name} in file: {file_path}"
                )

        return adf_view_objects

    def get_vo_content_and_path_by_vo_name(self, vo_name):
        """
        Search for XML ViewObject files by their name and return the content and file path.
        """
        # Get all ViewObjects
        view_objects = self.get_all_adf_view_objects()

        # Check if the requested ViewObject name exists in the extracted ViewObjects
        if vo_name in view_objects:
            # Get the file path for the matched ViewObject
            file_path = view_objects[vo_name]["file_path"]
            content = view_objects[vo_name]["content"]

            return content, file_path

        # Return None if no match is found
        logging.debug(f"No match found for ViewObject: {vo_name}")
        return None, None

    def get_component_class_from_vo(self, vo_name):
        """
        Get the component class corresponding to a given ADF ViewObject name.

        :param vo_name: The name of the ADF ViewObject.
        :return: The component class associated with the given ViewObject name, or None if not found.
        """
        logging.info(f"Retrieving component class for ViewObject: {vo_name}")

        adf_vos = self.get_all_adf_view_objects()

        if vo_name in adf_vos:
            component_class = adf_vos[vo_name].get("component_class")
            if component_class:
                logging.info(
                    f"Component class '{component_class}' found for ViewObject '{vo_name}'."
                )
            else:
                logging.warning(
                    f"ViewObject '{vo_name}' found, but no component class is associated."
                )
        else:
            logging.warning(f"ViewObject '{vo_name}' not found in ADF view objects.")

        return adf_vos.get(vo_name, {}).get("component_class")

    def get_view_criteria_by_vo(self, vo_name):
        """
        Get the view criteria corresponding to a given ADF ViewObject name.

        :param vo_name: The name of the ADF ViewObject.
        :return: The view criteria associated with the given ViewObject name, or an empty list if not found.
        """
        logging.info(f"Retrieving view criteria for ViewObject: {vo_name}")

        adf_vos = self.get_all_adf_view_objects()

        if vo_name in adf_vos:
            view_criteria = adf_vos[vo_name].get("view_criteria")
            if view_criteria:
                logging.info(
                    f"View criteria '{view_criteria}' found for ViewObject '{vo_name}'."
                )
            else:
                logging.warning(
                    f"ViewObject '{vo_name}' found, but no view criteria is associated."
                )
        else:
            logging.warning(f"ViewObject '{vo_name}' not found in ADF view objects.")

        return adf_vos.get(vo_name, {}).get("view_criteria", [])

    def get_sql_query_by_vo(self, vo_name):
        """
        Get the SQL query corresponding to a given ADF ViewObject name.

        :param vo_name: The name of the ADF ViewObject.
        :return: The SQL query associated with the given ViewObject name, or None if not found.
        """
        logging.info(f"Retrieving SQL query for ViewObject: {vo_name}")

        adf_vos = self.get_all_adf_view_objects()

        if vo_name in adf_vos:
            sql_query = adf_vos[vo_name].get("query")
            if sql_query:
                logging.info(f"SQL query found for ViewObject '{vo_name}'.")
            else:
                logging.warning(
                    f"ViewObject '{vo_name}' found, but no SQL query is associated."
                )
        else:
            logging.warning(f"ViewObject '{vo_name}' not found in ADF view objects.")

        return adf_vos.get(vo_name, {}).get("query")

    def __get_view_criterias(self, element):
        """
        Extract ViewCriteria from an XML element of a ViewObject.
        """
        # Find all ViewCriteria elements within the given ViewObject element
        view_criteria = element.findall("ViewCriteria")

        # Dictionary to store view criteria names and their content
        view_criteria_dict = {}

        for vc in view_criteria:
            vc_name = vc.get("Name")
            vc_content = self.__extract_content(vc)
            view_criteria_dict[vc_name] = vc_content

        return view_criteria_dict

    def __get_main_query(self, xml_element):
        """
        Extract SelectList and FromList attributes from the provided XML element
        """
        select_list = (
            xml_element.get("SelectList", "")
            .strip()
            .replace("\n", " ")
            .replace("  ", " ")
        )
        from_list = xml_element.get("FromList", "").strip()
        where = xml_element.get("Where", "").strip()  # Handle optional Where

        if select_list and from_list:
            return self.__build_query_from_attributes(select_list, from_list, where)
        else:
            return self.__get_sql_query_from_element(xml_element)

    def __build_query_from_attributes(self, select_list, from_list, where):
        # Construct SQL query from SelectList and FromList if available
        select_part = f"SELECT {select_list}"
        tables = from_list.split(", ")
        from_part = f"FROM {','.join(tables)}"
        sql_query = select_part + "\n" + from_part

        if where:
            sql_query += f"\nWHERE {where}"

        return sql_query

    def __get_sql_query_from_element(self, xml_element):
        # If SelectList and FromList are not available, look for SQLQuery
        sql_query_element = xml_element.find("SQLQuery")
        if sql_query_element is not None and sql_query_element.text:
            # Return the SQL directly from SQLQuery if available
            return sql_query_element.text.strip()

        # If neither SelectList nor SQLQuery is available, return None
        return None

    def __get_root_element_from_xml(self, xml_file):
        """
        Helper method to get the root element from an XML file.
        """
        try:
            tree = elemTree.parse(xml_file)
            tree = self.__remove_namespace(tree)
            return tree.getroot()
        except elemTree.ParseError as e:
            logging.error(f"Error parsing {xml_file}: {e}")
        except Exception as e:
            logging.error(f"Unexpected error with file {xml_file}: {e}")
        return None

    def __extract_content(self, element):
        content = elemTree.tostring(element, encoding="unicode")
        content = content.strip()
        content = re.sub(r"\s+", " ", content)
        return content

    def __remove_namespace(self, tree):
        for elem in tree.iter():
            if "}" in elem.tag:
                elem.tag = elem.tag.split("}", 1)[1]  # Remove namespace prefix
        return tree
