import logging
import os
import xml.etree.ElementTree as elemTree
import unicodedata
import chardet

# Mapping of German umlauts and sharp s to their replacements
umlaut_map = {
    "ä": "ae",
    "ö": "oe",
    "ü": "ue",
    "Ä": "Ae",
    "Ö": "Oe",
    "Ü": "Ue",
    "ß": "ss",
    "&#228;": "ae",
    "&#246;": "oe",
    "&#252;": "ue",
    "&#196;": "Ae",
    "&#214;": "Oe",
    "&#220;": "Ue",
    "&#223;": "ss",
}


def clean_up_entity_names(directory_path):
    logging.info(f"Reading ADF XML files from directory: {directory_path}")
    adf_entities = {}

    for root, _, files in os.walk(directory_path):
        for file in files:
            if file.endswith(".xml"):
                file_path = os.path.join(root, file)
                logging.debug(f"Processing ADF XML file: {file_path}")
                try:
                    tree = elemTree.parse(file_path)
                    root_element = tree.getroot()
                    if (
                        root_element.tag == "{http://xmlns.oracle.com/bc4j}Entity"
                        or root_element.tag
                        == "{http://xmlns.oracle.com/bc4j}ViewObject"
                    ):
                        entity_name = root_element.get("Name")
                        if "_" in entity_name:
                            adapted_name = __convert_snake_case_to_camel_case(
                                entity_name
                            )
                            adf_entities[entity_name] = adapted_name
                            logging.info(
                                f"Name of Entity or View will be adapted: {entity_name} to {adapted_name}"
                            )
                            # Update the name in the current file
                            __update_file_content(file_path, entity_name, adapted_name)
                            # Update all other files in the directory recursively
                            for dirpath, dirnames, filenames in os.walk(directory_path):
                                for other_file in filenames:
                                    other_file_path = os.path.join(dirpath, other_file)
                                    __update_file_content(
                                        other_file_path, entity_name, adapted_name
                                    )
                except elemTree.ParseError as e:
                    logging.error(f"Error parsing XML file {file_path}: {e}")

    logging.info(f"Total entities collected: {len(adf_entities)}")
    return adf_entities


def clean_up_umlauts_in_directory(directory_path):
    for root, dirs, files in os.walk(directory_path, topdown=True):
        logging.debug(f"Scanning directory: {root}")
        logging.debug(f"Contents before processing: {os.listdir(root)}")

        # Ignore directories starting with a dot
        dirs[:] = [d for d in dirs if not d.startswith(".")]

        # Rename directories first
        for index in range(len(dirs)):
            directory = dirs[index]
            if directory.startswith("."):
                logging.debug(f"Ignoring hidden directory: {directory}")
                continue
            dir_path = os.path.join(root, directory)
            logging.debug(f"Processing directory: {dir_path}")
            logging.debug(f"Before renaming directory: {dir_path}")
            new_dir_path = __rename_umlaut_path(dir_path)
            logging.debug(f"After renaming directory: {new_dir_path}")
            if dir_path != new_dir_path:
                dirs[index] = os.path.basename(new_dir_path)

        # Process all files, handle errors as they occur
        for file in files:
            if (
                file.startswith(".")
                or file.endswith(".gif")
                or file.endswith(".png")
                or file.endswith(".jpg")
                or file.endswith(".jpeg")
                or file.endswith(".JPG")
            ):
                logging.debug(f"Ignoring file: {file}")
                continue
            file_path = os.path.join(root, file)
            logging.debug(f"Processing file: {file_path}")
            logging.debug(f"Before renaming file: {file_path}")
            new_file_path = __rename_umlaut_path(file_path)
            logging.debug(f"After renaming file: {new_file_path}")
            __update_file_content(new_file_path)
        logging.debug(f"Contents after processing: {os.listdir(root)}")
    logging.info("All files and directories have been processed.")


def __replace_umlauts(text):
    normalized_text = unicodedata.normalize("NFD", text)
    for key, value in umlaut_map.items():
        normalized_key = unicodedata.normalize("NFD", key)
        normalized_text = normalized_text.replace(normalized_key, value)
    return unicodedata.normalize("NFC", normalized_text)


def __convert_snake_case_to_camel_case(name: str):
    """Convert snake_case to CamelCase."""
    parts = name.split("_")
    # Capitalize the first letter of each part (except the first part) and leave the rest unchanged
    camel_case = parts[0].capitalize() + "".join(part for part in parts[1:])
    return camel_case


def __rename_umlaut_path(path):
    dir_name, base_name = os.path.split(path)
    new_base_name = __replace_umlauts(base_name)
    new_path = os.path.join(dir_name, new_base_name)
    if new_base_name != base_name:
        os.rename(path, new_path)
        logging.info(f"Renamed: {path} -> {new_path}")
    return new_path


def __detect_encoding(file_path):
    with open(file_path, "rb") as file:
        raw_data = file.read()
    result = chardet.detect(raw_data)
    return result["encoding"]


def __update_file_content(file_path, old_entity_name=None, new_entity_name=None):
    encoding = __detect_encoding(file_path)
    try:
        with open(file_path, "r", encoding=encoding) as file:
            content = file.read()
        new_content = __replace_umlauts(content)
        if old_entity_name and new_entity_name:
            new_content = new_content.replace(old_entity_name, new_entity_name)
        with open(file_path, "w", encoding="utf-8") as file:
            file.write(new_content)
    except UnicodeDecodeError as e:
        logging.warning(
            f"Failed to read file {file_path} due to Unicode decoding error: {e}"
        )
    except PermissionError as e:
        logging.warning(f"Permission denied for file {file_path}: {e}")
