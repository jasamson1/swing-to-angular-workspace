
import os
from pathlib import Path

from dotenv import load_dotenv

from genrevive.helpers.common.shell_utils import (
    get_local_command_path,
    run_build_process,
)


class MavenBuilder:
    """Build a Java/Spring project with Maven, locally (or via mvnw if present)."""

    def __init__(self):
        load_dotenv()
        self.springboot_path = os.getenv("SPRINGBOOT_PROJECT_PATH", os.getenv("TARGET_PROJECT_PATH"))

    def _resolve_maven_executable(self) -> str:
        """
        Prefer mvnw (Maven Wrapper) if present in the project dir.
        Otherwise use 'mvn' found on PATH via get_local_command_path.
        """
        mvnw_unix = Path(self.springboot_path) / "mvnw"
        mvnw_win = Path(self.springboot_path) / "mvnw.cmd"
        if mvnw_unix.exists():
            return str(mvnw_unix)
        if mvnw_win.exists():
            return str(mvnw_win)
        return get_local_command_path("mvn")

    def execute_build(
        self,
        with_tests: bool = True,
        skip_repackage: bool = True,
        goals: list[str] | None = None,
        additional_args: list[str] | None = None,
    ) -> dict:
        """
        Execute a Maven build.

        Args:
            with_tests: run tests if True; otherwise append -DskipTests
            skip_repackage: if True, add -Dspring-boot.repackage.skip=true
            goals: Maven goals; default is ['clean', 'package']
            additional_args: any extra CLI args, e.g. ['-Pdev', '-Dfoo=bar']

        Returns:
            dict from run_build_process() with stdout/stderr/returncode etc.
        """
        mvn_exec = self._resolve_maven_executable()
        if goals is None:
            goals = ["clean", "package"]

        cmd = [mvn_exec, *goals]

        if not with_tests:
            cmd.append("-DskipTests")

        if skip_repackage:
            # Avoid Spring Boot plugin failing with “Unable to find main class”
            cmd.append("-Dspring-boot.repackage.skip=true")

        if additional_args:
            cmd.extend(additional_args)

        return run_build_process(cmd, cwd=self.springboot_path)
