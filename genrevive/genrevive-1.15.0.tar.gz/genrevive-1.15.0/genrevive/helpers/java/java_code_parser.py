import logging
from .tree_sitter_query import TreeSitterQuery


class JavaCodeParser:

    @staticmethod
    def extract_class_name(content):
        tree_sitter_query = TreeSitterQuery(content)
        class_names = tree_sitter_query.query_element_identifier("class")
        if class_names:
            class_name = class_names[0]
            logging.debug(f"Extracted class name: {class_name}")
            return class_name
        else:
            logging.debug("No class name found")
            return None

    @staticmethod
    def extract_interface_name(content):
        tree_sitter_query = TreeSitterQuery(content)
        interface_names = tree_sitter_query.query_element_identifier("interface")
        if interface_names:
            interface_name = interface_names[0]
            logging.debug(f"Extracted interface name: {interface_name}")
            return interface_name
        logging.debug("No interface name found")
        return None

    @staticmethod
    def extract_annotated_classes(content, annotation):
        tree_sitter_query = TreeSitterQuery(content)
        annotated_classes = []
        marker_flag = True
        if annotation == "Table":
            marker_flag = False
        class_names = tree_sitter_query.query_identifier_for_annotation(
            "class", annotation, marker_flag
        )
        if class_names:
            logging.debug(
                f"Extracted annotated classes with @{annotation}: {class_names}"
            )
            annotated_classes.extend(class_names)
        return annotated_classes

    @staticmethod
    def extract_annotated_interfaces(content, annotation):
        tree_sitter_query = TreeSitterQuery(content)
        annotated_classes = []
        interface_names = tree_sitter_query.query_identifier_for_annotation(
            "interface", annotation, True
        )
        if interface_names:
            logging.debug(
                f"Extracted annotated classes with @{annotation}: {interface_names}"
            )
            annotated_classes.extend(interface_names)
        return annotated_classes

    @staticmethod
    def extract_annotated_fields(content, annotation):
        tree_sitter_query = TreeSitterQuery(content)
        annotated_classes = []
        field_names = tree_sitter_query.query_annotated_field(annotation)
        if field_names:
            logging.debug(
                f"Extracted annotated classes with @{annotation}: {field_names}"
            )
            annotated_classes.extend(field_names)
        return annotated_classes

    @staticmethod
    def extract_annotated_constructor_params(content, annotation):
        tree_sitter_query = TreeSitterQuery(content)
        annotated_constructor_params = []
        field_names = tree_sitter_query.query_annotated_constructor_params(annotation)
        if field_names:
            logging.debug(
                f"Extracted annotated classes with @{annotation}: {field_names}"
            )
            annotated_constructor_params.extend(field_names)
        return annotated_constructor_params

    @staticmethod
    def extract_field_type(content, field_name):
        tree_sitter_query = TreeSitterQuery(content)
        field_type = tree_sitter_query.query_field_type(field_name)
        if field_type:
            return field_type[0]
        else:
            logging.debug(f"No field type found for {field_name}")
            return None

    @staticmethod
    def extract_autowired_fields(content):
        autowired_fields = []

        autowired_fields.extend(
            JavaCodeParser.extract_annotated_fields(content, "Autowired")
        )
        autowired_fields.extend(
            JavaCodeParser.extract_annotated_constructor_params(content, "Autowired")
        )

        logging.debug(f"Extracted autowired fields: {autowired_fields}")
        return autowired_fields

    @staticmethod
    def get_table_name(content):
        # Check if the Java code has classes annotated with @Table
        annotated_classes = JavaCodeParser.extract_annotated_classes(content, "Table")

        if not annotated_classes:
            logging.info("No classes annotated with @Table found.")
            return None

        tree_sitter_query = TreeSitterQuery(content)
        tablename = tree_sitter_query.query_table_name()
        logging.debug(f"Extracted table name from @Table annotation: {tablename}")
        if tablename:
            return tablename[0]
        else:
            return None
