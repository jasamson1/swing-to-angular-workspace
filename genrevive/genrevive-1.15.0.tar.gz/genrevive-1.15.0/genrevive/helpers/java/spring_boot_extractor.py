import logging
from tree_sitter import Language, Query, QueryCursor
import tree_sitter_java as tsjava

from genrevive.helpers.common.file_utils import FileUtils
from genrevive.helpers.java.java_code_parser import JavaCodeParser
from genrevive.helpers.java.tree_sitter_query import TreeSitterQuery


class SpringBootExtractor:
    """
    SpringBootExtractor is a utility class designed for extracting and
    analyzing various components from a Spring Boot application's Java
    source code. It uses file system utilities to read Java files, and
    Java code parsing tools to extract and analyze classes and components
    annotated with Spring-specific annotations such as @Entity,
    @Repository, @Service, and @RestController.

    Attributes:
        springboot_directory_path (str): The file system path to the root
            directory of the Spring Boot project containing Java source
            files.

    Limitations:
        This utility class assumes that there are no files with the same
        class name but in different packages. If such a case exists, it
        might not accurately identify the correct file and content for a
        given class name.
    """

    JAVA_LANGUAGE = Language(tsjava.language())

    def __init__(self, springboot_directory_path):
        self.springboot_directory_path = springboot_directory_path
        self.class_content_map = {}

    def get_all_java_files(self):
        logging.info(
            f"Reading Java files from directory: " f"{self.springboot_directory_path}"
        )
        java_files = FileUtils.find_files_in_directory(
            ".java", self.springboot_directory_path
        )
        return java_files

    def get_java_content_and_file_by_class_name(self, class_name):
        if class_name in self.class_content_map:
            return self.class_content_map[class_name]

        for java_file in self.get_all_java_files():
            logging.debug(f"Processing Java file: {java_file}")
            content = FileUtils.read_file(java_file)
            name = JavaCodeParser.extract_class_name(content)
            if name == class_name:
                logging.info(f"File for class {class_name}: {java_file}")
                self.class_content_map[class_name] = (content, java_file)
                return content, java_file
        logging.warning(f"Class {class_name} not found in any Java file.")
        return "", ""

    def load_entities(self):
        entities = {}

        for java_file in self.get_all_java_files():
            logging.debug(f"Processing Java file: {java_file}")
            content = FileUtils.read_file(java_file)
            entity_class_name = JavaCodeParser.extract_annotated_classes(
                content, "Entity"
            )
            if entity_class_name:
                logging.debug(f"Found Entity: {', '.join(entity_class_name)}")
                entities[java_file] = content

        return entities

    def load_repositories(self):
        repositories = {}

        for java_file in self.get_all_java_files():
            logging.debug(f"Processing Java file: {java_file}")
            content = FileUtils.read_file(java_file)
            repository_interface_name = JavaCodeParser.extract_annotated_interfaces(
                content, "Repository"
            )
            if repository_interface_name:
                logging.debug(
                    f"Found Repository: " f"{', '.join(repository_interface_name)}"
                )
                repositories[java_file] = content

        return repositories

    def load_services(self):
        services = {}

        for java_file in self.get_all_java_files():
            logging.debug(f"Processing Java file: {java_file}")
            content = FileUtils.read_file(java_file)
            service_class_name = JavaCodeParser.extract_annotated_classes(
                content, "Service"
            )
            if service_class_name:
                logging.debug(f"Found Service: {', '.join(service_class_name)}")
                services[java_file] = content

        return services

    def load_controllers(self):
        controllers = {}

        for java_file in self.get_all_java_files():
            logging.debug(f"Processing Java file: {java_file}")
            content = FileUtils.read_file(java_file)
            controller_class_name = JavaCodeParser.extract_annotated_classes(
                content, "RestController"
            )
            if controller_class_name:
                logging.debug(f"Found Controller: {', '.join(controller_class_name)}")
                controllers[java_file] = content

        return controllers

    def load_entity_based_on_repository_name(self, repository_name):
        content, repo_file = self.get_java_content_and_file_by_class_name(
            repository_name
        )
        if content:
            try:
                # Use TreeSitter to find the entity name from
                # JpaRepository extension
                entity_name = self.__find_extends_jpa_repository_entity_name(content)
                if entity_name:
                    logging.info(
                        f"Entity based on repository "
                        f"{repository_name}: {entity_name}"
                    )
                    return entity_name

            except Exception as e:
                logging.error(f"Error while parsing {repo_file}: {e}")

        # If no appropriate file is found or no match is made, return ""
        return ""

    def __find_extends_jpa_repository_entity_name(self, content):
        """
        Private method that parses a Java file to find the entity name
        from JpaRepository extension.

        This method uses TreeSitter to parse the provided Java file
        content and search for a class/interface that extends
        JpaRepository, then extracts the entity name from the generic
        type parameter.

        Args:
            content (str): The Java file content to parse

        Returns:
            str: The entity name if found, empty string otherwise
        """
        try:
            # Use TreeSitter directly for complex query
            query_helper = TreeSitterQuery(content)
            tree = query_helper._generate_tree(content)

            # Query for class extending JpaRepository
            query_str = """(class_declaration
              superclass: (superclass
                (generic_type
                  (type_identifier) @super_type
                  (#eq? @super_type "JpaRepository")
                  (type_arguments
                    (type_identifier) @entity_type))))"""

            query = Query(self.JAVA_LANGUAGE, query_str)
            captures = QueryCursor(query).captures(tree.root_node)

            # Return the first entity type (the first type argument of
            # JpaRepository<EntityType, IdType>)
            if "entity_type" in captures and len(captures["entity_type"]) > 0:
                return captures["entity_type"][0].text.decode("utf-8")

            # Also check for interface extending JpaRepository
            interface_query_str = """(interface_declaration
              (extends_interfaces
                (type_list
                  (generic_type
                    (type_identifier) @super_type
                    (#eq? @super_type "JpaRepository")
                    (type_arguments
                      (type_identifier) @entity_type)))))"""

            interface_query = Query(self.JAVA_LANGUAGE, interface_query_str)
            interface_captures = QueryCursor(interface_query).captures(tree.root_node)

            if (
                "entity_type" in interface_captures
                and len(interface_captures["entity_type"]) > 0
            ):
                return interface_captures["entity_type"][0].text.decode("utf-8")

            return ""
        except Exception as e:
            logging.error(f"Error parsing JpaRepository extension: {e}")
            return ""

    def load_autowired_fields_by_class_name(self, class_name):
        """
        This method loads the autowired fields (e.g., services or
        repositories) from the Java class specified by the provided
        class name.

        Args:
            class_name (str): The name of the Java class to search for
                autowired fields.

        Returns:
            List[str]: A list of autowired field names found in the class.
        """
        autowired_fields = []

        # Fetch the Java class content and file based on class name
        content, _ = self.get_java_content_and_file_by_class_name(class_name)

        if content:
            # Extract autowired fields using JavaCodeParser
            autowired_fields.extend(JavaCodeParser.extract_autowired_fields(content))

        # Extract field names (repositories or services)
        field_names = [field_name for field_name, _ in autowired_fields]

        logging.info(f"Autowired fields for class {class_name}: {field_names}")
        return field_names
