from typing import Optional

from crewai.tools import BaseTool
from genrevive.helpers.java.maven_builder import MavenBuilder


class MavenBuildTool(BaseTool):
    name: str = "Maven build tool"
    with_tests: Optional[bool] = None
    description: str = """
        This tool checks if given Java code is functional.
        It takes the file_path and its' content, so the java code, as input.
        If it's functional return True else return the Error message.
    """

    def __init__(self, with_tests: bool, **kwargs):
        """
        Args:
            with_tests (bool): The flag whether tests should be executed or not.
        """
        super().__init__(**kwargs)
        self.with_tests = with_tests

    def _run(self, file_path: str, java_code: str) -> dict[bool, str]:
        maven_builder = MavenBuilder()
        build_result = maven_builder.execute_build(self.with_tests)
        return build_result


def maven_build_tool(with_tests: bool, cache_success_only: bool):
    tool = MavenBuildTool(with_tests)
    if cache_success_only:
        tool.cache_function = cache_success
    return tool


def cache_success(args, result):
    cache = result["success"]
    return cache
