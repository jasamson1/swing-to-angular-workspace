import logging
from tree_sitter import Language, Parser, Query, QueryCursor

import tree_sitter_java as tsjava


class TreeSitterQuery:
    # TreeSitter Language constant initialized once at class level
    JAVA_LANGUAGE = Language(tsjava.language())

    def __init__(self, content: str):
        self.content = content

    # for finding the name of an element such as class, interface, method
    def query_element_identifier(self, element_to_find: str):
        tree = self._generate_tree(self.content)
        QUERY = """
        ({element}_declaration 
            (identifier) @{element})
        """
        try:
            query = Query(self.JAVA_LANGUAGE, QUERY.format(element=element_to_find))
            captures = QueryCursor(query).captures(tree.root_node)
            if element_to_find in captures and len(captures[element_to_find]) > 0:
                names = [node.text.decode("utf8") for node in captures[element_to_find]]
                return names
        except Exception as e:
            logging.error(
                f"Failed to query element identifier for '{element_to_find}': {e}"
            )
            return None

    # for elements such as package_declaration, marker_annotation when you want the whole element
    def query_element(self, element_to_find: str):
        tree = self._generate_tree(self.content)
        QUERY = """
        ({element_type_description})
            @{element}
        """
        element_type_description = self._create_element_type_description(
            element_to_find
        )
        try:
            query = Query(
                self.JAVA_LANGUAGE,
                QUERY.format(
                    element=element_to_find,
                    element_type_description=element_type_description,
                ),
            )
            captures = QueryCursor(query).captures(tree.root_node)
            if element_to_find in captures and len(captures[element_to_find]) > 0:
                names = [node.text.decode("utf8") for node in captures[element_to_find]]
                return names
        except Exception as e:
            logging.error(
                f"Failed to query element '{element_to_find}' with type description '{element_type_description}': {e}"
            )
            return None

    # for finding the name of an annotated element e.g. class, interface etc
    def query_identifier_for_annotation(
        self, element_to_find: str, annotation: str, is_marker_annotation: bool
    ):
        tree = self._generate_tree(self.content)
        if is_marker_annotation:
            marker_annotation = "marker_"
        else:
            marker_annotation = ""
        QUERY = """
        ({element}_declaration
        	(modifiers
            	(({marker}annotation (identifier) @annotation)
                    (#eq? @annotation "{annotation}")))
                        ((identifier) @name))
        """
        try:
            query = Query(
                self.JAVA_LANGUAGE,
                QUERY.format(
                    element=element_to_find,
                    annotation=annotation,
                    marker=marker_annotation,
                ),
            )
            captures = QueryCursor(query).captures(tree.root_node)
            if "name" in captures and len(captures["name"]) > 0:
                names = [node.text.decode("utf8") for node in captures["name"]]
                return names
        except Exception as e:
            logging.error(
                f"Failed to query identifier for annotation '{annotation}' on element '{element_to_find}': {e}"
            )
            return []

    def query_annotated_field(self, annotation):
        tree = self._generate_tree(self.content)
        QUERY = """
        (field_declaration
            (modifiers
        	    ((marker_annotation (identifier) @annotation)
                       (#eq? @annotation "{annotation}")))
                            (type_identifier) @type (variable_declarator) @name)
        """
        try:
            query = Query(self.JAVA_LANGUAGE, QUERY.format(annotation=annotation))
            captures = QueryCursor(query).captures(tree.root_node)
            field_type_name = []
            if "type" in captures and "name" in captures:
                field_types = [node.text.decode("utf8") for node in captures["type"]]
                names = [node.text.decode("utf8") for node in captures["name"]]
                if field_types and names:
                    field_type_name.append((field_types[0], names[0]))
                return field_type_name
        except Exception as e:
            logging.error(
                f"Failed to query annotated field with annotation '{annotation}': {e}"
            )
            return []

    def query_annotated_constructor_params(self, annotation):
        tree = self._generate_tree(self.content)
        QUERY = """
        (constructor_declaration 
	        (modifiers
    	        (marker_annotation name: (identifier) @annotation) 
                    (#eq? @annotation "{annotation}"))
                        (formal_parameters)+ @params)
        """
        try:
            query = Query(self.JAVA_LANGUAGE, QUERY.format(annotation=annotation))
            captures = QueryCursor(query).captures(tree.root_node)
            if "params" in captures and len(captures["params"]) > 0:
                params_decoded = [
                    node.text.decode("utf8") for node in captures["params"]
                ]
                final_param_list = self._convert_params_to_tuple_list(params_decoded)
                return final_param_list
        except Exception as e:
            logging.error(
                f"Failed to query annotated constructor params with annotation '{annotation}': {e}"
            )
            return []

    def query_field_type(self, field_name):
        tree = self._generate_tree(self.content)
        QUERY = """
        (({type}) @type
    	    ((variable_declarator) @name (#eq? @name "{field_name}")))
        """
        try:
            query = Query(
                self.JAVA_LANGUAGE,
                QUERY.format(field_name=field_name, type="type_identifier"),
            )
            captures = QueryCursor(query).captures(tree.root_node)
            if "type" in captures and len(captures["type"]) > 0:
                decoded = [node.text.decode("utf8") for node in captures["type"]]
                logging.debug(f"Extracted field type for {field_name}: {decoded}")
                return decoded
            else:
                query = Query(
                    self.JAVA_LANGUAGE,
                    QUERY.format(field_name=field_name, type="integral_type"),
                )
                captures = QueryCursor(query).captures(tree.root_node)
                if "type" in captures and len(captures["type"]) > 0:
                    decoded = [node.text.decode("utf8") for node in captures["type"]]
                    logging.debug(
                        f"Extracted integral field type for {field_name}: {decoded}"
                    )
                    return decoded
        except Exception as e:
            logging.error(f"Failed to query field type for field '{field_name}': {e}")
            return None

    def query_table_name(self):
        tree = self._generate_tree(self.content)
        QUERY = """
        (annotation 
	        (identifier) @annotation ((#eq? @annotation "Table"))
	            (annotation_argument_list 
    	            (element_value_pair 
        	            (string_literal (string_fragment) @tablename))))
        """
        try:
            query = Query(self.JAVA_LANGUAGE, QUERY)
            captures = QueryCursor(query).captures(tree.root_node)
            if "tablename" in captures and len(captures["tablename"]) > 0:
                decoded = [node.text.decode("utf8") for node in captures["tablename"]]
                return decoded
        except Exception as e:
            logging.error(f"Failed to query table name from @Table annotation: {e}")
            return None

    def _convert_params_to_tuple_list(self, params_decoded):
        params = params_decoded[0].strip("()")
        params_list = params.split(",")
        logging.debug(f"Extracted constructor parameters: {params_list}")
        final_param_list = []
        for param in params_list:
            logging.debug(f"Processing constructor parameter: {param}")
            param_stripped = param.strip()
            param_as_list = param_stripped.split(" ")
            param_tuple = tuple(param_as_list)
            final_param_list.append(param_tuple)
        return final_param_list

    def _generate_tree(self, content: str):
        parser = Parser(self.JAVA_LANGUAGE)
        tree = parser.parse(content.encode("utf8"))
        return tree

    def _unpack_decode_capture(self, capture, key_to_decode):
        node = capture[key_to_decode]
        node_decoded = []
        for node in node:
            node_decoded.append(node.text.decode("utf8"))
        return node_decoded

    def _create_element_type_description(self, element_to_find):
        element_type_description = ""
        try:
            if element_to_find in ["package", "import", "class", "interface"]:
                element_type_description = element_to_find + "_declaration"
            if element_to_find in ["annotation"]:
                element_type_description = "marker_" + element_to_find
            return element_type_description
        except Exception as e:
            logging.error(
                f"Failed to create element type description for '{element_to_find}': {e}"
            )
            logging.debug(f'"{element_to_find}" not a recognised element to search for')
            return None
