import logging
import os
import xml.etree.ElementTree as elemTree

import yaml
from lxml import etree

from genrevive.helpers.common.file_utils import FileUtils
from genrevive.helpers.common.shell_utils import run_command, get_local_command_path


class SpringBootProjectCreator:
    """
    Class to create a Spring Boot application using Spring Boot CLI locally.

    Requirements:
    - Spring Boot CLI must be installed on the system for this class to function properly.

    Installation:
    - To install Spring Boot CLI, follow these steps:
      1. Visit the official Spring Boot documentation for CLI installation instructions:
         https://docs.spring.io/spring-boot/docs/current/reference/html/getting-started.html#getting-started.installing.cli
      2. Follow the guide for your operating system.
      3. Verify the installation by running `spring --version` in your terminal.
    """

    def create_spring_boot_project(
        self,
        project_directory: str,
        project_name: str,
        build_system: str,
        dependencies: list[str],
        group: str,
        java_version: str,
        language: str,
        package_name: str,
        packaging: str,
        project_type: str,
    ):
        """
        Creates a Spring Boot project based on the provided parameters. Adds an application.yaml instead of an application.properties file.

        Args:
            project_directory (str): The directory where the project should be created.
                Example: "/home/user/projects/"
            project_name (str): The name of the project to be created.
                Example: "my-spring-app"
            build_system (str): The build system to use for the project.
                Valid values: "maven", "gradle"
                Example: "maven"
            dependencies (list[str]): A list of dependencies to include in the project.
                Each dependency is a string representing the dependency's ID.
                Example: ["web", "data-jpa"]
            group (str): The group ID for the project. In Maven or Gradle, the group ID defines the root package structure.
                Example: "com.example"
            java_version (str): The Java version to use for the project.
                Valid values: "17", "21" etc.
                Example: "17"
            language (str): The programming language for the project.
                Valid values: "java", "kotlin", "groovy"
                Example: "java"
            package_name (str): The root package name for the project (this is usually the combination of group ID and project name).
                Example: "com.example.myspringapp"
            packaging (str): The packaging format for the project.
                Valid values: "jar", "war"
                Example: "jar"
            project_type (str): The type of Spring Boot project to generate.
                Valid values: "gradle-build", "gradle-project", "gradle-project-kotlin", "maven-build", "maven-project"
                Example: "maven-project"
        """
        # Full path where the project will be created
        full_path = os.path.join(project_directory, project_name)

        # Check if the directory exists and is not empty
        if os.path.exists(full_path) and os.listdir(full_path):
            logging.error(f"Directory not empty, cannot create project: {full_path}")
            return

        # Store the original path before changing directory
        original_path = os.getcwd()
        os.chdir(project_directory)  # Change to the desired directory
        logging.info(f"Attempting to create Spring Boot project at: {full_path}")

        spring_path = get_local_command_path("spring")
        logging.info(f"Using spring at: {spring_path}")

        # Define the command to create a Spring Boot project (arguments are ordered alphabetically)
        command = [
            spring_path,
            "init",
            "-a",
            project_name,
            "--build",
            build_system,
            "-d",
            ",".join(dependencies),
            "--extract",
            "-g",
            group,
            "-j",
            java_version,
            "-l",
            language,
            "-n",
            project_name,
            "--package-name",
            package_name,
            "-p",
            packaging,
            "-t",
            project_type,
            full_path,
        ]

        # Run the command
        run_command(command)
        self.__replace_properties_with_yaml(full_path, project_name)
        os.chdir(original_path)

    def add_maven_dependency(
        self, springboot_project_path, group_id, artifact_id, version, scope=None
    ):
        # Parse the existing pom.xml file
        pom_file = os.path.join(springboot_project_path, "pom.xml")
        if self.__dependency_exists(group_id, artifact_id, version, pom_file):
            logging.warning(
                f"Dependency {group_id}:{artifact_id}:{version} already exists in {pom_file}."
            )
            return

        tree, root = self.__parse_xml_file(pom_file)

        # Define the Maven XML namespaces
        ns = self.__register_mvn_namespace()

        # Locate the <dependencies> section
        dependencies = root.find("mvn:dependencies", ns)
        if dependencies is None:
            dependencies = elemTree.SubElement(root, "dependencies")

        # Create the new dependency element
        dependency = elemTree.Element("dependency")
        self.__add_sub_element(dependency, "groupId", group_id)
        self.__add_sub_element(dependency, "artifactId", artifact_id)
        self.__add_sub_element(dependency, "version", version)
        if scope is not None:
            self.__add_sub_element(dependency, "scope", scope)

        # Append the new dependency to the <dependencies> section
        dependencies.append(dependency)

        # Write the updated XML back to the file
        tree.write(pom_file, encoding="utf-8", xml_declaration=True)

        # Ensure the XML output is formatted in a human-readable way (proper indentation, line breaks).
        # The default write method does not preserve formatting, so _pretty_print_xml helps with that.
        self.__pretty_print_xml(pom_file)

        logging.info(
            f"Dependency {group_id}:{artifact_id}:{version} added to {pom_file}."
        )

    def add_liquibase(self, springboot_directory_path, yaml_file):
        """
        Adds Liquibase configuration to a Spring Boot project.

        This method creates the required Liquibase changelog structure in the project
        and adds the Liquibase configuration to the specified yaml file.

        Use this when setting up Liquibase in a Spring Boot project to manage and apply database changes.

        Note: It creates two changelogs - one for the schema SQL and another for inserting test data.
        """

        self.__create_changelog_structure(springboot_directory_path)
        liquibase_config = {
            "spring": {
                "liquibase": {
                    "enabled": True,
                    "change-log": "classpath:/db/changelog/db.changelog-master.yaml",
                }
            }
        }
        self.add_config_to_yaml(liquibase_config, yaml_file)

    def add_config_to_yaml(self, new_config: dict, yaml_file_path):
        """
        Merges the given configurations with the existing YAML document.
        If the file doesn't exist, a new one will be created with the provided configuration.
        """
        existing_config = {}

        # Attempt to load the existing YAML configuration file
        try:
            with open(yaml_file_path, "r") as file:
                # Load the current configuration from the YAML file
                existing_config = yaml.safe_load(file) or {}
        except FileNotFoundError:
            logging.error(
                f"File {yaml_file_path} not found. A new file will be created."
            )
        except yaml.YAMLError as error:
            logging.error(f"Failed to load YAML file: {error}")
            return

        # Merge the new configuration with the existing configuration
        merged_config = self.__deep_merge_dicts(new_config, existing_config)

        # Write the merged configuration back to the YAML file
        try:
            with open(yaml_file_path, "w") as file:
                yaml.dump(merged_config, file, default_flow_style=False)
            logging.info(
                f"Configuration successfully merged and written to {yaml_file_path}"
            )
        except Exception as error:
            logging.error(f"Error writing to YAML file: {error}")

    @staticmethod
    def __create_changelog_structure(springboot_directory_path):
        """Creates the changelog folder structure and files."""
        db_path = os.path.join(
            springboot_directory_path, "src", "main", "resources", "db"
        )

        changelog_folder = os.path.join(db_path, "changelog")
        version_folder = os.path.join(changelog_folder, "1.0.0")

        # YAML content for db.changelog-master.yaml
        changelog_master_content = {
            "databaseChangeLog": [
                {
                    "changeSet": {
                        "id": "include-sql-ddl-01",
                        "comment": "Including an SQL file for execution",
                        "author": "GenRevive",
                        "changes": [
                            {
                                "sqlFile": {
                                    "path": "db/changelog/1.0.0/changelog-1.sql",
                                    "splitStatements": True,
                                    "stripComments": True,
                                }
                            }
                        ],
                    }
                },
                {
                    "changeSet": {
                        "id": "include-sql-dml-01",
                        "comment": "Including an SQL file for execution only in test",
                        "context": "test",
                        "author": "GenRevive",
                        "changes": [
                            {
                                "sqlFile": {
                                    "path": "db/changelog/1.0.0/changelog-2.sql",
                                    "splitStatements": True,
                                    "stripComments": True,
                                }
                            }
                        ],
                    }
                },
            ]
        }
        # Create files with their respective content
        SpringBootProjectCreator().add_config_to_yaml(
            changelog_master_content,
            os.path.join(changelog_folder, "db.changelog-master.yaml"),
        )
        FileUtils.write_file(
            os.path.join(version_folder, "changelog-1.sql"), " "
        )  # Empty file
        FileUtils.write_file(
            os.path.join(version_folder, "changelog-2.sql"), " "
        )  # Empty file

        logging.info(
            "Changelog structure created successfully with the specified content!"
        )

    @staticmethod
    def __add_sub_element(parent, tag, text):
        """Helper function to add a sub-element with text."""
        element = elemTree.SubElement(parent, tag)
        element.text = text

    @staticmethod
    def __get_text(element, tag, namespaces):
        """Helper function to get text from a specific tag."""
        sub_element = element.find(tag, namespaces)
        return sub_element.text if sub_element is not None else ""

    @staticmethod
    def __dependency_exists(group_id, artifact_id, version, pom_file="pom.xml") -> bool:
        # Parse the existing pom.xml file
        _, root = SpringBootProjectCreator.__parse_xml_file(pom_file)

        # Define the Maven XML namespaces
        ns = SpringBootProjectCreator.__register_mvn_namespace()

        # Locate the <dependencies> section
        dependencies = root.find("mvn:dependencies", ns)
        if dependencies is None:
            return False  # No dependencies section found

        # Check if the dependency already exists
        for dep in dependencies.findall("mvn:dependency", ns):
            if (
                SpringBootProjectCreator.__get_text(dep, "mvn:groupId", ns) == group_id
                and SpringBootProjectCreator.__get_text(dep, "mvn:artifactId", ns)
                == artifact_id
                and SpringBootProjectCreator.__get_text(dep, "mvn:version", ns)
                == version
            ):
                return True  # Dependency already exists

        return False

    @staticmethod
    def __pretty_print_xml(xml_file):
        # Parse the XML file while preserving whitespace
        parser = etree.XMLParser(remove_blank_text=False)
        _, root = SpringBootProjectCreator.__parse_xml_file(xml_file, parser)

        # Function to format XML with pretty print
        def format_xml(element, level=0):
            indent = "    "
            if len(element):
                if not element.text or not element.text.strip():
                    element.text = "\n" + (level + 1) * indent
                last_sub_element = elemTree.Element("")
                for sub_element in element:
                    last_sub_element = sub_element
                    if not sub_element.tail or not sub_element.tail.strip():
                        sub_element.tail = "\n" + (level + 1) * indent
                    format_xml(sub_element, level + 1)
                if not last_sub_element.tail or not last_sub_element.tail.strip():
                    last_sub_element.tail = "\n" + level * indent

        # Format the XML tree
        format_xml(root)

        # Serialize the XML with proper encoding
        pretty_xml = etree.tostring(
            root, encoding="utf-8", xml_declaration=True, method="xml"
        )

        # Write the pretty XML to the output file
        with open(xml_file, "wb") as file:
            file.write(pretty_xml)

    def __deep_merge_dicts(self, source, destination):
        """
        Recursively merges source dictionary into destination dictionary.

        :param source: The dictionary with new data to merge.
        :param destination: The original dictionary where data will be merged.
        :return: The merged dictionary.
        """
        for key, value in source.items():
            if (
                isinstance(value, dict)
                and key in destination
                and isinstance(destination[key], dict)
            ):
                destination[key] = self.__deep_merge_dicts(value, destination[key])
            elif (
                isinstance(value, list)
                and key in destination
                and isinstance(destination[key], list)
            ):
                destination[key].extend(value)
            else:
                destination[key] = value
        return destination

    @staticmethod
    def __parse_xml_file(xml_file, parser=None):
        if parser is None:
            tree = elemTree.parse(xml_file)
        else:
            tree = elemTree.parse(xml_file, parser)
        root = tree.getroot()
        return tree, root

    @staticmethod
    def __register_mvn_namespace():
        ns = {"mvn": "http://maven.apache.org/POM/4.0.0"}
        elemTree.register_namespace("", ns["mvn"])
        return ns

    def __replace_properties_with_yaml(
        self, springboot_directory_path, springboot_project_name
    ):
        properties_file = os.path.join(
            springboot_directory_path,
            "src",
            "main",
            "resources",
            "application.properties",
        )
        yaml_file = os.path.join(
            springboot_directory_path, "src", "main", "resources", "application.yaml"
        )
        os.remove(properties_file)
        properties_config = {
            "spring": {"application": {"name": springboot_project_name}}
        }
        self.add_config_to_yaml(properties_config, yaml_file)
