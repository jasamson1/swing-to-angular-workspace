import logging

import sqlparse
from sqlparse.sql import IdentifierList, Identifier


class SQLParser:
    @staticmethod
    def extract_table_names(sql_content):
        table_names = []
        parsed = sqlparse.parse(sql_content)
        logging.debug("Extracting table names from CREATE statements")
        for statement in parsed:
            if statement.get_type() == "CREATE" and "TABLE" in str(statement).upper():
                logging.debug(f"Processing statement: {statement}")
                for token in statement.tokens:
                    if isinstance(token, Identifier):
                        table_name = token.get_real_name()
                        table_names.append(table_name)
                        logging.debug(f"Extracted table name: {table_name}")
                        break
                    elif isinstance(token, IdentifierList):
                        for identifier in token.get_identifiers():
                            table_name = identifier.get_real_name()
                            table_names.append(table_name)
                            logging.debug(f"Extracted table name: {table_name}")
                            break
        logging.info(f"Extracted tables names: {table_names}")
        return table_names

    @staticmethod
    def get_table_statements_by_name(sql_content, table_name):
        parsed = sqlparse.parse(sql_content)
        table_statements = []

        for statement in parsed:
            if statement.get_type() in ("CREATE", "ALTER"):
                # Convert statement to string for easier searching
                statement_str = str(statement).upper()
                if f"CREATE TABLE {table_name.upper()}" in statement_str:
                    table_statements.append(statement_str.strip())
                elif f"ALTER TABLE {table_name.upper()}" in statement_str:
                    table_statements.append(statement_str.strip())

        return table_statements

    @staticmethod
    def extract_create_sequence_statements(sql_content):
        parsed = sqlparse.parse(sql_content)
        sequence_statements = []

        for statement in parsed:
            # Convert statement to string for easier searching
            statement_str = str(statement).upper()
            if statement.get_type() == "CREATE" and "SEQUENCE" in statement_str:
                sequence_statements.append(statement_str.strip())

        return sequence_statements
