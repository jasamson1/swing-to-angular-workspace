from tree_sitter import Node  # using this for AST:
from genrevive.helpers.intelligent_chunking.prompt_context_calculator import (
    PromptContextCalculator,
)

from tree_sitter_language_pack import get_parser


def get_code(node: Node, source_bytes: bytes) -> str:
    """
    Extracting a source code represented out of AST

    Args:
        node (Node): Tree-sitter AST node (e.g., class_declaration, method_declaration).
        source_bytes (bytes): Full source code as UTF-8 encoded bytes

    Retuns:
        str: code corresponding to the given node in a string format
    """
    return source_bytes[node.start_byte : node.end_byte].decode("utf-8")


class JavaChunker:
    """
    JavaChunker is implementation of BaseChunker that uses AST-based chunking with tree sitter
    """

    def __init__(self):  # available_tokens_se
        """
        Args:
            max_chunk_size: Max characters per chunk.
        """

        # """
        self.prompt_context_calculator = PromptContextCalculator()
        self.parser = get_parser("java")
        self.encoding = lambda text: len(text)

    def _consolidate_small_chunks(
        self, chunks: list[str], max_size: int
    ) -> list[str]:
        """
        Merge chunks if the total tokens fit into max_size; otherwise, greedily
        pack chunks without exceeding max_size per output chunk.
        Returns:
            list[str]: consolidated chunks
        """
        meaningful = [ch for ch in chunks if ch and ch.strip()]

        total = sum(self.encoding(ch) for ch in meaningful)
        if total <= max_size:
            return ["\n".join(meaningful)]

        new_chunks: list[str] = []
        current_group: list[str] = []
        current_size = 0

        for ch in meaningful:
            ch_tokens = self.encoding(ch)

            if ch_tokens > max_size:

                if current_group:
                    new_chunks.append("\n".join(current_group))
                    current_group = []
                    current_size = 0
                new_chunks.append(ch)
                continue

            if current_size + ch_tokens <= max_size or not current_group:
                current_group.append(ch)
                current_size += ch_tokens
            else:
                new_chunks.append("\n".join(current_group))
                current_group = [ch]
                current_size = ch_tokens

        if current_group:
            new_chunks.append("\n".join(current_group))

        return new_chunks

    def _chunk_node(
        self, node: Node, source_bytes: bytes, max_size: int
    ) -> list[str]:
        """
            Here we use Depth First Search logic
            IMPORTANT: we do not cut between the node!
        Args:
            node (Node): Tree-sitter AST node
            source_bytes (bytes): Full source code as UTF-8 encoded bytes
            max_size (int): max token count of a given chunk
        Returns:
            list(str): list containing str chunks
        """
        chunks = []
        current_chunk_nodes = []
        current_size = 0  # size in tokens

        for child in node.children:
            child_text = get_code(child, source_bytes)
            child_size = self.encoding(child_text)

            if current_size + child_size > max_size and current_chunk_nodes:

                combined_text = "".join(
                    get_code(child_node, source_bytes)
                    for child_node in current_chunk_nodes
                )

                if self.encoding(combined_text) > max_size:

                    for child_node in current_chunk_nodes:
                        chunks.extend(
                            self._chunk_node(
                                child_node, source_bytes, max_size
                            )
                        )
                else:
                    chunks.append(combined_text)

                current_chunk_nodes = []
                current_size = 0

            current_chunk_nodes.append(child)
            current_size += child_size

        if current_chunk_nodes:

            combined_text = "".join(
                get_code(child_node, source_bytes)
                for child_node in current_chunk_nodes
            )

            if self.encoding(combined_text) > max_size:
                for child_node in current_chunk_nodes:
                    chunks.extend(
                        self._chunk_node(child_node, source_bytes, max_size)
                    )

            else:
                chunks.append(combined_text)

        return chunks

    def chunk(self, java_input: str, role: str = "se") -> list[str]:
        """
        Chunk a full Java source file into smaller AST-based segments.

            Args
            java_input : str
                The **entire contents of a Java file** as a single string.
            role : str
                Controls chunking constraints ('se', 'sr').

            Returns
            list[str]
                List of chunked source segments extracted from the full file.
        """
        role = role.lower()
        max_chunk_size = self.prompt_context_calculator.get_available_tokens(
            role
        )
        source_bytes = java_input.encode("utf-8")
        tree = self.parser.parse(source_bytes)
        root_node = tree.root_node

        chunks = self._chunk_node(root_node, source_bytes, max_chunk_size)
        chunks = self._consolidate_small_chunks(chunks, max_chunk_size)
        return chunks
