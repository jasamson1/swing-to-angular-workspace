from pydantic import BaseModel, Field, field_validator


class ChunkOutput(BaseModel):
    code: str = Field(..., min_length=1, description="Generated code chunk")
    chunk_idx: int = Field(
        ..., ge=0, description="Chunk index, must be non-negative"
    )
    origin_chunk_id: str = Field(
        ..., min_length=1, description="Origin chunk identifier"
    )
    filename: str = Field(..., min_length=1, description="Target filename")
    source_file_path: str = Field(
        ..., min_length=1, description="Source file path"
    )

    @field_validator("filename", "source_file_path")
    @classmethod
    def validate_not_only_whitespace(cls, v: str) -> str:
        if not v.strip():
            raise ValueError(
                "Field cannot be empty or contain only whitespace"
            )
        return v
