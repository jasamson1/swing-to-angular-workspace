"""
Tree-sitter query service for extracting Java code structure.
Provides outline of classes, fields, methods, and inner classes.
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional
from tree_sitter import Query, QueryCursor
from tree_sitter_language_pack import get_language, get_parser

logger = logging.getLogger(__name__)


class TreeSitterQueryService:
    """Service for querying Java code structure using tree-sitter."""
    
    CLASS_QUERY = """
        (class_declaration
            name: (identifier) @class_name
            body: (class_body) @class_body
        ) @class
    """
    
    METHOD_QUERY = """
        (method_declaration
            name: (identifier) @method_name
        ) @method
    """
    
    def __init__(self):
        """Initialize tree-sitter parser for Java."""
        try:
            self.language_name = 'java'
            self.language = get_language('java')
            self.parser = get_parser('java')
            # Compile queries once for reuse
            self.class_query = Query(self.language, 
                "(class_declaration name: (identifier) @class_name body: (class_body) @class_body) @class")
            self.method_query = Query(self.language, 
                "(method_declaration name: (identifier) @method_name) @method")
            self.field_query = Query(self.language, 
                "(field_declaration declarator: (variable_declarator name: (identifier) @field_name)) @field")
        except Exception as e:
            logger.error(f"Failed to initialize tree-sitter parser for Java: {e}")
            raise RuntimeError(f"Tree-sitter initialization failed: {e}")

    def get_method_content(self, file_path: str, method_name: str) -> Optional[str]:
        """Extract method content by name with line number information."""
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            source_code = f.read()
        
        tree = self.parser.parse(bytes(source_code, 'utf8'))
        query = Query(self.language, self.METHOD_QUERY)
        cursor = QueryCursor(query)
        matches = cursor.matches(tree.root_node)
        
        for pattern_idx, captures in matches:
            if 'method' in captures:
                for node in captures['method']:
                    func_name_node = node.child_by_field_name('name')
                    func_name = source_code[func_name_node.start_byte:func_name_node.end_byte]
                    
                    if func_name == method_name:
                        start_node = node
                        # Include annotations and modifiers
                        current = node.prev_sibling
                        while current and current.type in ('modifiers', 'marker_annotation', 'annotation'):
                            start_node = current
                            current = current.prev_sibling
                        
                        line_start = start_node.start_point[0] + 1
                        line_end = node.end_point[0] + 1
                        method_text = source_code[start_node.start_byte:node.end_byte]
                        
                        return f"# Number of lines: {line_start} - {line_end}\n{method_text}"

        # If method not found, try to find a class with this name
        class_result = self._get_class_skeleton(method_name, source_code, tree.root_node)
        if class_result:
            return class_result
        
        return None
    
    def get_outline(self, file_path: str) -> str:
        """Get outline of Java file in agent-readable text format."""
        outline = self._get_outline_json(file_path)
        
        lines = ["=== JAVA FILE OUTLINE ===\n"]
        for cls in outline['classes']:
            lines.extend(self._format_class(cls))
        
        return "\n".join(lines)

    def _get_outline_json(self, file_path: str) -> Dict[str, List[Dict[str, any]]]:
        """
        Internal method: Get outline of Java file as JSON structure.
        Used internally by get_outline() to build the text summary.
        
        Args:
            file_path: Path to Java source file
            
        Returns:
            Dictionary with structure:
            {
                "classes": [
                    {
                        "name": str,
                        "line_start": int,
                        "line_end": int,
                        "fields": [{"name": str, "line_start": int, "line_end": int}, ...],
                        "methods": [{"name": str, "line_start": int, "line_end": int}, ...],
                        "inner_classes": [{"name": str, "line_start": int, "line_end": int, ...}, ...]
                    },
                    ...
                ]
            }
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            source_code = f.read()
        
        tree = self.parser.parse(bytes(source_code, 'utf8'))
        root_node = tree.root_node
        
        # Extract top-level classes in one pass
        cursor = QueryCursor(self.class_query)
        return {
            "classes": [
                self._extract_class_info(node, source_code)
                for _, captures in cursor.matches(root_node)
                for node in captures.get('class', [])
                if self._is_top_level_class(node)
            ]
        }
    

    def _format_class(self, cls: Dict) -> List[str]:
        """Format a single class for outline display."""
        lines = [f"CLASS: {cls['name']} (lines {cls['line_start']}-{cls['line_end']})"]
        
        if cls['fields']:
            lines.append(f"  FIELDS ({len(cls['fields'])}):")
            lines.extend(f"    - {f['name']} (line {f['line_start']})" for f in cls['fields'])
        
        if cls['methods']:
            lines.append(f"  METHODS ({len(cls['methods'])}):")
            lines.extend(f"    - {m['name']}() (lines {m['line_start']}-{m['line_end']})" for m in cls['methods'])
        
        if cls['inner_classes']:
            lines.append(f"  INNER CLASSES ({len(cls['inner_classes'])}):")
            for inner in cls['inner_classes']:
                lines.append(f"    - {inner['name']} (lines {inner['line_start']}-{inner['line_end']})")
                if inner['methods']:
                    lines.append(f"      Methods: {', '.join(m['name'] + '()' for m in inner['methods'])}")
                if inner['fields']:
                    lines.append(f"      Fields: {', '.join(f['name'] for f in inner['fields'])}")
        
        lines.append("")
        return lines
    
    def _get_methods_in_class(self, class_node, source_code: str) -> List[Dict[str, any]]:
        """Extract all methods from a Java class node."""
        cursor = QueryCursor(self.method_query)
        seen = set()
        methods = []
        
        for _, captures in cursor.matches(class_node):
            for node in captures.get('method', []):
                name_node = node.child_by_field_name('name')
                name = source_code[name_node.start_byte:name_node.end_byte]
                
                if name not in seen:
                    seen.add(name)
                    methods.append({
                        "name": name,
                        "line_start": node.start_point[0] + 1,
                        "line_end": node.end_point[0] + 1
                    })
        
        return methods
    
    def _get_fields_in_class(self, class_node, source_code: str) -> List[Dict[str, any]]:
        """Extract all fields from a Java class node (excludes fields in inner classes)."""
        cursor = QueryCursor(self.field_query)
        seen = set()
        fields = []
        
        for _, captures in cursor.matches(class_node):
            for node in captures.get('field', []):
                if self._is_in_inner_class(node, class_node):
                    continue
                
                for declarator in (c for c in node.children if c.type == 'variable_declarator'):
                    if (name_node := declarator.child_by_field_name('name')):
                        name = source_code[name_node.start_byte:name_node.end_byte]
                        if name not in seen:
                            seen.add(name)
                            fields.append({
                                "name": name,
                                "line_start": node.start_point[0] + 1,
                                "line_end": node.end_point[0] + 1
                            })
        
        return fields
    
    def _get_inner_classes(self, class_node, source_code: str) -> List[Dict[str, any]]:
        """Extract all inner/nested classes from a Java class node."""
        cursor = QueryCursor(self.class_query)
        inner_classes = []
        
        for _, captures in cursor.matches(class_node):
            for node in captures.get('class', []):
                if node != class_node and self._is_direct_inner_class(node, class_node):
                    inner_classes.append(self._extract_class_info(node, source_code))
        
        return inner_classes
    
    def _extract_class_info(self, class_node, source_code: str) -> Dict[str, any]:
        """Extract complete information about a class including fields, methods, and inner classes."""
        class_name_node = class_node.child_by_field_name('name')
        class_name = source_code[class_name_node.start_byte:class_name_node.end_byte]
        
        return {
            "name": class_name,
            "line_start": class_node.start_point[0] + 1,
            "line_end": class_node.end_point[0] + 1,
            "fields": self._get_fields_in_class(class_node, source_code),
            "methods": self._get_methods_in_class(class_node, source_code),
            "inner_classes": self._get_inner_classes(class_node, source_code)
        }
    
    def _is_top_level_class(self, class_node) -> bool:
        """Check if a class is top-level (not nested inside another class)."""
        current = class_node.parent
        while current:
            if current.type == 'class_declaration':
                return False
            current = current.parent
        return True
    
    def _is_in_inner_class(self, node, parent_class_node) -> bool:
        """Check if a node is inside an inner class (not directly in parent_class_node)."""
        current = node.parent
        while current and current != parent_class_node:
            if current.type == 'class_declaration':
                return True
            current = current.parent
        return False
    
    def _is_direct_inner_class(self, inner_node, parent_class_node) -> bool:
        """Check if inner_node is a direct child class of parent_class_node."""
        current = inner_node.parent
        while current:
            if current == parent_class_node:
                return True
            if current.type == 'class_declaration':
                return False
            current = current.parent
        return False

    def _get_class_skeleton(self, class_name: str, source_code: str, root_node, patterns: dict) -> str:
        """
        Extract class skeleton without method bodies.
        Returns imports, class declaration, docstring, and fields, but excludes method bodies.
        """
        # Query for the class
        class_query = Query(self.language, patterns['class'])
    def _get_class_skeleton(self, class_name: str, source_code: str, root_node) -> Optional[str]:
        """Extract class skeleton without method bodies."""
        class_query = Query(self.language, self.CLASS_QUERY)
        cursor = QueryCursor(class_query)
        matches = cursor.matches(root_node)
        
        for pattern_idx, captures in matches:
            if 'class' in captures:
                for class_node in captures['class']:
                    class_name_node = class_node.child_by_field_name('name')
                    found_class_name = source_code[class_name_node.start_byte:class_name_node.end_byte]
                    
                    if found_class_name == class_name:
                        skeleton_parts = []
                        
                        # Extract imports (everything before the class)
                        pre_class_content = source_code[0:class_node.start_byte].rstrip()
                        if pre_class_content:
                            skeleton_parts.append(pre_class_content)
                        
                        line_start = class_node.start_point[0] + 1
                        
                        # Extract class declaration
                        class_header_end = self._find_class_header_end(class_node, source_code)
                        skeleton_parts.append(source_code[class_node.start_byte:class_header_end])
                        
                        # Extract fields, skip methods
                        last_byte = class_header_end
                        for child in class_node.children:
                            if child.type == 'method_declaration':
                                method_name_node = child.child_by_field_name('name')
                                if method_name_node:
                                    method_name_text = source_code[method_name_node.start_byte:method_name_node.end_byte]
                                    indent = self._get_indent(child, source_code)
                                    skeleton_parts.append(f"{indent}// ... method {method_name_text}() ...\n")
                                continue
                            
                            if child.start_byte >= last_byte:
                                node_text = source_code[child.start_byte:child.end_byte]
                                if node_text.strip():
                                    skeleton_parts.append(node_text)
                                last_byte = child.end_byte
                        
                        line_end = class_node.end_point[0] + 1
                        skeleton = "\n".join(skeleton_parts)
                        
                        return f"# Number of lines: {line_start} - {line_end}\n{skeleton}"
        
        return None
    
    def _find_class_header_end(self, class_node, source_code: str) -> int:
        """Find the byte position where class header ends."""
        for child in class_node.children:
            if child.type == 'class_body':
                body_start = child.start_byte
                while body_start < child.end_byte and source_code[body_start] != '{':
                    body_start += 1
                body_start += 1
                while body_start < len(source_code) and source_code[body_start] in '\n\r ':
                    body_start += 1
                return body_start
        
        return class_node.start_byte
    
    def _get_indent(self, node, source_code: str) -> str:
        """Get the indentation of a node."""
        line_start_byte = node.start_byte
        while line_start_byte > 0 and source_code[line_start_byte - 1] not in '\n\r':
            line_start_byte -= 1
        
        indent = ""
        pos = line_start_byte
        while pos < node.start_byte and source_code[pos] in ' \t':
            indent += source_code[pos]
            pos += 1
        
        return indent
