import os
from pathlib import Path
import logging
from tokencost import count_string_tokens


class PromptContextCalculator:
    DEFAULT_PROMPT_CONTEXT_SIZE = 600
    OTHER_INSTRUCTIONS_SIZE = 300

    def __init__(self):
        self.prompt_context_size = int(
            os.getenv("PROMPT_CONTEXT_SIZE", self.DEFAULT_PROMPT_CONTEXT_SIZE)
        )
        self.input_token_limit = int(os.getenv("INPUT_TOKEN_LIMIT", 15000))

        self.se_prompt_path = os.getenv("SE_PROMPT_FILE")
        self.se_cookbook_path = os.getenv("SE_COOKBOOK_FILE")

        self.re_prompt_path = os.getenv("SR_PROMPT_FILE")
        self.re_cookbook_path = os.getenv("SR_COOKBOOK_FILE")

        self.FREE_TOKENS_BUFFER = 0.2 * self.input_token_limit

    def get_available_tokens(self, engineer_type: str = "se") -> int:
        consumed_tokens = self._calculate_consumed_tokens(engineer_type)
        available_tokens = (
            self.input_token_limit - consumed_tokens - self.FREE_TOKENS_BUFFER
        )
        if available_tokens < 1000:
            logging.warning(
                f"Available tokens for output is low: {available_tokens}. Consider model with higher LLM_CONTEXT_LENGTH or reducing prompt."
            )
        return int(max(0, available_tokens))

    def _calculate_consumed_tokens(self, engineer_type: str) -> int:
        content = self._get_prompt_and_cookbook_content(engineer_type)
        additional_content = self._generate_text_with_word_count()
        content += additional_content
        content += self._get_agent_factory_content()
        model = self._extract_model_name()
        try:
            prompt_tokens = count_string_tokens(content, model)
        except Exception as e:
            logging.error(
                f"Error counting tokens for model {model}: {e}. Falling back to 'gpt-4' model."
            )
            prompt_tokens = count_string_tokens(content, "gpt-4")
        return prompt_tokens

    def _get_prompt_and_cookbook_content(self, engineer_type: str) -> str:
        if engineer_type.lower() == "se":
            paths = [self.se_prompt_path, self.se_cookbook_path]
        elif engineer_type.lower() == "re":
            paths = [self.re_prompt_path, self.re_cookbook_path]
        else:
            raise ValueError(
                f"Unknown engineer_type: {engineer_type}. Use 'se' or 'sr'."
            )

        content = ""
        for path in paths:
            if path:
                content += self._get_content(path)
        return content

    def _extract_model_name(self) -> str:
        model = os.getenv("AGENT_MODEL", "gpt-4")
        if "/" in model:
            model = model.split("/")[1]
        return model

    def _get_agent_factory_content(self) -> str:
        try:
            import inspect
            from genrevive.core.agent_factory import AgentFactory

            factory = AgentFactory()
            content = ""

            agent_methods = ["software_engineer", "software_reviewer"]

            for method_name in agent_methods:
                if not hasattr(factory, method_name):
                    continue

                method = getattr(factory, method_name)
                if not callable(method):
                    continue

                source = inspect.getsource(method)

                import re

                backstory_match = re.search(
                    r'backstory=dedent\s*\(\s*[rf]?"""(.*?)"""\s*\)',
                    source,
                    re.DOTALL,
                )
                goal_match = re.search(
                    r'goal=dedent\s*\(\s*[rf]?"""(.*?)"""\s*\)',
                    source,
                    re.DOTALL,
                )

                if backstory_match:
                    content += backstory_match.group(1) + " "
                if goal_match:
                    content += goal_match.group(1) + " "

            return content

        except Exception as e:
            print(f"Warning: Could not read AgentFactory instructions: {e}")
            return ""

    def _generate_text_with_word_count(self) -> str:
        total_words = 0
        total_words += self.prompt_context_size
        total_words += self.OTHER_INSTRUCTIONS_SIZE
        return " ".join(["placeholder"] * total_words)

    def _get_content(self, file_path: str) -> str:
        try:
            path = Path(file_path)
            if not path.is_absolute():
                project_root = Path(__file__).parent.parent.parent
                path = project_root / file_path

            if not path.exists():
                return ""

            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
                return content

        except Exception as e:
            print(f"Warning: Could not read file {file_path}: {e}")
            return ""
