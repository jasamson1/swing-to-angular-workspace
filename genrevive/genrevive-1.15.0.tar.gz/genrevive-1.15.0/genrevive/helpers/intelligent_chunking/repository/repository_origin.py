"""
Repository for managing intelligent chunking data in ChromaDB.
Provides CRUD operations for document chunks.
"""
from typing import List, Dict, Any, Optional
import uuid
import datetime

from chromadb import Collection

from .db_provider import DbProvider


class RepositoryOrigin:
    """Repository for intelligent chunking document storage in ChromaDB."""
    
    _process_id: Optional[str] = None
    
    def __init__(self):
        """Initialize repository with ChromaDB client."""
        collection_name = DbProvider.get_origin_chunks_collection_name()
        self._collection: Optional[Collection] = DbProvider.get_or_create_collection_by_name(collection_name)
    
        RepositoryOrigin._process_id = DbProvider.get_current_process_id()

    @classmethod
    def get_process_id(cls) -> str:
        """Get the shared process ID for this execution."""
        if cls._process_id is None:
            cls._process_id = f"origin_process_{datetime.datetime.now().isoformat()}_{uuid.uuid4()}"
        return cls._process_id
    
    
    def add(
        self,
        ids: List[str],
        chunks: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """
        Add documents to the collection.
        
        Args:
            ids: List of unique chunk IDs e.g  ...genrev..._chunk_0_2026-01-19T21:37:33.611166, ...genrev...chunk_1_last_chunk_2026-01-19T21:37:33.611334

            chunks: List of document chunks
            metadatas: Optional list of metadata dictionaries
        
        Raises:
            ValueError: If required metadata fields are missing
        """
        for metadata in metadatas or []:
            metadata["process_id"] = self.get_process_id()
        self._validate_metadatas(metadatas)

        self._collection.add(
            ids=ids,
            documents=chunks,
            metadatas=metadatas,
        )
    
    def _validate_metadatas(self, metadatas: Optional[List[Dict[str, Any]]]) -> None:
        if metadatas is None:
            raise ValueError("Metadatas are required for OriginRepository")
        
        required_fields = ["process_id", "target_filepath_full"]
        
        for idx, metadata in enumerate(metadatas):
            missing_fields = [field for field in required_fields if field not in metadata]
            if missing_fields:
                raise ValueError(
                    f"Metadata at index {idx} is missing required fields: {', '.join(missing_fields)}"
                )
    
    def update_consolidated_flag(
        self,
        ids: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
    ) -> None:
        """
        Update existing documents in the collection.
        
        Args:
            ids: List of document IDs to update
            metadatas: Optional[List[Dict[str, Any]]] = None,
        """

        self._collection.update(
            ids=ids,
            metadatas=metadatas,
        )
        
    def get_chunks_by_target_filepath_full(
        self,
        target_filepath_full: str) -> List[Dict[str, Any]]:
        
        result = self._collection.get(
            where={"$and": [
                {"target_filepath_full": target_filepath_full},
                {"process_id": self.get_process_id()}
            ]},
            include=["documents"])
        
        return self._map_results(result)
    
    def _map_results(self, result: Dict[str, Any]) -> List[Dict[str, Any]]:
        chunks = []
        for idx in range(len(result["ids"])):
            chunk = {
                "chunk_id": result["ids"][idx],
                "content": result["documents"][idx],
            }
            chunks.append(chunk)
        return chunks
    
    
