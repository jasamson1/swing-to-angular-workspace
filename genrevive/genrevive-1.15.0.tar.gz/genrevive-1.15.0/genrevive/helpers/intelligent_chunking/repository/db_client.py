"""
Singleton client for ChromaDB.
Provides thread-safe access to a single ChromaDB client instance.
"""
import threading
from typing import Optional

import chromadb
from chromadb import ClientAPI

from .db_provider import DbProvider


class ChromaDBClient:
    """Singleton wrapper for ChromaDB client."""
    
    _instance: Optional[ClientAPI] = None
    _lock: threading.Lock = threading.Lock()
    
    @classmethod
    def get_client(cls) -> ClientAPI:
        """
        Get the singleton ChromaDB client instance.
        Thread-safe lazy initialization on first call.
        
        Returns:
            ClientAPI: The ChromaDB client instance
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls._initialize_client()
        
        return cls._instance
    
    @classmethod
    def _initialize_client(cls) -> ClientAPI:
        """
        Initialize the ChromaDB client with configuration from DbProvider.
        
        Returns:
            ClientAPI: Configured ChromaDB client instance
        """
        db_path = DbProvider.get_db_path()
        settings = DbProvider.get_settings()
        
        client = chromadb.PersistentClient(
            path=db_path,
            settings=chromadb.Settings(**settings)
        )
        
        return client
    
    @classmethod
    def reset_instance(cls) -> None:
        """
        Reset the singleton instance.
        Useful for testing purposes.
        """
        with cls._lock:
            cls._instance = None
