import os
from pathlib import Path
from typing import Optional, Dict, Any, Collection
import uuid
from datetime import datetime

class DbProvider:
    DEFAULT_DB_PATH = "intelligent_chunking_db"
    DEFAULT_ORIGIN_CHUNKS_COLLECTION_NAME = "intelligent_chunking_origin"
    DEFAULT_SE_CHUNKS_COLLECTION_NAME = "intelligent_chunking_se"
    DEFAULT_SR_CHUNKS_COLLECTION_NAME = "intelligent_chunking_sr"
    _collection_name_origin: Optional[str] = None
    _collection_name_se: Optional[str] = None
    _collection_name_sr: Optional[str] = None
    _process_id: Optional[str] = None
    
    @staticmethod
    def get_db_path() -> str:
        project_root = os.environ.get("TARGET_PROJECT_PATH")
        if not project_root:
            project_root = os.environ.get("LOCAL_TARGET_PROJECT_PATH")
        if not project_root:
            raise EnvironmentError("Project root path not set in environment variables.")
        
        db_path = os.environ.get("INTELLIGENT_CHUNKING_DB_PATH", 
                                  os.path.join(project_root, DbProvider.DEFAULT_DB_PATH))
        
        os.makedirs(db_path, exist_ok=True)
        
        return str(db_path)
    
    @classmethod
    def get_origin_chunks_collection_name(cls) -> str:
        if cls._collection_name_origin is None:
            cls._collection_name_origin = cls.DEFAULT_ORIGIN_CHUNKS_COLLECTION_NAME
        
        return cls._collection_name_origin
    
    @classmethod
    def get_se_chunks_collection_name(cls) -> str:
        if cls._collection_name_se is None:
            cls._collection_name_se = cls.DEFAULT_SE_CHUNKS_COLLECTION_NAME
        return cls._collection_name_se
    
    @classmethod
    def get_sr_chunks_collection_name(cls) -> str:
        if cls._collection_name_sr is None:
            cls._collection_name_sr = cls.DEFAULT_SR_CHUNKS_COLLECTION_NAME
        return cls._collection_name_sr
    
    @classmethod
    def get_current_process_id(cls) -> str:
        if cls._process_id is None:
            cls._process_id = f"process_{datetime.now().isoformat()}_{uuid.uuid4()}"
        
        return cls._process_id
    
    @staticmethod
    def get_settings() -> dict:
        return {
            "is_persistent": True,
            "anonymized_telemetry": False,
            "allow_reset": False,
        }
    
    
    @staticmethod
    def get_default_collection_metadata() -> dict:
        return {"hnsw:space": "cosine"}


    @staticmethod
    def get_or_create_collection_by_name(collection_name: str):
        # lazy import to avoid circular imports at module import time
        from .db_client import ChromaDBClient
        client = ChromaDBClient.get_client()
        return client.get_or_create_collection(
            name=collection_name,
            metadata=DbProvider.get_default_collection_metadata()
        )


