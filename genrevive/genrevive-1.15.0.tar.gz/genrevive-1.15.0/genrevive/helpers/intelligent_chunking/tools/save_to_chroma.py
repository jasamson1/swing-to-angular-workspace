from textwrap import dedent
from crewai import TaskOutput
from crewai.tools import BaseTool
from typing import List, Dict, Any
from pydantic import BaseModel, Field
import datetime

from genrevive.helpers.intelligent_chunking.repository.repository_se import RepositorySE
from genrevive.helpers.intelligent_chunking.repository.repository_sr import RepositorySR


class SaveChromaToolInput(BaseModel):
    """Input schema for TaskTool."""
    agent: str = Field(..., description="The agent name, the role e.g. 'software_engineer' or 'solution_reviewer'")
    source_filepath: str = Field(..., description="source file path of the original document")
    output: TaskOutput = Field(..., description="The TaskOutput containing chunk to be saved")
    filename: str = Field(..., description="The target filename of the file being processed")
    idx: int = Field(..., description="The number of the chunk of given file being processed")
    origin_chunk_id: str = Field(..., description="The origin chunk id from which this chunk was created")


class SaveToChroma(BaseTool):
    name: str = "Save to Chroma tool"
    description: str = """
        This tool saves output chunks to ChromaDB.
        It takes a list of chunks and their corresponding metadata as input.
        Metadata should include 'source_filepath', 'origin_chunk_id'.
    """
    args_schema: type[BaseModel] = SaveChromaToolInput

    def __init__(self):
        self.se_reo = RepositorySE()
        self.sr_repo = RepositorySR()

    def _run(self, 
             agent: str, 
             source_filepath: str, 
             output: TaskOutput, 
             filename: str, idx: int, 
             origin_chunk_id: str) -> dict[bool, str]:
        
        chunk_id = f"{filename}_chunk_{idx}_{datetime.datetime.now().isoformat()}"
        repo = None
        if "software engineer" in agent.lower():
            repo = self.se_reo
        elif "reviewer" in agent.lower():
            repo = self.sr_repo
        if repo:
            repo.add(
                ids=[chunk_id],
                chunks=[output.raw],
                metadatas=[{
                    "source_filepath": source_filepath,
                    "origin_chunk_id": origin_chunk_id,
                }]
            )
            return {"success": True, "message": f"Chunk {chunk_id} saved successfully."}
        return {"success": False, "message": "No valid repository found for the given agent."}