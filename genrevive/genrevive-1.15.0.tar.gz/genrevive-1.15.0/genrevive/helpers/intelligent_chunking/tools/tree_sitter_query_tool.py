import os
import re
import shutil
from typing import List, Callable, Dict
from crewai.tools import tool


from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from genrevive.helpers.intelligent_chunking.tree_sitter_query_service import TreeSitterQueryService



class TreeQueryToolInput(BaseModel):
	"""Input schema for TreeQueryTool."""
	method_name: str = Field(..., description="The name of the method to query for")
	file_path: str = Field(..., description="The path to the file to query")


class TreeQueryTool(BaseTool):
	name: str = "Tree query tool"
	description: str = "Query for method implementation by name. Returns the method source code."
	args_schema: type[BaseModel] = TreeQueryToolInput
	
	def _run(self, method_name: str, file_path: str) -> str:
		"""Query for method implementation by name.
		
		Args:
			method_name: The name of the method to query for.
			file_path: The path to the file to query.
			
		Returns:
			str: The method implementation source code.
		"""
		return QueryTool().query(method_name, file_path)




class QueryTool:
	"""Wrapper for TreeSitterQueryService - queries method content from Java files."""
	
	def __init__(self):
		"""
		Initialize QueryTool.
		
		Args:
			default_file_path: Default file to query (can be overridden per query)
		"""
		self.service = TreeSitterQueryService()
	
	def query(self, method_name: str, file_path: str = None) -> str:
		"""
		Query for method implementation by name.
		
		Args:
			method_name: Name of the method to extract
			file_path: Path to Java file (uses default if not provided)
			
		Returns:
			Method source code or error message
		"""
		
		try:
			method_content = self.service.get_method_content(file_path, method_name)
			
			if method_content is None:
				return f"Method '{method_name}' not found in {file_path}"
			
			return method_content
		
		except FileNotFoundError as e:
			return f"Error: {e}"
		except Exception as e:
			return f"Error querying method: {e}"