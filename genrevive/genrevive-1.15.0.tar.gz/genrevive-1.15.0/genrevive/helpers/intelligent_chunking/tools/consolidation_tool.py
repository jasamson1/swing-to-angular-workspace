from typing import Any, Type, Union, List, Dict, Optional, Tuple, Iterable
from pydantic import BaseModel, Field, PrivateAttr
from crewai.tools.base_tool import BaseTool
import codecs
from genrevive.helpers.intelligent_chunking.repository.repository_se import RepositorySE
from genrevive.helpers.intelligent_chunking.repository.repository_sr import RepositorySR
import re
from pathlib import Path
import os 


class GetChunksArgs(BaseModel):
    target_filepath_full: str = Field(..., description="Absolute or project-relative path used when saving chunks")
    agent: str = Field(..., description="Either software engineer or software reviewer agent type")

class ConsolidationTool(BaseTool):
    markdown_path: Optional[str] = None
    name: str = "consolidation_tool"
    description: str = "Retrieve translated chunks for a given target file path and current process id and consolidate them"
    _repository: Union[RepositorySE, RepositorySR] = PrivateAttr()

    def __init__(self, repository,**data):
        super().__init__(**data)
        self._repository = repository
        

    def _save_code(self, save_file_path: str, code: str): 
        folder = os.path.dirname(save_file_path)
        os.makedirs(folder, exist_ok=True)
        with open(save_file_path, "w") as file:
            file.write(code)

    def _unescape_text(self, s: str) -> str:
        # Converts "\\n" -> newline, "\\t" -> tab, "\\\"" -> "
        return codecs.decode(s, 'unicode_escape')

    def _save_markdown(self, save_file_path: str, markdown: str, agent: str) -> str:
        p = Path(save_file_path)
        p.parent.mkdir(parents=True, exist_ok=True) 
        if agent == "sr":

            needs_newline = (len(markdown) > 0 and not markdown.endswith("\n"))
            with p.open("a", encoding="utf-8", newline="") as f:
                f.write("\n## Agent: Software Reviewer\n")
                f.write(markdown)
                if needs_newline:
                    f.write("\n")
            return f"OK: appended {len(markdown.encode('utf-8'))} bytes to {p}"
        
        elif agent == "se":
            needs_newline = (len(markdown) > 0 and not markdown.endswith("\n"))
            with p.open("w", encoding="utf-8", newline="") as f:
                f.write("\n## Agent: Software Engineer\n")
                f.write(markdown)
                if needs_newline:
                    f.write("\n")
            return f"OK: written {len(markdown.encode('utf-8'))} bytes to {p}"
        
        else:
            raise ValueError(f"Unknown agent type: {agent}. Expected 'se' or 'sr'.")

        
    
    def _merge_markdown(self, data: Iterable[dict]) -> str:
        contents = [self._unescape_text(str(md['markdown']))
                    for md in (item['markdown'] for item in data)]

        merged = "\n".join(s for s in contents if s is not None)
        return merged

    
    def _run(self, target_filepath_full: str, agent: str) -> str:
        
        target_filepath_full = os.path.normpath(target_filepath_full)
        chunks = self._repository.get_chunks_by_target_filepath_full(target_filepath_full)
        content = [self._unescape_text(str(chunk["content"])) for chunk in chunks]
        merged_chunks ="".join(content)
        merged_chunks = self._java_bracket_complete(merged_chunks)
        self._save_code(target_filepath_full, merged_chunks)

         
        merged_markdown = self._merge_markdown(chunks)
        markdown_path = f"{str(target_filepath_full)}.md"

        self._save_markdown(markdown_path, merged_markdown, agent)

        return f"Consolidation complete for {target_filepath_full}. Merged code saved to {target_filepath_full} and markdown saved to {markdown_path}."
    
    def _java_bracket_complete(self, code: str) -> str:
        opening_count = code.count('{')
        closing_count = code.count('}')
        
        if opening_count > closing_count:
            missing_brackets = opening_count - closing_count
            code += '\n' + ('}' * missing_brackets)
        
        return code
        
       
