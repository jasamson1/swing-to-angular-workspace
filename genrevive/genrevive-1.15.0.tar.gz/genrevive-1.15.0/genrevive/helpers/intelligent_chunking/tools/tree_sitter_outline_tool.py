from crewai.tools import BaseTool
from pydantic import BaseModel, Field

from genrevive.helpers.intelligent_chunking.tree_sitter_query_service import TreeSitterQueryService


class TreeOutlineToolInput(BaseModel):
	"""Input schema for TreeOutlineTool."""
	file_path: str = Field(..., description="Path to the Java source file to generate outline for")


class TreeOutlineTool(BaseTool):
	name: str = "Tree outline tool"
	description: str = "Generate a structured outline of a Java file showing classes, methods, and fields."
	args_schema: type[BaseModel] = TreeOutlineToolInput
	
	def _run(self, file_path: str) -> str:
		"""Generate outline for a Java file.
		
		Args:
			file_path: Path to the Java source file.
			
		Returns:
			str: The file outline showing classes, methods, and fields.
		"""
		return OutlineTool().outline(file_path)



class OutlineTool:
	"""Wrapper for TreeSitterQueryService - generates file outlines from Java files."""
	
	def __init__(self):
		"""Initialize OutlineTool."""
		self.service = TreeSitterQueryService()
	
	def outline(self, file_path: str) -> str:
		"""
		Generate an outline of a Java file.
		
		Args:
			file_path: Path to Java file
			
		Returns:
			File outline showing classes, methods, and fields or error message
		"""
		
		try:
			outline_content = self.service.get_outline(file_path)
			
			if outline_content is None:
				return f"Could not generate outline for {file_path}"
			
			return outline_content
		
		except FileNotFoundError as e:
			return f"Error: {e}"
		except Exception as e:
			return f"Error generating outline: {e}"
