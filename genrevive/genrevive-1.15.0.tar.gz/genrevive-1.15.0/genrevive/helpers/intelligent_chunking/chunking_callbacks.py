from datetime import datetime
import os
from pathlib import Path
import re
import codecs
from crewai import TaskOutput

from genrevive.helpers.intelligent_chunking.repository.repository_se import (
    RepositorySE,
)
from genrevive.helpers.intelligent_chunking.repository.repository_sr import (
    RepositorySR,
)


class ChunkingCallbacks:
    def __init__(self):
        self.se_repo = RepositorySE()
        self.sr_repo = RepositorySR()

    def save_code_blocks(self, output: TaskOutput):
        agent = str(output.agent).lower()
        input_text = output.raw

        # Pattern to extract metadata from expected output format
        pattern = r"""  # noqa: S5852
            "code"\s*:\s*"(?P<code>(?:\\.|[^"\\])*)"\s*,\s*
            "chunk_idx"\s*:\s*(?P<chunk_idx>\d+)\s*,\s*
            "origin_chunk_id"\s*:\s*"(?P<origin_chunk_id>[^"]+)"\s*,\s*
            "filename"\s*:\s*"(?P<filename>[^"]*)"\s*,\s*
            "target_filepath_full"\s*:\s*"(?P<target_filepath_full>[^"]+)"
        """

        match = re.search(
            pattern, input_text, re.DOTALL | re.VERBOSE
        )  # NOSONAR

        if match:
            code = codecs.decode(match.group("code").strip(), "unicode_escape")
            idx = int(match.group("chunk_idx"))
            origin_chunk_id = match.group("origin_chunk_id").strip()
            filename = match.group("filename").strip()
            target_filepath_full = os.path.normpath(match.group("target_filepath_full").strip())

            # Extract markdown block that comes after the JSON
            markdown_pattern = r"```markdown\s*(.*?)\s*```"
            markdown_match = re.search(markdown_pattern, input_text, re.DOTALL)
            markdown_content = (
                markdown_match.group(1).strip() if markdown_match else ""
            )
        else:
            # Fallback to old pattern if new format not found
            code_pattern = (
                r"```.*?\s*filename:\s*(?P<filename>.+?)\s*\n(?P<code>.*?)```"
            )
            code_match = re.search(code_pattern, input_text, re.DOTALL)
            code = code_match.group("code").strip() if code_match else ""
            filename = (
                code_match.group("filename").strip() if code_match else ""
            )
            origin_chunk_id = ""
            target_filepath_full = ""
            idx = 0
            markdown_content = ""

        chunk_id = f"{agent}_{target_filepath_full}_{filename}_chunk_{idx}"
        if "last_chunk" in origin_chunk_id:
            chunk_id += "_last_chunk"
        chunk_id += f"_{datetime.now().isoformat()}"

        repo = None
        if "software engineer" in agent.lower():
            repo = self.se_repo
        elif "reviewer" in agent.lower():
            repo = self.sr_repo
        if repo:
            repo.add(
                ids=[chunk_id],
                chunks=[code],
                metadatas=[
                    {
                        "target_filepath_full": target_filepath_full,
                        "origin_chunk_id": origin_chunk_id,
                        "markdown": markdown_content,
                    }
                ],
            )
            return {
                "success": True,
                "message": f"Chunk {chunk_id} saved successfully.",
            }
        return {
            "success": False,
            "message": "No valid repository found for the given agent.",
        }
