from genrevive.helpers.common.shell_utils import run_command, get_local_command_path
import logging

# info
# we don't use a rewrite.yml, because that would require us to use the openrewrite-plugin
# and thus modify the pom.xml.


def execute_mvn_rewrite(dependencies: list[str], recipes: list[str], cwd: str = None):
    """
    Executes the given OpenRewrite recipes.

    Args:
        cwd (str): The working directory where the Maven project is located. Choose None for the current directory.
        dependencies (list[str]): A list of Maven artifact coordinates for the OpenRewrite dependencies
            required to execute the recipes.
        recipes (list[str]): A list of OpenRewrite recipe identifiers to be executed.

    Returns:
        bool: Always returns True after executing the recipes.

    Example:
        execute_mvn_rewrite(
            cwd = "C:\\Users\\ermustermann\\repos\\demo_mvn",
            dependencies=['org.openrewrite.recipe:rewrite-migrate-java:LATEST',
                          'org.openrewrite.recipe:rewrite-spring:RELEASE'],
            recipes=['org.openrewrite.java.migrate.guava.NoGuavaImmutableSetOf',
                     'org.openrewrite.java.migrate.guava.NoGuavaImmutableListOf',
                     'org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_3']
        )
    """
    maven_command = get_local_command_path("mvn")
    logging.debug(f"Using maven at: {maven_command}")

    run_command(
        [
            maven_command,
            "-U",
            "org.openrewrite.maven:rewrite-maven-plugin:run",
            f"-Drewrite.recipeArtifactCoordinates={','.join(dependencies)}",
            f"-Drewrite.activeRecipes={','.join(recipes)}",
        ],
        cwd=cwd,
    )
