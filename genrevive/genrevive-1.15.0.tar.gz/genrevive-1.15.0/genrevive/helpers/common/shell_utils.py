import logging
import os
import shutil
import subprocess

from dotenv import load_dotenv


def run_command(command: list[str], **kwargs):
    """Runs a shell command and logs its output and errors."""
    logging.info(f"Running command: {' '.join(command)}")
    try:
        load_dotenv()
        shell = os.environ.get("USE_SHELL", "false")  # default to "false" if not set
        if shell.lower() == "true":
            result = subprocess.run(
                command,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                shell=True,
                **kwargs,
            )
        else:
            result = subprocess.run(
                command,
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                **kwargs,
            )
        logging.info(f"Command output: {result.stdout}")
        if result.stderr:
            logging.error(f"Command error: {result.stderr}")
    except subprocess.CalledProcessError as e:
        logging.error(f"Command failed with return code {e.returncode}")
        logging.error(f"Command output: {e.output}")
        logging.error(f"Command error: {e.stderr}")
        raise


def run_build_process(
    command: list[str],
    cwd: str,
    error_keywords: list = ["Error", "ERROR"],
    warning_keywords: list = ["WARNING"],
    **kwargs,
) -> dict:
    """Run a build process and log output in real-time."""
    logging.info(f"Executing build command: {' '.join(command)}")
    load_dotenv()
    shell = os.environ.get("USE_SHELL", "false")  # default to "false" if not set
    if shell.lower() == "true":
        process = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            shell=True,
            encoding="utf-8",
            **kwargs,
        )
    else:
        process = subprocess.Popen(
            command,
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            **kwargs,
        )

    log_statements = ""

    while True:
        line = process.stdout.readline()
        if not line:
            break
        stripped_line = line.strip()
        if any(keyword in line for keyword in error_keywords):
            logging.error(stripped_line)
        elif any(keyword in line for keyword in warning_keywords):
            logging.warning(stripped_line)
        else:
            logging.info(stripped_line)
        log_statements += line + "\n"

    process.wait()
    build_success = process.returncode == 0
    logging.info(f"Build result: {build_success}")
    return {"success": build_success, "description": log_statements}


def get_local_command_path(command: str) -> str:
    """Find the path of a given command in the system's PATH."""
    command_path = shutil.which(command)
    if not command_path:
        logging.error(f"{command} command not found in PATH")
        raise EnvironmentError("command not found in PATH")
    return command_path
