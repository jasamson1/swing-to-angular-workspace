from genrevive.helpers.common.content_minifier import ContentMinifier


class MarkdownRenderer:
    @staticmethod
    def render_content(content: str | dict | list, content_type: str) -> str:
        if isinstance(content, str):
            return f"```{content_type}\n{ContentMinifier.minify_content(content)}\n```"
        if isinstance(content, dict):
            markdown = ""
            for key, value in content.items():
                markdown += f"{key}: ```{content_type}\n{ContentMinifier.minify_content(value)}\n```\n"
            return markdown
        if isinstance(content, list):
            markdown = ""
            for item in content:
                markdown += (
                    f"```{content_type}\n{ContentMinifier.minify_content(item)}\n```\n"
                )
            return markdown

    @staticmethod
    def render_dict_to_markdown(data: dict) -> str:
        markdown = ""
        for key, value in data.items():
            if isinstance(value, dict):
                content = value.get("content", "")
                if isinstance(content, list):
                    markdown += f"## {key}:\n"
                    for item in content:
                        minified_item = ContentMinifier.minify_content(item)
                        if minified_item is None:
                            markdown += f"{minified_item}\n"
                        else:
                            markdown += (
                                f"```{value.get('type', '')}\n{minified_item}\n```\n"
                            )
                else:
                    minified_content = ContentMinifier.minify_content(content)
                    if minified_content is None:
                        markdown += f"## {key}:\n{minified_content}\n"
                    else:
                        markdown += f"## {key}:\n```{value.get('type', '')}\n{minified_content}\n```\n"
            elif isinstance(value, list):
                markdown += f"## {key}:\n"
                for item in value:
                    for subkey, sub_value in item.items():
                        content = ContentMinifier.minify_content(
                            sub_value.get("content", "")
                        )
                        markdown += f"### {subkey}:\n```{sub_value.get('type', '')}\n{content}\n```\n"
            else:
                content = ContentMinifier.minify_content(value)
                markdown += f"## {key}:\n{content}\n"

        return markdown
