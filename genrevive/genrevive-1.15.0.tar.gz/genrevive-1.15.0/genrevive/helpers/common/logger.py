import logging
import os
import sys
from functools import wraps

from dotenv import load_dotenv


class Logger(object):
    def __init__(self):
        load_dotenv()
        log_path = os.environ["LOG_PATH"]
        self.terminal = sys.stdout
        self.log = open(log_path, "a", encoding="utf-8")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        # this flush method is needed for python 3 compatibility.
        # this handles the flush command by doing nothing.
        # you might want to specify some extra behavior here.
        pass


def log_activity_execution(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        class_name = args[0].__class__.__name__ if args else "UnknownClass"
        logging.info(f"Activity execution started: {class_name}")
        result = None
        try:
            result = func(*args, **kwargs)
        except Exception as e:
            logging.error(f"Exception occurred in {class_name}.{func.__name__}(): {e}")
            raise
        logging.info(f"Activity execution completed: {class_name}")
        return result

    return wrapper
