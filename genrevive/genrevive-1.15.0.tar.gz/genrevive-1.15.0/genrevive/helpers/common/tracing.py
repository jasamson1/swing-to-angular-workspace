import os
import logging
import openlit
import base64
import uuid
import atexit
from dotenv import load_dotenv
from opentelemetry.sdk.environment_variables import OTEL_SDK_DISABLED
from opentelemetry import trace

# Internal flag to prevent reinitialization
_tracing_initialized = False


def set_langfuse_tracing():
    """
    Initializes Langfuse tracing if the LANGFUSE_TRACING environment variable is set to true.
    It sets up the necessary environment variables for OpenTelemetry (OTEL) and Langfuse,
    enables the OTEL SDK, initializes the OpenLit SDK, and then disables the OTEL SDK.
    
    Raises:
    Exception: If any error occurs during the tracing setup process.
    """

    global _tracing_initialized
    if _tracing_initialized:
        logging.warning("Langfuse tracing is already set.")
        return
    try:
        load_dotenv()
        tracing = os.getenv("LANGFUSE_TRACING", "false").lower() == "true"
        if tracing:
            logging.info("Tracing is enabled")

            # Encode Langfuse credentials in base64 for OTEL headers
            os.environ["LANGFUSE_AUTH"] = base64.b64encode(
                f"{os.getenv('LANGFUSE_PUBLIC_KEY')}:{os.getenv('LANGFUSE_SECRET_KEY')}".encode()
            ).decode()

            # Set OTEL header with encoded credentials
            os.environ["OTEL_EXPORTER_OTLP_HEADERS"] = (
                f"Authorization=Basic {os.getenv('LANGFUSE_AUTH')}"
            )

            # Enable OTEL SDK before initializing OpenLit
            enable_otel_sdk()

            # Initialize the OpenLit SDK for tracing
            openlit.init()

            # Get tracer and create an unique session id
            tracer = trace.get_tracer("test_tracer")
            session_id = str(uuid.uuid4())

            # Start a root span with Langfuse session information
            root_span = tracer.start_span(
                "crew_ai_app_session",
                attributes={
                    "langfuse.session.id": session_id,
                    "langfuse.session.name": "GenRevive run",
                    "langfuse.session.metadata.env": "local",
                },
            )

            # Put span into context so all traces are children of this session
            ctx_token = trace.use_span(root_span, end_on_exit=True)
            ctx_token.__enter__()

            # Cleanup
            def close_session():
                ctx_token.__exit__(None, None, None)
                root_span.end()

            atexit.register(close_session)

            # Disable OTEL SDK after initialization to prevent further tracing for optimization of performance
            disable_otel_sdk()

            _tracing_initialized = True
            logging.info("Langfuse tracing has been set successfully.")

    except Exception as e:
        logging.error(f"Error in setting langfuse tracing: {e}")
        raise


def enable_otel_sdk():
    """
    Enables the OpenTelemetry SDK by setting the OTEL_SDK_DISABLED environment variable to 'false'.
    This allows telemetry data to be collected and exported. It checks if the SDK is currently disabled
    """

    is_disabled = os.environ.get(OTEL_SDK_DISABLED, "false").lower() == "true"
    if is_disabled:
        os.environ[OTEL_SDK_DISABLED] = "false"


def disable_otel_sdk():
    """
    Disables the OpenTelemetry SDK by setting the OTEL_SDK_DISABLED environment variable to 'true'.
    This stops the collection and export of telemetry data after the necessary initialization is complete.
    """

    os.environ[OTEL_SDK_DISABLED] = "true"
