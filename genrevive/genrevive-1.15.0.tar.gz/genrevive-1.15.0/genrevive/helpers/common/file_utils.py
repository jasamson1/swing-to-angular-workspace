import logging
import os
from pathlib import Path


class FileUtils:
    """Class for file-related utility functions."""

    @staticmethod
    def write_file(file_path: str, content: str) -> None:
        """
        Write content to a specified file. Creates directories if they do not exist.

        Args:
            file_path (str): The path to the file.
            content (str): The content to write to the file.

        Raises:
            ValueError: If file_path or content is invalid.
            OSError: If there is an issue with file operations.
        """
        try:
            # Validate file path
            if not file_path or not isinstance(file_path, str):
                logging.error(f"[write_file] Invalid file path provided: {file_path}")
                raise ValueError("File path is invalid or empty.")
            # Validate content
            if not content or not isinstance(content, str):
                logging.error("[write_file] Invalid content provided.")
                raise ValueError("Content is invalid or empty.")

            # Create directories if they don't exist
            try:
                os.makedirs(os.path.dirname(file_path), exist_ok=False)
                logging.info(f"Directories for path {os.path.dirname(file_path)} created.")
            except FileExistsError:
                pass

            # Write content to file
            with open(file_path, "w", encoding="utf-8") as file:
                file.write(content)
            logging.info(f"[write_file] Content written successfully to '{file_path}'")

        except ValueError as ve:
            logging.error(f"ValueError: {ve}")
            raise ValueError("Invalid input. Please check the file path and content.")
        except OSError as oe:
            logging.error(f"OSError: {oe}")
            raise OSError("Failed to write the file due to an OS error.")
        except Exception as e:
            logging.error(f"Unexpected error: {e}")
            raise Exception("An unexpected error occurred while writing the file.")

    @staticmethod
    def read_file(file_path: str) -> str:
        """
        Read content from a specified file.

        Args:
            file_path (str): The path to the file.

        Returns:
            str: The content of the file.

        Raises:
            FileNotFoundError: If the file does not exist.
            OSError: If there is an issue with file operations.
        """
        try:
            with open(file_path, "r", encoding="utf-8") as file:
                content = file.read()
            return content
        except FileNotFoundError as fnf_error:
            logging.error(f"FileNotFoundError: {fnf_error}")
            raise
        except OSError as oe:
            logging.error(f"OSError: {oe}")
            raise
        except Exception as e:
            logging.error(f"Unexpected error: {e}")
            raise

    @staticmethod
    def list_files(folder_path: str) -> list:
        """
        List all files in a specified directory. Creates the directory if it does not exist.

        Args:
            folder_path (str): The path to the directory.

        Returns:
            list: A list of filenames in the directory.

        Raises:
            OSError: If there is an issue with directory operations.
        """
        try:
            if not os.path.exists(folder_path):
                # If the directory does not exist, create it
                raise FileNotFoundError(f"Directory not found: {folder_path}")
            files = [
                f
                for f in os.listdir(folder_path)
                if os.path.isfile(os.path.join(folder_path, f))
            ]
            return files
        except FileNotFoundError as fnf_error:
            logging.error(f"FileNotFoundError: {fnf_error}")
            raise
        except OSError as oe:
            logging.error(f"OSError: {oe}")
            raise
        except Exception as e:
            logging.error(f"Unexpected error: {e}")
            raise

    @staticmethod
    def find_files_in_directory(extension: str, directory: str) -> list[str]:
        """
        Find all files with the given extension in the specified directory.

        Args:
            extension (str): The file extension to search for.
            directory (str): The directory to search in.

        Returns:
            list[str]: A list of file paths that match the extension.
        """
        try:
            directory_path = Path(directory)

            if not directory_path.exists():
                raise FileNotFoundError(f"Directory not found: {directory}")
            if not directory_path.is_dir():
                raise NotADirectoryError(f"Not a directory: {directory}")

            matching_files = [
                str(file_path) for file_path in directory_path.rglob(f"*{extension}")
            ]
            logging.debug(
                f"Found {len(matching_files)} files with extension'{extension}' in directory '{directory}'"
            )
            return matching_files
        except FileNotFoundError as fnf_error:
            logging.error(f"FileNotFoundError: {fnf_error}")
            raise
        except NotADirectoryError as nd_error:
            logging.error(f"NotADirectoryError: {nd_error}")
            raise
        except OSError as os_error:
            logging.error(f"OSError while accessing {directory}: {os_error}")
            raise
        except Exception as e:
            logging.error(f"Unexpected error while searching files in {directory}: {e}")
            raise

    @staticmethod
    def find_file_by_name(full_file_name: str, directory_path: str) -> str:
        """
        Find a file with the given name in the specified directory.

        Args:
            full_file_name (str): The full file name to search for (e.g. "my_file.txt").
            directory_path (str): The directory to search in.

        Returns:
            str: The full path of the first file found, or None if not found.
        """
        if not Path(directory_path).is_dir():
            logging.error(
                f"[find_file_by_name] Directory '{directory_path}' does not exist or is not a directory."
            )
            raise ValueError("Directory does not exist.")

        for root, _, files in os.walk(directory_path):
            if full_file_name in files:
                return os.path.join(root, full_file_name)

    @staticmethod
    def list_files_with_extension(folder_path: str, file_extension: str) -> list:
        """
        List all files in a specified directory with a given file extension.

        Args:
            folder_path (str): The path to the directory.
            file_extension (str): The file extension to filter by.

        Returns:
            list: A list of matching file names.

        Raises:
            OSError: If directory operations fail.
        """
        try:
            if not os.path.exists(folder_path):
                raise FileNotFoundError(f"Directory not found: {folder_path}")

            return [
                f
                for f in os.listdir(folder_path)
                if os.path.isfile(os.path.join(folder_path, f))
                and f.endswith(file_extension)
            ]
        except OSError as oe:
            logging.error(f"OSError while listing files in {folder_path}: {oe}")
            raise
        except Exception as e:
            logging.error(f"Unexpected error while listing files in {folder_path}: {e}")
            raise

    @staticmethod
    def read_files_with_keyword(folder_path: str, keyword: str) -> dict:
        """
        Read multiple files in a folder and return contents of files containing keyword.

        Args:
            folder_path (str): The directory path.
            keyword (str): The keyword to search for in the file contents.

        Returns:
            dict: A dictionary with the filenames as keys and file contents as values.

        Raises:
            OS Error: If directory operations fails.
        """
        try:
            result = {}
            if not os.path.exists(folder_path):
                raise FileNotFoundError(f"Directory {folder_path} does not exist.")

            for file_name in os.listdir(folder_path):
                file_path = os.path.join(folder_path, file_name)
                if os.path.isfile(file_path):
                    with open(file_path, "r") as file:
                        content = file.read()
                        if keyword in content:
                            result[file_name] = content
            return result
        except (FileNotFoundError, OSError) as e:
            logging.error(f"Error: {e}")
            raise
        except Exception as e:
            logging.error(f"Unexpected error: {e}")
            raise

    @staticmethod
    def read_lines(file_path: str) -> list:
        """
        Read a file and return its content as a list of lines.

        Args:
            file_path (str): The path to the file.

        Returns:
            list: List of lines from the file.

        Raises:
            FileNotFoundError: If the file does not exist.
            OSError: If file operations fail.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        try:
            with open(file_path, "r", encoding="utf-8") as file:
                return file.readlines()
        except OSError as e:
            logging.error(f"OSError while reading file {file_path}: {e}")
            raise
        except Exception as e:
            logging.error(f"Unexpected error while reading file {file_path}: {e}")
            raise
