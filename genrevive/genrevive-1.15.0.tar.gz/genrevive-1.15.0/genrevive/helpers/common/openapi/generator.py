import logging
import os
import shutil

from genrevive.helpers.common.shell_utils import run_command, get_local_command_path


def generate_api_client(
    openapi_file_path: str,
    project_path: str,
    generator_name: str,
    generator_options=None,
):
    """
    Generate an API client from an OpenAPI specification using the OpenAPI Generator CLI.

    This function automates the typical workflow for producing an API client:
    1. Creates a temporary output directory inside the provided project path.
    2. Locates the local openapi-generator-cli executable (via get_local_command_path) and runs it to generate sources.
    3. Moves the generated API files into the project (via __move_api_files).
    4. Cleans up the temporary directory when finished.

    Parameters
    ----------
    openapi_file_path : str
        Path to the OpenAPI specification file (.yaml or .json) to use as input.
    project_path : str
        Root directory of the project where the generated client should be integrated.
    generator_name : str
        Name of the OpenAPI Generator template to use.
        Please visit following link for more information about allowed values: https://github.com/OpenAPITools/openapi-generator-cli/blob/39c1bd6e0d49b0836c3db0a2995fb03bb87aded7/apps/generator-cli/src/config.schema.json#L89
    generator_options : dict[str, Any], optional
        Optional mapping of additional generator properties. Each key/value pair is formatted as
        "key=value" and passed to the generator via the CLI `-p` / `--additional-properties` flag.
        Example: {"npmName": "my-api-client", "modelSuffix": "Dto"}.
        If None or empty, no additional properties are passed.

    Returns
    -------
    None

    Raises
    ------
    FileNotFoundError
        If the OpenAPI spec file or the openapi-generator-cli executable cannot be found.
    subprocess.CalledProcessError
        If the openapi-generator-cli command returns a non-zero exit code.
    OSError
        If filesystem operations (creating/removing directories, moving files) fail.
    ValueError
        If generator_options contains keys or values that cannot be stringified for CLI use.

    Notes
    -----
    - The function creates a temporary directory named "temp_api_generation" inside `project_path`.
    That directory will be removed after the generated files are moved into the project.
    - Existing files in the destination may be overwritten when moving generated output; callers should back up important files or use version control to track changes.
    - This function depends on helper utilities available in the same module: get_local_command_path,
    run_command and __move_api_files. Ensure those helpers are present and behave as expected.
    """

    temp_output_dir = os.path.join(project_path, "temp_api_generation")
    if not os.path.exists(temp_output_dir):
        os.makedirs(temp_output_dir)

    openapi_generator_path = get_local_command_path("openapi-generator-cli")
    logging.info(f"Using openapi-generator-cli at: {openapi_generator_path}")
    command = [
        openapi_generator_path,
        "generate",
        "-i",
        openapi_file_path,
        "-g",
        generator_name,
        "-o",
        temp_output_dir,
    ]
    additional_properties = ",".join(
        [f"{key}={value}" for key, value in generator_options.items()]
    )
    if additional_properties:
        command.extend(["-p", additional_properties])

    run_command(command)

    __move_api_files(temp_output_dir, project_path)

    if os.path.exists(temp_output_dir):
        shutil.rmtree(temp_output_dir)


def __move_api_files(temp_output_dir, target_project_path):
    """Helper function to move generated files to their final location."""
    main_target_dir = os.path.join(target_project_path, "src", "app")
    folders_to_copy = ["api", "model"]
    files_to_ignore = [
        ".openapi-generator-ignore",  # Specifies files to exclude during OpenAPI code generation
        # Shell script (auto-generated) to automate Git operations
        "git_push.sh",
        # Defines how an Angular library should be built and packaged using ng-packagr.
        "ng-package.json",
        # Declares Node.js project metadata, dependencies, and scripts
        "package.json",
        "README.md",  # Markdown file for project documentation
        "tsconfig.json",  # Configures TypeScript compiler options
        ".gitignore",  # Lists files/folders Git should exclude from version control
        # Internal folder used by OpenAPI Generator to store metadata and track generation state.
        ".openapi-generator",
        ".travis.yml",  # CI/CD configuration
        "build.gradle",  # Gradle build file
        "build.sbt",  # Scala build file
        "pom.xml",  # Maven build file
        "requirements.txt",  # Python dependencies
        "setup.py",  # Python package setup
        "gradlew",  # Gradle wrapper script
        "gradlew.bat",  # Gradle wrapper for Windows
        "mvnw",  # Maven wrapper script
        "mvnw.cmd",  # Maven wrapper for Windows
        "Gemfile",  # Ruby dependencies
        "Cargo.toml",  # Rust package manifest
        ".npmignore",  # NPM ignore file
        "package-lock.json",  # NPM lock file
        "yarn.lock",  # Yarn lock file
        "composer.json",  # PHP dependencies
        ".swagger-codegen-ignore",  # Swagger codegen ignore file
        "api_test.go",  # Go test file
        ".php_cs",  # PHP CS Fixer config
        ".eslintrc",  # ESLint config
        "tslint.json",  # TSLint config}
    ]

    if not os.path.exists(main_target_dir):
        os.makedirs(main_target_dir)

    for folder in folders_to_copy:
        src_folder = os.path.join(temp_output_dir, folder)
        if os.path.exists(src_folder):
            shutil.move(src_folder, main_target_dir)

    for file in os.listdir(temp_output_dir):
        if file not in files_to_ignore:
            src_file = os.path.join(temp_output_dir, file)
            if os.path.exists(src_file):
                shutil.move(src_file, main_target_dir)
