import re


class MarkdownParser:
    def __init__(self, md_content: str):
        self.md_content = md_content

    def extract_sections(self, section_name: str) -> list:
        """
        Extracts all sections whose heading contains the given section_name (case-insensitive) and returns a list of their contents.
        Each section includes all its subsections, until a heading of the same or higher level is found. The search continues for all matches in the file.
        """
        lines = self.md_content.splitlines()
        section_pattern = re.compile(r"^(#{1,6})\s+(.*)$")
        all_sections = []
        section_name_lower = section_name.lower()
        i = 0
        n = len(lines)
        while i < n:
            match = section_pattern.match(lines[i])
            if match:
                heading_level = len(match.group(1))
                heading_text = match.group(2).strip()
                if section_name_lower in heading_text.lower():
                    # Start collecting this section
                    section_content = [lines[i].rstrip()]
                    i += 1
                    while i < n:
                        next_match = section_pattern.match(lines[i])
                        if next_match:
                            next_level = len(next_match.group(1))
                            if next_level <= heading_level:
                                break
                        section_content.append(lines[i].rstrip())
                        i += 1
                    content = "\n".join(section_content).strip()
                    if content:
                        all_sections.append(content)
                    continue  # Don't increment i again, already done in loop
            i += 1
        return all_sections
