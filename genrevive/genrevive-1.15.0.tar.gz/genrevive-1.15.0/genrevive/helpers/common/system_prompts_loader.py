import os
import logging
from genrevive.helpers.common.file_utils import FileUtils


def load_system_prompts_templates(role: str):
    """
    Load system, prompt, and response templates for a given agent role.
    """
    prefix = role.upper()  # e.g., "SE", "SR", "DE"
    keys = [f"{prefix}_SYSTEM_TEMPLATE_FILE", f"{prefix}_PROMPT_TEMPLATE_FILE"]
    values = [os.environ.get(k) for k in keys]

    # If all are empty, skip loading
    if not any(values):
        logging.info(f"No templates set for role: {role}. Skipping loading.")
        return None, None

    # If some are set but not all, raise error
    if any(values) and not all(values):
        raise ValueError(
            f"All system prompts template variables must be set for role: {role}"
        )

    system_template = FileUtils.read_file(values[0])
    prompt_template = FileUtils.read_file(values[1])

    return system_template, prompt_template
