import logging
import re


class ContentMinifier(object):
    @staticmethod
    def minify_content(content):
        """Minify markdown content by removing extra whitespace and HTML comments."""

        def minify_string(s):
            """Minify a single string by removing extra whitespace and HTML comments."""
            if s:
                logging.debug(f"Minifying string: {s}")
                s = re.sub(r"\s+", " ", s)
                s = re.sub(r"<!--(.*?)-->", "", s)
                s = re.sub(r" +", " ", s)
                s = s.strip()
            return s

        def minify_list(lst):
            """Minify a list by applying minify_string to each string element."""
            logging.debug(f"Minifying list: {lst}")
            minified_lst = [ContentMinifier.minify_content(item) for item in lst]
            return minified_lst

        def minify_dict(d):
            """Minify a dictionary by applying minify_string to each string value."""
            logging.debug(f"Minifying dictionary: {d}")
            minified_dict = {
                key: ContentMinifier.minify_content(value) for key, value in d.items()
            }
            return minified_dict

        if content is None:
            return None
        elif isinstance(content, str):
            return minify_string(content)
        elif isinstance(content, list):
            return minify_list(content)
        elif isinstance(content, dict):
            return minify_dict(content)
        else:
            logging.info(
                f"Unknown Type: not 'dict, list, str'. Converted {type(content)} to string: {content}"
            )
            return minify_string(str(content))
