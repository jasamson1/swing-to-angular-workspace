import os
import logging
from genrevive.core.embedding_configuration import get_embedding_configuration
from crewai.knowledge.source.text_file_knowledge_source import TextFileKnowledgeSource
from crewai.knowledge.source.pdf_knowledge_source import PDFKnowledgeSource
from crewai.knowledge.source.csv_knowledge_source import CSVKnowledgeSource
from crewai.knowledge.source.excel_knowledge_source import ExcelKnowledgeSource
from crewai.knowledge.source.json_knowledge_source import JSONKnowledgeSource

logger = logging.getLogger(__name__)

# Default chunking parameters
DEFAULT_CHUNK_SIZE = int(os.getenv("DEFAULT_CHUNK_SIZE", "800"))
DEFAULT_CHUNK_OVERLAP = int(os.getenv("DEFAULT_CHUNK_OVERLAP", "10"))

# Supported file extensions and their corresponding knowledge source classes
EXTENSION_MAP = {
    ".txt": TextFileKnowledgeSource,
    ".pdf": PDFKnowledgeSource,
    ".csv": CSVKnowledgeSource,
    ".xls": ExcelKnowledgeSource,
    ".xlsx": ExcelKnowledgeSource,
    ".json": JSONKnowledgeSource,
}


class KnowledgeFactory:
    @staticmethod
    def _load_source(
        file_name: str, embedder=None, chunk_size=None, chunk_overlap=None
    ):
        ext = os.path.splitext(file_name)[1].lower()
        source_class = EXTENSION_MAP.get(ext)
        if not source_class:
            logger.info(f"[KnowledgeFactory] Unsupported file type: {file_name}")
            return None
        # Use provided chunking or fallback to defaults
        chunk_size = chunk_size or DEFAULT_CHUNK_SIZE
        chunk_overlap = chunk_overlap or DEFAULT_CHUNK_OVERLAP

        kwargs = {
            "file_paths": [file_name],
            "chunk_size": chunk_size,
            "chunk_overlap": chunk_overlap,
        }
        if embedder:
            kwargs["embedder"] = embedder
        return source_class(**kwargs)

    @staticmethod
    def get_multiple_knowledge_from_env(
        env_var_name: str, enable_flag: str = None, embedder=None
    ):
        """
        Loads multiple knowledge sources from a comma-separated list in the environment variable.
        Respects the enable_flag just like get_knowledge_from_env.
        """
        if enable_flag and os.getenv(enable_flag, "false").lower() != "true":
            return []

        file_paths = os.getenv(env_var_name)
        if not file_paths:
            return []

        # Optional per-source chunking overrides
        chunk_size = int(os.getenv(f"{env_var_name}_CHUNK_SIZE", DEFAULT_CHUNK_SIZE))
        chunk_overlap = int(
            os.getenv(f"{env_var_name}_CHUNK_OVERLAP", DEFAULT_CHUNK_OVERLAP)
        )

        path_list = [p.strip() for p in file_paths.split(",") if p.strip()]
        sources = [
            KnowledgeFactory._load_source(
                path,
                embedder=embedder,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
            )
            for path in path_list
        ]
        return [s for s in sources if s]

    @staticmethod
    def get_crew_knowledge(embedder=None):
        enable_crew_knowledge = KnowledgeFactory._is_crew_knowledge_enabled()
        if not embedder:
            embedder = KnowledgeFactory.get_global_embedder_config()
        return KnowledgeFactory.get_multiple_knowledge_from_env(
            "CREW_KNOWLEDGE_PATH",
            enable_flag="true" if enable_crew_knowledge else "false",
            embedder=embedder,
        )

    @staticmethod
    def get_global_embedder_config():
        knowledge_embedder = None
        enable_crew_knowledge = KnowledgeFactory._is_crew_knowledge_enabled()
        if enable_crew_knowledge:
            knowledge_embedder = get_embedding_configuration("knowledge_embedder")

        return knowledge_embedder

    @staticmethod
    def _is_crew_knowledge_enabled() -> bool:
        enable_se = os.getenv("ENABLE_SE_KNOWLEDGE", "false").lower() == "true"
        enable_sr = os.getenv("ENABLE_SR_KNOWLEDGE", "false").lower() == "true"
        enable_devops = os.getenv("ENABLE_DEVOPS_KNOWLEDGE", "false").lower() == "true"
        return enable_se or enable_sr or enable_devops
