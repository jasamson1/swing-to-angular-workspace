import os


def get_merged_tools_for_agent_type(mcp_tools, tools, agent_type: str):
    """
    Returns tools for the given agent type (SE, SR, DE) by filtering self.mcp_tools
    using the corresponding environment variable.
    Optionally merges with extra_tools.
    """
    env_key = f"DEFAULT_TOOLS_FOR_{agent_type.upper()}"
    tool_names = os.getenv(env_key, "")
    tool_names = [name.strip() for name in tool_names.split(",") if name.strip()]

    available_tool_names = {getattr(tool, "name", None) for tool in mcp_tools}
    missing_tools = [name for name in tool_names if name not in available_tool_names]

    if missing_tools:
        raise ValueError(
            f"The following tools specified for agent type '{agent_type}' were not found: {', '.join(missing_tools)}. "
            f"Please check the environment variable '{env_key}' and ensure all tool names are valid."
        )

    filtered_mcp_tools = [
        tool for tool in mcp_tools if getattr(tool, "name", None) in tool_names
    ]

    return merge_tools(filtered_mcp_tools, tools)


def get_merged_tools_for_task_type(mcp_tools, tools, task_type: str):
    """
    Returns merged tools for the given task type by filtering mcp_tools
    using the environment variable <TASK_TYPE>_DEFAULT_TOOLS and merging with tools.
    """
    env_key = f"{task_type.upper()}_DEFAULT_TOOLS"
    tool_names = os.getenv(env_key, "")
    tool_names = [name.strip() for name in tool_names.split(",") if name.strip()]

    available_tool_names = {getattr(tool, "name", None) for tool in mcp_tools}
    missing_tools = [name for name in tool_names if name not in available_tool_names]

    if missing_tools:
        raise ValueError(
            f"The following tools specified for task type '{task_type}' were not found: {', '.join(missing_tools)}. "
            f"Please check the environment variable '{env_key}' and ensure all tool names are valid."
        )

    filtered_mcp_tools = [
        tool for tool in mcp_tools if getattr(tool, "name", None) in tool_names
    ]

    return merge_tools(filtered_mcp_tools, tools)


def merge_tools(mcp_tools, tools):
    """
    If mcp_tools is empty, return tools.
    Otherwise, add all mcp_tools to tools (avoiding duplicates by tool name).
    """

    if not mcp_tools:
        return tools or []

    tools = tools or []
    tool_names = {tool.name for tool in tools}
    merged = tools + [tool for tool in mcp_tools if tool.name not in tool_names]
    return merged


def get_tool_by_name(tools, name):
    """
    Returns the tool object from the list that matches the given name.

    Args:
        tools (list): A list of tool objects, each expected to have a 'name' attribute.
        name (str): The name of the tool to retrieve.

    Returns:
        object or None: The matching tool object, or None if not found.
    """
    tool = next((tool for tool in tools if getattr(tool, "name", None) == name), None)
    if tool is None:
        raise ValueError(
            f"Tool with name '{name}' was not found in the provided tools list. "
            "Please check the MCP server connection or the tool name specified."
        )

    return tool
