import logging
import os

from genrevive.helpers.common.shell_utils import run_command, get_local_command_path


def create_angular_component(
    project_directory: os.PathLike[str],
    component_name: str,
    angular_version: str = None,
    standalone: bool = False,
):
    """
    Creates a new Angular component within an existing Angular project.

    This method uses the Angular CLI via `npx` to generate a component inside the `components/` directory
    of the specified Angular project. It supports both traditional NgModule-based components and
    modern standalone components. Using `npx` ensures the specified Angular CLI version is used
    regardless of what's locally installed.

    Args:
        project_directory (os.PathLike[str]): The root directory of the Angular project.
        component_name (str): The name of the component to create.
        angular_version (str, optional): The version of Angular CLI to use for component generation.
            If not provided, defaults to '16'.
        standalone (bool, optional): If True, generates a standalone component using the
            `--standalone` flag. If False, the component is registered with the `app.module.ts`
            using the `--module=app` flag. Defaults to False.

    Notes:
        - For standalone components, Angular CLI will not modify `app.module.ts`.
        - This function assumes that `npx` is available in the system path.
        - The specified Angular CLI version will be downloaded if not already cached by npx.

    Returns:
        None
    """
    full_path = os.path.join(project_directory)
    if not os.path.exists(full_path):
        logging.error(f"Project directory does not exist: {full_path}")
        return

    original_path = os.getcwd()  # Store the original path before changing directory
    os.chdir(project_directory)  # Change to the Angular project directory
    logging.info(
        f"Attempting to create Angular component '{component_name}' in: {full_path}"
    )

    npx_path = get_local_command_path("npx")
    logging.info(f"Using npx at: {npx_path}")

    component_name = os.path.join("components", component_name)

    ng_version = "16" if not angular_version else angular_version

    # Build the command based on the standalone flag
    if standalone:
        command = [
            npx_path,
            "-p",
            "@angular/cli@" + ng_version,
            "ng",
            "generate",
            "component",
            component_name,
            "--standalone",
        ]
    else:
        command = [
            npx_path,
            "-p",
            "@angular/cli@" + ng_version,
            "ng",
            "generate",
            "component",
            component_name,
            "--module=app",
            "--standalone=false",
        ]

    # Run the command
    run_command(command)
    # Restore the original directory after tasks
    os.chdir(original_path)
