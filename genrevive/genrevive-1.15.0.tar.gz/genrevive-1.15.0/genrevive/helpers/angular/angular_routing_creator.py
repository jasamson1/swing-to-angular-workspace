import logging
import os

from caseconverter import kebabcase, pascalcase

from genrevive.helpers.common.shell_utils import run_command, get_local_command_path


class AngularRoutingCreator:
    def __init__(self, angular_project_path) -> None:
        self.angular_project_path = angular_project_path

    def create_app_routing_module(self):
        """
        Creates an Angular `app-routing` module within the specified Angular project directory.

        This method uses the Angular CLI (`ng generate module`) to create a flat `app-routing` module
        and automatically imports it into the main `app.module.ts` file. It assumes the project follows
        the traditional NgModule-based structure and will not work with Angular standalone component architecture.

        Steps performed:
        1. Verifies the existence of the Angular project directory.
        2. Changes the working directory to the Angular project path.
        3. Locates the local Angular CLI (`ng`) executable.
        4. Executes the command to generate the `app-routing` module.
        5. Restores the original working directory.

        Note:
            - This method is specifically designed for Angular projects using NgModules.
            - It is not compatible with Angular standalone component architecture.
            - This method is not required if the Angular project was created with the `--routing=true` flag,
            as the routing module will already be generated

        Returns:
            None
        """
        full_path = os.path.join(self.angular_project_path)
        if not os.path.exists(full_path):
            logging.error(f"Project directory does not exist: {full_path}")
            return

        original_path = os.getcwd()  # Store the original path before changing directory
        os.chdir(self.angular_project_path)  # Change to the Angular project directory
        logging.info(f"Creating app-routing module in: {full_path}")

        ng_path = get_local_command_path("ng")
        logging.info(f"Using ng at: {ng_path}")

        # Define the command to generate the app-routing module
        command = [
            ng_path,
            "generate",
            "module",
            "app-routing",
            "--flat",
            "--module=app",
        ]
        # Run the command
        run_command(command)
        # Restore the original directory after tasks
        os.chdir(original_path)

    def adapt_app_routing_module(self, components: list):
        """
        Updates or creates Angular routing configuration based on the project structure.

        - If `app-routing.module.ts` or `app-routing-module.ts` exists, it overwrites it with a full routing module.
        - If not, but `app.routes.ts` exists, it appends route definitions and imports to it.
        - This supports both NgModule-based and standalone routing setups.

        Args:
            components (list): List of component names to be added to the routing.
        """
        output_dir = os.path.join(self.angular_project_path, "src", "app")
        routing_module_path = os.path.join(output_dir, "app-routing.module.ts")
        routing_module_alt_path = os.path.join(output_dir, "app-routing-module.ts")
        standalone_routes_path = os.path.join(output_dir, "app.routes.ts")

        # Determine which routing module file exists (if any)
        routing_file = None
        if os.path.exists(routing_module_path):
            routing_file = routing_module_path
        elif os.path.exists(routing_module_alt_path):
            routing_file = routing_module_alt_path

        # Prepare the import statements and routes array
        imports = ""
        routes = ""
        component_path = ""
        for component in components:
            component_name = pascalcase(component) + "Component"
            component_path = kebabcase(component)
            imports += f"import {{ {component_name} }} from './components/{component_path}/{component_path}.component';\n"
            routes += (
                f"  {{ path: '{component_path}', component: {component_name} }},\n"
            )

        # Default and wildcard routes redirect to the last component in the list
        default_route = component_path

        # Combine everything into the routing module content
        if routing_file:
            # Use NgModule-based routing logic for both naming conventions
            logging.info(f"Detected NgModule-based routing. Updating: {routing_file}")
            routing_module_content = f"""
                import {{ NgModule }} from '@angular/core';
                import {{ RouterModule, Routes }} from '@angular/router';
                import {{ HttpClientModule }} from '@angular/common/http';
                import {{ ApiModule }} from './api.module';
                import {{ Configuration }} from './configuration';
                {imports}
                const routes: Routes = [
                    {routes}  
                    {{ path: '', redirectTo: '/{default_route}', pathMatch: 'full' }},
                    {{ path: '**', redirectTo: '/{default_route}', pathMatch: 'full' }}
                ];

                @NgModule({{
                    imports: [RouterModule.forRoot(routes, {{}}), HttpClientModule, ApiModule.forRoot(() => new Configuration())],
                    exports: [RouterModule]
                }})
                export class AppRoutingModule {{ }}
            """
            # Write the generated content to the routing module file
            with open(routing_file, "w") as file:
                routing_module_content = "\n".join(
                    line.lstrip() for line in routing_module_content.splitlines()
                )
                file.write(routing_module_content)

            logging.info(f"Updated {os.path.basename(routing_file)} with new routes.")

        elif os.path.exists(standalone_routes_path):
            # Use standalone routing logic
            logging.info(
                f"Detected standalone routing. Updating: {standalone_routes_path}"
            )
            standalone_routes_content = f"""
                import {{ Routes }} from '@angular/router';
                {imports}
                export const routes: Routes = [
                    {routes}
                    {{ path: '', redirectTo: '{default_route}', pathMatch: 'full' }},
                    {{ path: '**', redirectTo: '{default_route}', pathMatch: 'full' }}
                ];
            """
            # Write the generated content to app.routes.ts
            with open(standalone_routes_path, "w") as file:
                standalone_routes_content = "\n".join(
                    line.lstrip() for line in standalone_routes_content.splitlines()
                )
                file.write(standalone_routes_content)
            logging.info(f"Updated {standalone_routes_path} with new routes.")

        else:
            logging.error(
                "Neither NgModule routing files (app-routing.module.ts/app-routing-module.ts) nor app.routes.ts found. Cannot update routing."
            )
