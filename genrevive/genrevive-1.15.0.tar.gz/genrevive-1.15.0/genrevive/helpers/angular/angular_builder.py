import logging
import os
import re
import docker
from dotenv import load_dotenv

from genrevive.helpers.common.shell_utils import (
    get_local_command_path,
    run_build_process,
)


class AngularBuilder:
    """Class to build an Angular application either in a Docker container or locally."""

    def __init__(self, angular_version: str = None):
        load_dotenv()

        self.angular_project_path = os.environ["ANGULAR_PROJECT_PATH"]
        self.node_modules_path = os.environ["NODE_MODULES_PATH"]
        self.angular_version = self._normalize_version(angular_version)
        self.client = docker.from_env() if not self.use_local_ng() else None
        self.container = None

    def _normalize_version(self, version: str) -> str:
        """Extracts the major version number from a version string like '16.2.4' or '18.x.x'."""
        if version is None:
            return "16"
        match = re.match(r"(\d+)", version)
        return match.group(1) if match else "16"

    def get_node_image(self) -> str:
        """
        Get the appropriate Node.js Docker image based on the Angular version.

        Maps Angular versions to compatible Node.js Docker images:
        - Angular 16-19: Uses node:18-alpine
        - Angular 20: Uses node:20-alpine
        - Default fallback: node:18-alpine for unknown versions

        Returns:
            str: The Docker image name (e.g., "node:18-alpine", "node:20-alpine")
        """
        version_map = {
            "16": "node:18-alpine",
            "17": "node:18-alpine",
            "18": "node:18-alpine",
            "19": "node:18-alpine",
            "20": "node:20-alpine",
        }
        return version_map.get(self.angular_version, "node:18-alpine")

    def stop_and_remove_container(self):
        """Stops and removes the current Docker container."""
        if self.container:
            logging.info("Stopping and removing existing container...")
            self.container.stop()
            self.container.remove()

    @staticmethod
    def use_local_ng():
        """Check if local Angular CLI should be used based on environment flag."""
        return os.getenv("USE_LOCAL_NPM", "false").lower() == "true"

    def create_and_start_container(self) -> docker.models.containers.Container:
        """Creates and starts a Docker container for the Angular build."""
        build_command = "npm run build"
        node_image = self.get_node_image()
        logging.info(f"Using image: {node_image}")
        container_config = {
            "image": node_image,
            "volumes": {
                os.path.abspath(self.angular_project_path): {
                    "bind": "/angular",
                    "mode": "rw",
                },
                os.path.abspath(self.node_modules_path): {
                    "bind": "/angular/node_modules",
                    "mode": "rw",
                },
            },
            "working_dir": "/angular",
            "command": f"/bin/sh -c '{build_command}'",
            "detach": True,
            "stdout": True,
            "stderr": True,
        }
        logging.info("Starting Docker container with config: %s", container_config)
        try:
            self.container = self.client.containers.run(**container_config)
        except docker.errors.DockerException as e:
            logging.error("Failed to start Docker container: %s", e)
        return self.container

    def execute_local_build(self) -> dict:
        """Execute Angular build locally."""
        npm_path = get_local_command_path("npm")
        build_command = [npm_path, "run", "build"]
        return run_build_process(build_command, cwd=self.angular_project_path)

    def execute_build(self) -> dict:
        """Executes the build either locally or in a Docker container based on the environment flag."""
        if self.use_local_ng():
            return self.execute_local_build()
        else:
            self.create_and_start_container()
            log_statements = ""
            build_success = False

            for line in self.container.logs(stream=True, follow=True):
                line = line.decode("utf-8").strip()
                if line.startswith("-") or line.startswith(">"):
                    logging.info(line)
                    continue
                elif line.startswith("npm"):
                    continue
                elif line.startswith("Error"):
                    logging.error(line)
                    # log_statements += line + "\n"
                if "Build at" in line:
                    build_success = True
                log_statements += line + "\n"

            result = self.container.wait()
            exit_code = result["StatusCode"]

            # Ensure build_success is true only if the exit_code is 0 and "Build at" is found
            build_success = build_success and exit_code == 0

            logging.info(f"Build result: {'success' if build_success else 'failure'}")
            return {"success": build_success, "description": log_statements}

    def close_container(self):
        """Stops and removes the Docker container and closes the Docker client, if used."""
        if self.container:
            self.stop_and_remove_container()
        if self.client:
            self.client.close()
