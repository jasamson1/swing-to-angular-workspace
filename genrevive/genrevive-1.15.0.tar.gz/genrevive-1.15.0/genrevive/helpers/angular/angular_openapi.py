import logging
import os

from genrevive.helpers.common.openapi.generator import generate_api_client
from typing_extensions import deprecated


@deprecated(
    "generate_client is deprecated and will be removed in a future release. "
    "Use generate_api_client(..., generator_name=...) instead."
)
def generate_client(
    openapi_file_path: str, angular_project_path: str, generator_options=None
):
    """
    Deprecated wrapper for backwards compatibility. Calls generate_api_client
    with the default generator name 'typescript-angular'.

    Keep this function to avoid breaking existing callers. New code should call
    `generate_api_client` and pass `generator_name` explicitly.
    """
    return generate_api_client(
        openapi_file_path, angular_project_path, "typescript-angular", generator_options
    )


def add_http_client_module(angular_project_path: str):
    """
    Adds HTTP client support to an Angular project by modifying either:
    - `app.module.ts` or `app-module.ts` (for NgModule-based apps), or
    - `app.config.ts` (for standalone apps).

    Usually called after generating an OpenAPI client for Angular. This function automatically
    detects the project type and applies the appropriate HTTP client configuration.

    For NgModule-based apps (app.module.ts or app-module.ts):
        - Adds `HttpClientModule` import from '@angular/common/http' after the last existing import.
        - Inserts `HttpClientModule` into the imports array in the @NgModule decorator.

    For standalone apps (app.config.ts):
        - Adds `provideHttpClient()` import from '@angular/common/http'.
        - Inserts `provideHttpClient()` into the providers array in the app config.

    Note: Only use this function if your Angular project structure follows standard conventions
    with either module files (app.module.ts/app-module.ts) or config files (app.config.ts).

    Args:
        angular_project_path (str): The root directory path of the Angular project where
            app.module.ts, app-module.ts, or app.config.ts is located.

    Returns:
        None
    """
    # Check for NgModule files (both naming conventions)
    app_module_file_path = os.path.join(
        angular_project_path, "src", "app", "app.module.ts"
    )
    app_module_alt_path = os.path.join(
        angular_project_path, "src", "app", "app-module.ts"
    )
    app_config_file_path = os.path.join(
        angular_project_path, "src", "app", "app.config.ts"
    )

    # Determine which NgModule file exists (if any)
    ngmodule_file = None
    if os.path.exists(app_module_file_path):
        ngmodule_file = app_module_file_path
    elif os.path.exists(app_module_alt_path):
        ngmodule_file = app_module_alt_path

    if ngmodule_file:
        logging.info(f"Detected NgModule-based app. Modifying: {ngmodule_file}")
        with open(ngmodule_file, "r") as f:
            lines = f.readlines()

        # Check if HttpClientModule is already imported
        if any("HttpClientModule" in line for line in lines):
            logging.info("HttpClientModule is already imported, skipping modification")
            return

        # Insert HttpClientModule import
        last_import_index = max(
            i for i, line in enumerate(lines) if line.startswith("import ")
        )
        lines.insert(
            last_import_index + 1,
            "import { HttpClientModule } from '@angular/common/http';\n",
        )

        # Insert into imports array
        start_index = end_index = None
        for i, line in enumerate(lines):
            if "imports:" in line and "[" in line:
                start_index = i + 1
            if start_index and "]" in line:
                end_index = i
                break

        if start_index and end_index:
            lines = (
                lines[:start_index] + ["    HttpClientModule,\n"] + lines[start_index:]
            )
            with open(ngmodule_file, "w") as f:
                f.writelines(lines)
            logging.info(
                f"Successfully added HttpClientModule to {os.path.basename(ngmodule_file)}"
            )
        else:
            logging.error(
                f"Failed to find the imports array in {os.path.basename(ngmodule_file)}"
            )

    elif os.path.exists(app_config_file_path):
        logging.info(f"Detected standalone app. Modifying: {app_config_file_path}")
        with open(app_config_file_path, "r") as f:
            lines = f.readlines()

        # Insert provideHttpClient import if not present
        if "provideHttpClient" not in "".join(lines):
            last_import_index = max(
                i for i, line in enumerate(lines) if line.startswith("import ")
            )
            lines.insert(
                last_import_index + 1,
                "import { provideHttpClient } from '@angular/common/http';\n",
            )

        # Find and modify providers array
        for i, line in enumerate(lines):
            if "providers:" in line and "[" in line:
                if "]" in line:
                    # Single-line providers array
                    if "provideHttpClient()" not in line:
                        start = line.find("[") + 1
                        end = line.find("]")
                        existing = line[start:end].strip()
                        if existing:
                            new_providers = f"[provideHttpClient(), {existing}]"
                        else:
                            new_providers = "[provideHttpClient()]"
                        lines[i] = (
                            line[: line.find("[")] + new_providers + line[end + 1 :]
                        )
                else:
                    # Multi-line providers array
                    # Insert provideHttpClient() on the next line if not already present
                    j = i + 1
                    while j < len(lines) and "]" not in lines[j]:
                        if "provideHttpClient()" in lines[j]:
                            break
                        j += 1
                    else:
                        lines.insert(i + 1, "    provideHttpClient(),\n")

        with open(app_config_file_path, "w") as f:
            f.writelines(lines)
        logging.info("provideHttpClient() added to app.config.ts")

    else:
        logging.warning(
            "Neither NgModule files (app.module.ts/app-module.ts) nor app.config.ts found in the project."
        )
