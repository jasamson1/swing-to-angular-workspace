import logging
import os

from genrevive.helpers.common.shell_utils import run_command, get_local_command_path


def create_angular_project(
    project_directory: os.PathLike[str],
    angular_app_name,
    angular_version: str = None,
    standalone: bool = False,
    routing: bool = False,
    arg="",
):
    """
    Initializes a new Angular project using the Angular CLI via `npx`.

    This function sets up a new Angular application in the specified directory. It supports customization
    of Angular version, routing, and standalone component structure. It also allows passing additional
    CLI arguments for advanced configuration.

    Parameters:
    ----------
    project_directory : os.PathLike[str]
        The path to the directory where the Angular project should be created.

    angular_app_name : str
        The name of the Angular application to be created.

    angular_version : str, optional
        The version of Angular CLI to use. Defaults to version '16' if not specified.

    standalone : bool, default=False
        Whether to use standalone components. True enables standalone components, False uses traditional NgModule structure.

    routing : bool, default=False
        Whether to include Angular routing in the project. True enables routing, False creates project without routing.

    arg : str, optional
        Any additional argument to be appended to the Angular CLI command.

    Notes:
    -----
    - This function assumes that `npx` is available in the system path.
    - It uses `--skip-install` and `--skip-git` flags to avoid installing dependencies or initializing Git.
    - The project is created with SCSS styling by default.

    Returns:
    - None
    """

    # Search for the full path of `npx`
    full_path = os.path.join(project_directory, angular_app_name)
    if os.path.exists(full_path) and os.listdir(full_path):
        logging.error(f"Directory not empty, cannot create project: {full_path}")
        return

    original_path = os.getcwd()  # Store the original path before changing directory
    os.chdir(project_directory)  # Change to the desired directory
    logging.info(f"Attempting to create Angular project at: {full_path}")

    npx_path = get_local_command_path("npx")
    logging.info(f"Using npx at: {npx_path}")

    ng_version = "16" if not angular_version else angular_version
    # Define the command to create an Angular project
    command = [
        npx_path,
        "-p",
        "@angular/cli@" + ng_version,
        "--yes",
        "ng",
        "new",
        angular_app_name,
        "--skip-install",
        "--skip-git",
        "--style=scss",
        "--routing=" + str(routing).lower(),
        "--standalone=" + str(standalone).lower(),
    ]
    arg and command.append(arg)

    # Run the command
    run_command(command)
    # Restore the original directory after tasks
    os.chdir(original_path)


def init_app_component(angular_project_path):
    """
    Initializes the main app template file with a basic Angular router outlet.

    This method looks for and updates either:
    - `app.component.html` (standard Angular component template), or
    - `app.html` (alternative naming convention)

    The file will be located at:
        <angular_project_path>/src/app/app.component.html
        <angular_project_path>/src/app/app.html

    It writes the following default content:
        <router-outlet></router-outlet>

    This setup is essential for enabling Angular's routing mechanism to render routed components.

    Note:
        This method is **not required** if the Angular project (NgModule/Standalone) was created with the `--routing=true` flag,
        as Angular CLI automatically sets up the `router-outlet` in that case.

    Args:
        angular_project_path (str): The root path of the Angular project.
    """
    # Check for both possible template file locations
    app_component_html_path = os.path.join(
        angular_project_path, "src", "app", "app.component.html"
    )
    app_html_path = os.path.join(angular_project_path, "src", "app", "app.html")

    target_file = None
    if os.path.exists(app_component_html_path):
        target_file = app_component_html_path
        logging.info(f"Found app.component.html, updating: {target_file}")
    elif os.path.exists(app_html_path):
        target_file = app_html_path
        logging.info(f"Found app.html, updating: {target_file}")
    else:
        # Default to app.component.html if neither exists
        target_file = app_component_html_path
        logging.info(f"No existing template found, creating: {target_file}")

    # Create or overwrite the template file
    with open(target_file, "w") as file:
        file.write("<router-outlet></router-outlet>")


def add_reactive_forms_module(angular_project_path):
    """
    Adds `ReactiveFormsModule` to the Angular NgModule configuration.

    This method looks for and updates either:
    - `app.module.ts` (standard Angular module file), or
    - `app-module.ts` (alternative naming convention)

    This method:
    - Inserts the import statement for `ReactiveFormsModule` from `@angular/forms`.
    - Adds `ReactiveFormsModule` to the `imports` array of the `@NgModule` decorator.

    This enables reactive forms support across the Angular application.

    ⚠️ Note:
        This method only works for Angular projects using the **NgModule** architecture.
        It does not apply to projects using **standalone components**.
        This method assumes the presence of a valid module file (app.module.ts or app-module.ts).

    Args:
        angular_project_path (str): The root path of the Angular project.
    """
    # Check for both possible module file locations
    app_module_file_path = os.path.join(
        angular_project_path, "src", "app", "app.module.ts"
    )
    app_module_alt_path = os.path.join(
        angular_project_path, "src", "app", "app-module.ts"
    )

    target_file = None
    if os.path.exists(app_module_file_path):
        target_file = app_module_file_path
        logging.info(f"Found app.module.ts, updating: {target_file}")
    elif os.path.exists(app_module_alt_path):
        target_file = app_module_alt_path
        logging.info(f"Found app-module.ts, updating: {target_file}")
    else:
        logging.error(
            f"Neither app.module.ts nor app-module.ts found in {angular_project_path}/src/app/"
        )
        return

    logging.info(f"Starting to adapt the Angular module: {target_file}")

    # Read the existing module file
    with open(target_file, "r") as f:
        lines = f.readlines()

    # Check if ReactiveFormsModule is already imported
    if any("ReactiveFormsModule" in line for line in lines):
        logging.info("ReactiveFormsModule is already imported, skipping modification")
        return

    # Find the last import statement
    last_import_index = None
    for i, line in enumerate(lines):
        if line.startswith("import "):
            last_import_index = i

    # Add import of ReactiveFormsModule at the end of imports
    if last_import_index is not None:
        lines.insert(
            last_import_index + 1,
            "import { ReactiveFormsModule } from '@angular/forms';\n",
        )
    else:
        lines.insert(0, "import { ReactiveFormsModule } from '@angular/forms';\n")

    # Find the imports array
    start_index = None
    end_index = None
    for i, line in enumerate(lines):
        if "imports:" in line and "[" in line:
            start_index = i + 1
        if start_index and "]" in line:
            end_index = i
            break

    # Insert the ReactiveFormsModule into the imports array
    if start_index and end_index:
        lines = (
            lines[:start_index] + ["    ReactiveFormsModule,\n"] + lines[start_index:]
        )
        with open(target_file, "w") as f:
            f.writelines(lines)
        logging.info(f"Successfully adapted the Angular module: {target_file}")
    else:
        logging.error(f"Failed to find the imports array in {target_file}")
