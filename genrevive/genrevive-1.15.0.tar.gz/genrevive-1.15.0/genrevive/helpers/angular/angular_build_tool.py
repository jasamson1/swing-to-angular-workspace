from crewai.tools import BaseTool

from genrevive.helpers.angular.angular_builder import AngularBuilder


class AngularBuildTool(BaseTool):
    name: str = "angular_build_tool"
    description: str = """
        This tool checks if given Angular code is functional.
        It accepts the file_path along with its contents (the Angular code) as input.
        If it's functional, return True, otherwise return the error message.
    """

    def __init__(self, angular_version: str = None, **kwargs):
        super().__init__(**kwargs)
        self._angular_version = angular_version

    def _run(
        self, file_path: str, html_code: str, ts_code: str, scss_code: str
    ) -> dict[bool, str]:
        angular_builder = AngularBuilder(angular_version=self._angular_version)
        build_result = angular_builder.execute_build()
        return build_result


def angular_build_tool(cache_success_only: bool, angular_version: str = None):
    # Default to version "16" if None is provided
    ng_version = angular_version or "16"
    tool = AngularBuildTool(angular_version=ng_version)
    if cache_success_only:
        tool.cache_function = cache_success
    return tool


def cache_success(args, result):
    cache = result["success"]
    return cache
