## Angular Helpers

The Angular helpers are reusable utilities that can be integrated across different migration scenarios where the target technology is Angular, supporting modern Angular development workflows and architectures.

## Supported Angular Versions

The Angular helpers support **Angular versions 16 to 20**, providing compatibility with both:

- **NgModule-based projects** (traditional Angular architecture)
- **Standalone components** (modern Angular architecture)

## Configuration Options when using Angular helpers

### Project Creation
Create new Angular projects with customizable version selection and architecture flags. Specify the Angular CLI version and configure standalone components and routing options according to your migration requirements.

When creating Angular project, you have the following options:

- **`angular_version`** (string):
  - Specify the Angular CLI version to use (e.g., "16.x.x", "17.x.x", "18.x.x", "19.x.x", "20.x.x")
  - Defaults to "16" if not specified

- **`standalone`** (boolean): 
  - `true`: Creates a project using standalone components (modern approach)
  - `false`: Creates a traditional NgModule-based project (default)

- **`routing`** (boolean):
  - `true`: Includes Angular Router setup with routing configuration
  - `false`: Creates project without routing (default)

```python
# Example
angular_project_creator.create_angular_project(
    project_directory="/path/to/projects",
    angular_app_name="my-modern-app",
    angular_version="18",
    standalone=True,
    routing=True,
    arg=""
)
```

### Component Generation
Generate Angular components with version-specific CLI and architecture configuration. Choose the Angular CLI version and set the standalone flag to match your project's component structure.

- **`angular_version`** (string):
  - Specify the Angular CLI version to use (e.g., "16.x.x", "17.x.x", "18.x.x", "19.x.x", "20.x.x")
  - Defaults to "16" if not specified

- **`standalone`** (boolean): 
  - `true`: Creates a project using standalone components (modern approach)
  - `false`: Creates a traditional NgModule-based project (default)

```python
# Example
angular_component_creator.create_angular_component(
    project_directory="/path/to/projects/my-modern-app",
    component_name="user-profile",
    angular_version="18",
    standalone=True
)
```
### Angular Builder Tool
Configure and use the Angular build tool with customizable version selection. You can specify the Angular CLI version to use for build operations, with the tool defaulting to version "16" if no version is provided.

- **`angular_version`** (string, optional):
  - Specify the Angular CLI version to use for build operations
  - Defaults to "16" if not specified

```python
# Example
angular_build_tool = angular_build_tool(
    cache_success_only=True,
    angular_version="18"
)
```

### Additional Utilities
There are several other helper methods available in the Angular helpers library. Some of these utilities are specific to NgModule-based projects, while others are compatible with both NgModule and standalone component architectures.