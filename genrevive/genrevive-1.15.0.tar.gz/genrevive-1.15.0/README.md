# GenRevive

GenRevive offers GenAI assisted migration of software projects.

There are three categories:

* **GenRevive Core**: a flexible, technologically agnostic GenAI multi-agent transformation core (this repository)
* **GenRevive Helpers**: Non-AI utilities that can be reused in several migration scenarios (this repository)
* **GenRevive Migrators**: separate runnable software (projects) that use the GenRevive (core & helpers) as a library to migrate software projects (separate repositories)

The core can not be executed as a standalone application. It is used by each migrator as a library.
A migrator provides activities, prompts and cookbooks for a specific migration scenario from an origin to a target.

A [GenRevive Migrator Template](https://github2.capgemini.com/Capgemini-Innersource/Global.CCA-AppsModernization-GenRevive-Migrator-Template) repository is provided to create a new migrator.

You find further architecture documentation [here](docs/genrevive_arc42_documentation.md) as part of this repository.

This readme provides an overview of the technical project setup. This is relevant if you want to maintain GenRevive (core & helpers).

If you want to run a specific migration, see the respective migrator repository.
If you want to create a new migrator, see [GenRevive Migrator Template](https://github2.capgemini.com/Capgemini-Innersource/Global.CCA-AppsModernization-GenRevive-Migrator-Template) repository.

## Table of Contents

- [Project Setup Guide](#project-setup-guide)
- [Additional tools](#additional-tools)
  - [Langfuse](#langfuse)
  - [Use of MCP Tools in GenRevive](#use-of-mcp-tools-in-genrevive)
  - [Angular helpers](#angular-helpers)
  - [Integration tests](#integration-tests)
  - [Notes](#notes)
- [Contributing to GenRevive](#contributing-to-genrevive)
  - [Access Requirements](#access-requirements)
  - [How to Contribute via Merge Requests](#how-to-contribute-via-merge-requests)
  - [How to Contribute by Creating Issues](#how-to-contribute-by-creating-issues)

# Project Setup Guide

This guide will help you set up your Python project on both Windows and macOS. We will cover the following steps:

1. [Installing Python 3.13](#1-installing-python-313)
2. [Installing Visual Studio Build Tools](#2-installing-visual-studio-build-tools)
3. [Setting up a virtual environment](#3-setting-up-a-virtual-environment)
4. [Installing and configuring Poetry](#4-installing-and-configuring-poetry)
5. [Integrating the project with PyCharm CE (optional)](#5-integrating-with-pycharm-ce-optional)
6. [Building GenRevive](#6-building-genrevive)
7. [Running tests](#7-running-tests)
8. [Enabling Long Path Support in Windows 10](#9-enabling-long-path-support-in-windows-10)


## 1. Installing Python 3.13

### Windows

1. Download the Python 3.13 installer from the [official website](https://www.python.org/downloads/release/python-3132/).
2. Run the installer and ensure you check the box that says "Add Python to PATH."
3. Follow the installation instructions.
4. Verify that the correct Python Version is actually used:
    * On Windows, using PowerShell:

        ```PowerShell
        python --version
        py --version
        ```

    If you see a different Python Version, you should check:

    * Environment Variables
            Action: Move the folder containing your desired python.exe earlier in PATH, or remove conflicting entries if you no longer need them.
    * App Execution Aliases (Microsoft Store)
            Settings → Apps → App execution aliases
            Toggle Off for python.exe and python3.exe if you don’t want Store aliases to intercept calls.

    Consider going through this (safe and reversible)
    [Clean-up plan](#cleanup-plan):

#### Cleanup Plan

##### 1. Uninstall unused Python distributions

Settings → Apps → Installed apps: remove old CPython, Anaconda/Miniconda, MSYS2 Python, WinPython.

```PowerShell
pyenv uninstall <version>
```

or

```PowerShell
remove pyenv‑win
```

##### 2. Disable Store aliases

Settings → Apps → App execution aliases: toggle Off for python.exe and python3.exe.

##### 3. Fix PATH order

Put your desired CPython’s folder (e.g., C:\Python312\ or C:\Users\<you>\AppData\Local\Programs\Python\Python312\) before any shim folders.

Keep …\Scripts after the core folder for pip/tooling.
Remove stale paths pointing to uninstalled interpreters.

##### 4. Remove shell aliases

Edit $PROFILE and delete any Set-Alias python … or functions.
Restart PowerShell.

##### 5. Verify resolution again

   ```PowerShell
   python --version
   py -0p
   ```

### macOS

1. Download the Python 3.13 installer from
   the [official website](https://www.python.org/downloads/release/python-3132/).
2. Open the downloaded `.pkg` file and follow the installation instructions.
3. Verify the installation by running the following command in Terminal:

    ```bash
    python --version
    ```
   It should display `Python 3.13.x`.

## 2. Installing Visual Studio Build Tools

1. Download the `Visual Studio Installer`from the [official website](https://visualstudio.microsoft.com/downloads/).
2. Start the downloaded `.exe` file and follow the installation instructions.
3. You need to install only the `Desktop development with C++` package.

## 3. Setting up a Virtual Environment

### Windows & macOS

1. Open your terminal (Command Prompt or PowerShell on Windows, Terminal on macOS).
2. Navigate to your GenRevive project directory:

    ```bash
    cd path/to/your/project
    ```

3. Create a virtual environment:

    ```bash
    py -m venv venv
    ```

   Hint: In some environments, you may need to use `python` or `python3` instead of `py`.
        Before creating the venv, you may want to verify usage of correct python version!

4. Activate the virtual environment:
    * On Windows, using PowerShell:

        ```PowerShell
        .\venv\Scripts\activate
        ```

    * On Windows, using Git Bash:

        ```bash
        source venv/Scripts/activate
        ```

    * On macOS:

        ```bash
        source venv/bin/activate
        ```

## 4. Installing and Configuring Poetry

### Windows & macOS

1. Install Poetry by following the [official installation instructions](https://python-poetry.org/docs/#installation).
   >**_NOTE:_** Make sure your poetry version > 2.x.x
    * Using the recommended installation script:

        ```bash
        curl -sSL https://install.python-poetry.org | python3 -
        ```

2. Add Poetry to your PATH (follow the instructions provided by the installer).
3. Verify the installation by running:

    ```bash
    poetry --version
    ```

    * Check the virtual environment that poetry is using:

    ```PowerShell
   poetry env info
    ```

    If it is not what you were expecting, refer to [Installing Python 3.13](#1-installing-python-313) and consider Cleaning up your Python installations.

4. Navigate to your GenRevive project directory (if not already there):

    ```bash
    cd path/to/your/project
    
    ```

5. Remove .tempate from .env files in your project
6. (Optional) Set up nexus repository credentials so poetry will use it as a primary python packages source instead of pypi.org (it might fail sometimes).

    ```bash
    poetry config http-basic.pypi-nexus ${NEXUS_USER} ${NEXUS_PASS}
    ```

    pypi-nexus is the name of repository defined in `pyproject.toml`

    `NEXUS USER` and `NEXUS_PASS` are user's CORP credentials.

7. (Optional) Create/Update the `poetry.lock` file to lock the dependencies specified in `pyproject.toml`.

    ```bash
    poetry lock
    ```

   >**_NOTE:_** By default, this will lock all dependencies to the latest available compatible versions.
   > To only refresh the lock file, use the `--no-update` option.
   > The `poetry.lock` file is committed to get reproducible builds.
8. Install the dependencies specified in `pyproject.toml`:

    ```bash
   poetry install
    ```

## 5. Integrating with IDE (Optional)

### Integrating with PyCharm CE (Windows & macOS)

1. Open PyCharm Community Edition.
2. Select "Open" and navigate to your project directory.
3. Set up your interpreter to use the virtual environment:
    1. Go to `File` > `Settings` (or `PyCharm` > `Preferences` on macOS).
    2. Navigate to `Project: <your_project_name>` > `Python Interpreter`.
    3. Click on the gear icon and select `Add...`.
    4. Choose `Existing environment`.
    5. Navigate to the virtual environment you created (e.g., `path/to/your/project/venv/bin/python` for macOS
       or `path\to\your\project\venv\Scripts\python.exe` for Windows).
    6. Click `OK` to apply the changes.

### Integrating with Visual Studio Code

1. Install and enable the [Python extension](https://marketplace.visualstudio.com/items?itemName=ms-python.python) from the Visual Studio Code market place.
1. Open editor commands (`Ctrl+Shift+P`) and choose `Python: Select Interpreter`.
1. Select `Python 3.13.x ('venv': venv)`.
1. To verify that the configuration was successful, check if all imports are resolved correctly now.

## 6. Building GenRevive

In order to build and package GenRevive code, you need to:

1. Navigate to your GenRevive project directory (if not already there):

    ```bash
    cd path/to/your/project
    ```

2. Build the project:

    ```bash
    poetry build
    ```

3. The successful build will produce the `genrevive-<version>.tar.gz` and `genrevive-<version>-py3-none-any.whl` files and place them in `dist/` directory. (This files will be used by Poetry as local dependencies for your migrator projects.)
4. Add following line to your `pyproject.toml` file of your migrator project under `[tool.poetry.dependencies]` section:

    ```plaintext
   genrevive = { path = "<path/to/genrevive>", develop = false }
    ```

## 7. Running tests

To run tests you can use PyCharm build-in run feature or by calling:

```bash
pytest ./tests/
```

## 8. Enabling Long Path Support in Windows 10

By default, Windows has a file path length limit of 260 characters, which includes the drive letter, directories, and file name. This can cause issues when working with deeply nested directories or long file names.

To avoid these problems, you can enable **Long Path Support** in Windows, allowing it to handle file paths up to 32,767 characters. This is particularly useful when working with large, complex directory structures or long file names.

For more information on how to enable Long Path Support, [see the official documentation](https://docs.microsoft.com/en-us/windows/win32/fileio/maximum-file-path-limitation).

Run PowerShell as administrator and execute:

```powershell
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -Value 1 -PropertyType DWORD -Force
```

# Additional tools

## Langfuse

  Langfuse is a tool used for debugging and analysis of LLM applications. You can learn how to set it up [here](https://github2.capgemini.com/Capgemini-Innersource/Global.CCA-AppsModernization-GenRevive-Migrator-Template/blob/main/docs/langfuse_guide.md)  

## Use of MCP Tools in GenRevive

GenRevive provides a default MCP server (FileSystem MCP) which is configured by default in the mcp.json in the migrator-template. For the configuration of the MCP in the migrator-template, Please refer to the documentation links below.

You can learn more about the FileSystem MCP server and its capabilities [here](https://github.com/modelcontextprotocol/servers/tree/main/src/filesystem).

Filesystem configuration details can be found [here](https://github2.capgemini.com/Capgemini-Innersource/Global.CCA-AppsModernization-GenRevive-Feature-Examples/blob/main/docs/MCP_Guide.md)

## Angular helpers

GenRevive provides comprehensive Angular helper functions designed specifically for Angular migration scenarios. You can learn more [here](genrevive/helpers/angular/angular_helpers.md)

Note: The OpenAPI client generator helper now supports selecting the generator name.

* New API: `genrevive.helpers.angular.angular_openapi.generate_client_with_generator(openapi_file_path, angular_project_path, generator_name='typescript-angular', generator_options=None)`
* Backwards compatible wrapper: `generate_client(...)` remains available but is deprecated. Prefer the new function when calling from migrators and pass the desired `generator_name`.

## Integration tests

The integration tests assure the quality of features that are implemented in the genrevive project.
At the moment they can only be run locally with `pytest` because there is no CI pipeline automation for the migrator-template repository.
The integration tests requires configuration of several environment variables.
There should be under the folder `test` one "global" `.test.env` file containing environment variable values that are shared across all the tests.

The values in the `.test.env` files are often specific to the local environment, so they aren't committed to the repository.
Use `.test.env.template` files as a base — copy, rename, and fill them with your environment-specific values in order to run integration tests with `pytest`.

| Environment Variable      | Required | Description                                      | Valid Values | Example                              |
|:--------------------------|:--------:|:-------------------------------------------------|:------------:|:-------------------------------------|
| `LLM_PROVIDER`            |   Yes    | LLM provider to be used by the crewai RAG tools    |    String    |  `azure_openai`                       |
| `AGENT_MODEL`             |   Yes    | LLM model to be used by the crewai RAG tools    |    String    |  `azure/gpt-4o`                       |
| `AZURE_API_VERSION`       |    Yes    | Version of the Azure OpenAI service          |    String    | `2024-08-01-preview`                 |
| `AZURE_API_BASE`          |    Yes    | Endpoint URL for Azure OpenAI service           | String (URL) | `https://api.openai.azure.com`       |
| `AZURE_API_KEY`           |    Yes    | API key for Azure OpenAI service                 |    String    | `your_api_key`                       |
| `EMBEDDING_PROVIDER`    |    No    | Embedding model provider name.  |   String    | `azure or ollama`                               |
| `EMBEDDING_MODEL`      |    No    | Embedding model name                | String | `nomic-embed-text or text-embedding-3-large`    |
| `EMBEDDING_DEPLOYMENT_NAME`      |    No    | Deployment name for embedding model (Azure only)                | String | `text-embedding-3-large`    |
| `EMBEDDING_API_KEY`      |    No    | API key for embedding model (Azure only)               | String | `your_api_key`    |
| `EMBEDDING_API_BASE`      |    No    | Base URL for embedding model API (Azure only)                | String | `https://embedding.openai.azure.com`    |
| `EMBEDDING_API_VERSION`      |    No    | API version for embedding model (Azure only)               | String | `2024-02-01`    |
| `CHUNK_SIZE`      |    No    | The size of data chunks being processed                | Integer | 256    |
| `CHUNK_OVERLAP`      |    No    | The overlap to maintain the context between chunks.                | Integer | 50    |
| `MIN_CHUNK_SIZE`      |    No    | The minimum size of data chunks being processed                | Integer | 50    |


More environment variables for the LLM provider can be set in the .test.env for example:

```env
   LLM_PROVIDER="ollama"
   AGENT_MODEL="llama2"
   LLM_TEMPERATURE=0.5
   LLM_TOP_P=1
   LLM_STREAM=true
```

## Notes

These variables are used by:

1. CrewAI RAG tools: `EMBEDDING_PROVIDER`, `EMBEDDING_MODEL`
2. CrewAI Knowledge: All of the above when `EMBEDDING_PROVIDER=azure`
If you're using Azure embeddings for CrewAI Knowledge, make sure to set:

```
EMBEDDING_PROVIDER=azure
EMBEDDING_MODEL= text-embedding-3-large(or your deployed model)
EMBEDDING_DEPLOYMENT_NAME, EMBEDDING_API_KEY, EMBEDDING_API_BASE, and EMBEDDING_API_VERSION accordingly.
```

3. CrewAI Memory: All of the above when `EMBEDDING_PROVIDER=openai`
```
EMBEDDING_PROVIDER=openai
EMBEDDING_MODEL= text-embedding-3-large(or your deployed model)
EMBEDDING_DEPLOYMENT_NAME, EMBEDDING_API_KEY, EMBEDDING_API_BASE, and EMBEDDING_API_VERSION accordingly.
```

# Contributing to GenRevive

We welcome contributions to **GenRevive**! To contribute, please follow the steps below:

## Access Requirements

To contribute directly by opening a merge request or creating a new issue, you need access to the Devon ProductionLine for our GitLab repositories [GenRevive](https://devon.s2-eu.capgemini.com/gitlab/cca-genrevive-global/Global.CCA-AppsModernization-GenRevive) and [GenRevive-Migrator-Template](https://devon.s2-eu.capgemini.com/gitlab/cca-genrevive-global/Global.CCA-AppsModernization-GenRevive-Migrator-Template).  
Please contact Kristina Peteln (kristina.peteln@capgemini.com) or Xinni Wang (xinni.a.wang@capgemini.com) to request access. Once approved, you’ll be added to the appropriate group with the necessary permissions.

## How to Contribute via Merge Requests

1. **Fork the Repository**: Start by forking the GenRevive repository to your own GitLab account.
2. **Create a Feature Branch**: Make your changes in a new branch with a descriptive name (e.g., `feature/add-new-module`).
3. **Commit Your Changes**: Write clear, concise commit messages that explain your changes.
4. **Push to Your Fork**: Push your branch to your forked repository on GitLab.
5. **Open a Merge Request (MR)**: Submit a merge request from your repository to the `develop` branch of the GenRevive repository. Please include a detailed description of your changes and any relevant issue numbers.

## How to Contribute by Creating Issues

1. **Open an Issue**: If you find a bug, have a feature request, or have any other suggestions, please open an [issue in the GenRevive GitLab repository](https://devon.s2-eu.capgemini.com/gitlab/cca-genrevive-global/Global.CCA-AppsModernization-GenRevive/-/issues).
2. **Provide Details**: Include a clear and concise description of the issue, steps to reproduce (if applicable), and any relevant screenshots or logs.
3. **Label Your Issue**: Use appropriate labels to categorize your issue (e.g., `bug`, `enhancement`, `question`). 

Our team will review your issue and provide feedback or updates as soon as possible.
